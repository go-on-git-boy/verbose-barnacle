# Horizon port report

| | |
|---|---|
| upstream v0.8.0 | 2bdb97f95f154f32d281aaa08446ae007b8ca117 |
| upstream v0.10.0 | f5337cdc947ff6d4c4196737e2c807a48f2a1fc2 |
| Skate SDK | 7eb0faf7787f5e01333c228b8e3f03c32f7295ea |
| nfsmw-nx | 4e3ffc24fe80285189f2cea601606c529d5f1b97 |
| port tree | `C:\Users\Jameson\Desktop\out\horizon-sdk` |

**38** Horizon-only files copied, **35** merged cleanly, **42** need manual conflict resolution, **2** edits target files the Skate SDK does not have.

## Conflicts - fix these first (most conflicting hunks first) (42)
- `src/audio/xma_context.cpp  [14 hunk(s)]`
- `src/ui/vulkan/vulkan_presenter.cpp  [11 hunk(s)]`
- `src/core/threading_posix.cpp  [6 hunk(s)]`
- `src/ui/imgui_drawer.cpp  [6 hunk(s)]`
- `src/ui/rex_app.cpp  [6 hunk(s)]`
- `src/audio/sdl/sdl_audio_driver.cpp  [5 hunk(s)]`
- `src/input/input_system.cpp  [5 hunk(s)]`
- `src/audio/xma_decoder.cpp  [4 hunk(s)]`
- `src/graphics/vulkan/command_processor.cpp  [4 hunk(s)]`
- `CMakeLists.txt  [3 hunk(s)]`
- `resources/templates/init/rexglue_cmake.inja  [3 hunk(s)]`
- `src/audio/audio_system.cpp  [3 hunk(s)]`
- `src/core/clock_posix.cpp  [3 hunk(s)]`
- `src/core/filesystem_posix.cpp  [3 hunk(s)]`
- `src/filesystem/devices/host_path_file.cpp  [3 hunk(s)]`
- `src/system/xmemory.cpp  [3 hunk(s)]`
- `include/rex/audio/sdl/sdl_audio_driver.h  [2 hunk(s)]`
- `include/rex/audio/xma/context.h  [2 hunk(s)]`
- `include/rex/thread/fiber.h  [2 hunk(s)]`
- `include/rex/ui/surface.h  [2 hunk(s)]`
- `include/rex/ui/vulkan/presenter.h  [2 hunk(s)]`
- `src/core/timer_queue.cpp  [2 hunk(s)]`
- `src/graphics/vulkan/render_target_cache.cpp  [2 hunk(s)]`
- `src/graphics/vulkan/shared_memory.cpp  [2 hunk(s)]`
- `src/ui/CMakeLists.txt  [2 hunk(s)]`
- `src/ui/overlay/debug_overlay.cpp  [2 hunk(s)]`
- `src/ui/presenter.cpp  [2 hunk(s)]`
- `src/ui/vulkan/vulkan_instance.cpp  [2 hunk(s)]`
- `include/rex/input/input_system.h  [1 hunk(s)]`
- `include/rex/ui/overlay/debug_overlay.h  [1 hunk(s)]`
- `include/rex/ui/renderdoc_api.h  [1 hunk(s)]`
- `include/rex/ui/vulkan/api.h  [1 hunk(s)]`
- `src/codegen/builders/context.cpp  [1 hunk(s)]`
- `src/codegen/builders/control_flow.cpp  [1 hunk(s)]`
- `src/core/CMakeLists.txt  [1 hunk(s)]`
- `src/core/logging.cpp  [1 hunk(s)]`
- `src/filesystem/devices/host_path_device.cpp  [1 hunk(s)]`
- `src/filesystem/devices/host_path_entry.cpp  [1 hunk(s)]`
- `src/graphics/CMakeLists.txt  [1 hunk(s)]`
- `src/graphics/vulkan/texture_cache.cpp  [1 hunk(s)]`
- `src/ui/overlay/settings_overlay.cpp  [1 hunk(s)]`
- `src/ui/renderdoc_api.cpp  [1 hunk(s)]`


## Horizon edits to files MISSING in the Skate SDK (added upstream after v0.8.0) (2)
- `resources/templates/codegen/pch_h.inja`
- `src/system/gpu_plugin_loader.cpp`


## Horizon-only new files (38)
- `cmake/rexglue_switch.cmake`
- `include/rex/audio/switch/switch_audio_system.h`
- `include/rex/input/switch/switch_input_driver.h`
- `include/rex/ui/surface_switch.h`
- `include/rex/ui/switch_apm.h`
- `include/rex/ui/switch_imgui_input.h`
- `include/rex/ui/switch_saltynx.h`
- `include/rex/ui/switch_sysclk.h`
- `include/rex/ui/vulkan/functions/instance_nn_vi_surface.inc`
- `include/rex/ui/window_switch.h`
- `include/rex/ui/windowed_app_context_switch.h`
- `src/audio/switch/switch_audio_system.cpp`
- `src/core/dynlib_switch.cpp`
- `src/core/exception_handler_switch.cpp`
- `src/core/fiber_switch.cpp`
- `src/core/guest_memory_switch.cpp`
- `src/core/guest_memory_switch.h`
- `src/core/mapped_memory_switch.cpp`
- `src/core/memory_switch.cpp`
- `src/core/resume_ctx.h`
- `src/core/rex_decode.h`
- `src/core/seh_switch.cpp`
- `src/core/switch_libc_supplement.c`
- `src/core/threading_switch.cpp`
- `src/core/threading_switch.h`
- `src/input/switch/switch_input_driver.cpp`
- `src/ui/runtime_switch.cpp`
- `src/ui/switch_apm.cpp`
- `src/ui/switch_crash_hooks.c`
- `src/ui/switch_elf_stubs.c`
- `src/ui/switch_perf.cpp`
- `src/ui/switch_saltynx.cpp`
- `src/ui/switch_sysclk.cpp`
- `src/ui/window_switch.cpp`
- `src/ui/windowed_app_context_switch.cpp`
- `src/ui/windowed_app_main_switch.cpp`
- `switch_compat/endian.h`
- `switch_compat/netinet/ip.h`


## Name clashes (Skate already has a file at that path; Horizon copy saved as *.nfs-horizon) (0)
_none_


## Binary files (Skate version kept) (0)
_none_


## Third-party overlay files (parked in thirdparty/_nfs_overlay/, apply by hand) (5)
- `thirdparty/FFmpeg/config.h`
- `thirdparty/FFmpeg/config_nfsmw_wmv3.h`
- `thirdparty/FFmpeg/config_switch_aarch64.h`
- `thirdparty/FFmpeg/libavcodec/fft_template.c`
- `thirdparty/FFmpeg/libavcodec/mdct_template.c`


## Errors (0)
_none_


## Merged cleanly (textually - NOT proof it compiles) (35)
- `cmake/rexglue_helpers.cmake`
- `include/rex/audio/audio_system.h`
- `include/rex/filesystem/devices/host_path_device.h`
- `include/rex/filesystem/devices/host_path_entry.h`
- `include/rex/filesystem/devices/host_path_file.h`
- `include/rex/filesystem/devices/stfs_xbox.h`
- `include/rex/filesystem/file.h`
- `include/rex/graphics/primitive_processor.h`
- `include/rex/logging/types.h`
- `include/rex/memory/utils.h`
- `include/rex/platform.h`
- `include/rex/platform/dynlib.h`
- `include/rex/system/xfile.h`
- `include/rex/ui/overlay/settings_overlay.h`
- `include/rex/ui/presenter.h`
- `include/rex/ui/vulkan/device.h`
- `include/rex/ui/vulkan/instance.h`
- `src/audio/CMakeLists.txt`
- `src/codegen/builders/builder_context.h`
- `src/filesystem/virtual_file_system.cpp`
- `src/graphics/command_processor.cpp`
- `src/graphics/primitive_processor.cpp`
- `src/graphics/vulkan/pipeline_cache.cpp`
- `src/graphics/vulkan/primitive_processor.cpp`
- `src/input/CMakeLists.txt`
- `src/kernel/xam/xam_content.cpp`
- `src/kernel/xboxkrnl/xboxkrnl_audio.cpp`
- `src/kernel/xboxkrnl/xboxkrnl_audio_xma.cpp`
- `src/kernel/xboxkrnl/xboxkrnl_io.cpp`
- `src/system/CMakeLists.txt`
- `src/system/xam/content_manager.cpp`
- `src/system/xthread.cpp`
- `src/ui/vulkan/vulkan_device.cpp`
- `thirdparty/CMakeLists.txt`
- `thirdparty/ffmpeg-overlay/codec_list.c`


_1 docs/tests/CI files differing from upstream were ignored; 893 Horizon-side files were identical to upstream._
