#!/usr/bin/env python3
"""
port_horizon.py - port the nfsmw-nx "Horizon" (Nintendo Switch) layer of the ReXGlue SDK onto the Skate 3 SDK fork.

WHAT IT DOES (strategy "a" from the Phase 0 notes: port the Horizon layer DOWN onto the Skate fork)
  Three source trees, all read straight from git objects (so working-tree CRLF/edits never matter):
    SKATE  = skate3recomp/third_party/rexglue-sdk   at HEAD     (v0.8.0 line + ~240 Skate changes)
    UP10   = upstream rexglue-sdk, tag v0.10.0                  (what nfsmw-nx's SDK was derived from)
    NFS    = nfsmw-nx  <sdk/>  at HEAD                          (v0.10.0 + Horizon layer)
  For every file under NFS:
    - not in UP10                    -> HORIZON-NEW      copied into the port tree (39 files expected per Phase 0)
    - in UP10, identical             -> untouched by the Horizon work, ignored
    - in UP10, different (Horizon edit):
        * file missing in SKATE      -> MISSING-IN-SKATE   reported, NOT copied (it was added upstream after v0.8.0)
        * otherwise                  -> 3-way merge:  current=SKATE, base=UP10, other=NFS
                                        i.e. "apply the Horizon diff (UP10 -> NFS) to the Skate file"
                                        clean merge  -> written
                                        conflicts    -> written WITH conflict markers (diff3 style), listed in the report
  Result: a full SDK tree in --out (a git repo with two commits: baseline, then the automatic port), plus
  report.md / report.json / conflict_hunks.txt in --report.

WHAT IT CANNOT DO
  A merge that applies cleanly is not proof the code compiles or behaves: v0.8 -> v0.10 changed 257 upstream files and
  the Horizon edits were written against v0.10 APIs. Expect compile errors after the textual merge; fix them in --out
  (it is a git repo, so `git diff HEAD~1` shows exactly what the port changed). Re-running never overwrites --out
  unless you pass --force.

Only the Python standard library and git are used.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

SKIP_PREFIXES = ('docs/', '.github/', 'tests/')
SKIP_NAMES = {'README.md', 'README.upstream.md', 'LICENSE', '.gitignore', '.gitmodules', '.gitattributes'}
MARKER = '.skate3nx-port'


def log(msg=''):
    print(msg, flush=True)


# ----------------------------------------------------------------------------------------------------------- git helpers
def git(repo, *args, check=True, input=None):
    p = subprocess.run(['git', '-c', 'core.quotepath=false', '-C', repo] + list(args),
                       input=input, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode != 0:
        raise RuntimeError('git %s failed (%d): %s' % (' '.join(args), p.returncode, p.stderr.decode('utf-8', 'replace').strip()))
    return p


def rev_parse(repo, ref):
    p = git(repo, 'rev-parse', '--verify', '--quiet', ref + '^{commit}', check=False)
    return p.stdout.decode().strip() if p.returncode == 0 else None


def ls_tree(repo, ref, subdir=None):
    """-> (blobs {path: sha}, links {path: sha}) for ref, optionally restricted to and relative to subdir."""
    args = ['ls-tree', '-r', '-z', '--full-tree', ref]
    if subdir:
        args += ['--', subdir.rstrip('/') + '/']
    out = git(repo, *args).stdout
    blobs, links = {}, {}
    strip = (subdir.rstrip('/') + '/') if subdir else ''
    for entry in out.split(b'\0'):
        if not entry:
            continue
        meta, path = entry.split(b'\t', 1)
        mode, typ, sha = meta.decode().split(' ')
        p = path.decode('utf-8', 'surrogateescape')
        if strip and p.startswith(strip):
            p = p[len(strip):]
        if mode == '160000':
            links[p] = sha
        elif typ == 'blob':
            blobs[p] = sha
    return blobs, links


def dir_tree(root, hash_repo):
    """Blob-hash every file under a plain folder (e.g. the unzipped nfsmw-nx release's sdk/) so it can be compared with git trees.
    git trees store LF, so text files with CRLF endings are hashed - and later read - LF-normalised.
    Returns ({path: sha}, DirBlobs)."""
    paths = []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d != '.git']
        for f in fn:
            paths.append(os.path.join(dp, f))
    rels = [os.path.relpath(p, root).replace(os.sep, '/') for p in paths]
    inp = ('\n'.join(paths) + '\n').encode('utf-8', 'surrogateescape')
    out = git(hash_repo, 'hash-object', '--no-filters', '--stdin-paths', input=inp).stdout.decode().split()
    if len(out) != len(paths):
        raise RuntimeError('hash-object returned %d hashes for %d files' % (len(out), len(paths)))
    tree, store = {}, {}
    for rel, path, sha in zip(rels, paths, out):
        with open(path, 'rb') as f:
            data = f.read()
        if b'\r\n' in data and b'\0' not in data:
            data = data.replace(b'\r\n', b'\n')
            sha = git(hash_repo, 'hash-object', '--no-filters', '--stdin', input=data).stdout.decode().strip()
            store[sha] = (path, True)
        else:
            store[sha] = (path, False)
        tree[rel] = sha
    return tree, DirBlobs(store)


class DirBlobs:
    def __init__(self, store):
        self.store = store

    def get(self, sha):
        if sha not in self.store:
            raise KeyError(sha)
        path, normalise = self.store[sha]
        with open(path, 'rb') as f:
            data = f.read()
        return data.replace(b'\r\n', b'\n') if normalise else data

    def close(self):
        pass


class Blobs:
    """Persistent `git cat-file --batch` reader."""

    def __init__(self, repo):
        self.p = subprocess.Popen(['git', '-C', repo, 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)

    def get(self, sha):
        self.p.stdin.write(sha.encode() + b'\n')
        self.p.stdin.flush()
        hdr = self.p.stdout.readline().split()
        if len(hdr) < 3 or hdr[1] != b'blob':
            raise KeyError(sha)
        size = int(hdr[2])
        data = self.p.stdout.read(size)
        self.p.stdout.read(1)
        return data

    def close(self):
        try:
            self.p.stdin.close()
            self.p.wait(timeout=10)
        except Exception:
            self.p.kill()


def three_way(cur, base, other):
    """git merge-file on byte strings. -> (merged bytes, n_conflicts, error or None)."""
    if b'\0' in cur or b'\0' in base or b'\0' in other:
        return None, 0, 'binary'
    with tempfile.TemporaryDirectory() as d:
        paths = []
        for name, data in (('skate', cur), ('upstream-v0.10.0', base), ('nfsmw-horizon', other)):
            fp = os.path.join(d, name)
            with open(fp, 'wb') as f:
                f.write(data)
            paths.append(fp)
        p = subprocess.run(['git', 'merge-file', '-p', '--diff3', '-L', 'skate-fork', '-L', 'upstream-v0.10.0', '-L', 'nfsmw-horizon'] + paths,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    rc = p.returncode
    if rc < 0 or rc == 255:
        return None, 0, 'merge-file error: ' + p.stderr.decode('utf-8', 'replace').strip()
    return p.stdout, rc, None


# ----------------------------------------------------------------------------------------------------------- the port
def skipped(path):
    return path.startswith(SKIP_PREFIXES) or os.path.basename(path) in SKIP_NAMES


def classify_and_merge(args):
    t0 = time.time()
    log('== reading trees from git')
    v08 = rev_parse(args.upstream, args.v08) or rev_parse(args.upstream, '2bdb97f')
    v10 = rev_parse(args.upstream, args.v010)
    if not v10:
        tags = git(args.upstream, 'tag', '--list', '*0.10*', check=False).stdout.decode().split()
        raise SystemExit('upstream tag %s not found in %s (tags like it: %s)' % (args.v010, args.upstream, ', '.join(tags) or 'none'))
    skate_head = rev_parse(args.skate_sdk, 'HEAD')
    nfs_head = rev_parse(args.nfs_repo, 'HEAD') if args.nfs_repo else 'plain folder ' + args.nfs_dir
    log('  upstream v0.8.0  : %s' % (v08 or 'NOT FOUND (continuing without it)'))
    log('  upstream v0.10.0 : %s' % v10)
    log('  skate SDK HEAD   : %s' % skate_head)
    log('  nfsmw-nx HEAD    : %s' % nfs_head)

    up10, up10_links = ls_tree(args.upstream, v10)
    skate, skate_links = ls_tree(args.skate_sdk, 'HEAD')
    if args.nfs_repo:
        nfs, nfs_links = ls_tree(args.nfs_repo, 'HEAD', args.nfs_sdk_prefix)
        b_nfs = Blobs(args.nfs_repo)
    else:
        nfs, b_nfs = dir_tree(args.nfs_dir, args.skate_sdk)
        nfs_links = {}
    log('  files: upstream10=%d skate=%d nfsmw-sdk=%d' % (len(up10), len(skate), len(nfs)))

    b_up = Blobs(args.upstream)
    b_sk = Blobs(args.skate_sdk)

    res = {'horizon_new': [], 'new_clash': [], 'merged_clean': [], 'merged_conflict': [], 'missing_in_skate': [],
           'binary_kept_skate': [], 'overlay_thirdparty': [], 'skipped_docs_tests': [], 'untouched_by_horizon': 0, 'errors': []}
    writes = {}   # path -> bytes   (to write into the port tree)

    log('== classifying %d Horizon-side files' % len(nfs))
    for path in sorted(nfs):
        nfs_sha = nfs[path]
        top = path.split('/')
        # thirdparty submodules (FFmpeg, ...): the nfs copy is an overlay of changed files, not a normal source file
        if top[0] == 'thirdparty' and len(top) > 2:
            link = 'thirdparty/' + top[1]
            if link in skate_links or link in up10_links:
                res['overlay_thirdparty'].append(path)
                writes['thirdparty/_nfs_overlay/' + path[len('thirdparty/'):]] = b_nfs.get(nfs_sha)
                continue
        if skipped(path):
            if path not in up10 or up10[path] != nfs_sha:
                res['skipped_docs_tests'].append(path)
            continue
        u = up10.get(path)
        if u is None:
            if path in skate:
                res['new_clash'].append(path)
                writes[path + '.nfs-horizon'] = b_nfs.get(nfs_sha)          # keep Skate's file, park the Horizon one beside it
            else:
                res['horizon_new'].append(path)
                writes[path] = b_nfs.get(nfs_sha)
            continue
        if u == nfs_sha:
            res['untouched_by_horizon'] += 1
            continue
        # Horizon edited an upstream file
        s = skate.get(path)
        if s is None:
            res['missing_in_skate'].append(path)
            continue
        try:
            cur, base, other = b_sk.get(s), b_up.get(u), b_nfs.get(nfs_sha)
        except KeyError as e:
            res['errors'].append('%s: blob %s not readable' % (path, e))
            continue
        if cur == base:                    # Skate never touched it and upstream did not drift: the Horizon version is the answer
            writes[path] = other
            res['merged_clean'].append(path)
            continue
        merged, conflicts, err = three_way(cur, base, other)
        if err == 'binary':
            res['binary_kept_skate'].append(path)
        elif err:
            res['errors'].append('%s: %s' % (path, err))
        elif conflicts == 0:
            writes[path] = merged
            res['merged_clean'].append(path)
        else:
            writes[path] = merged
            res['merged_conflict'].append({'path': path, 'conflicts': conflicts})
    for b in (b_up, b_sk, b_nfs):
        b.close()
    log('  done in %.1fs' % (time.time() - t0))
    return res, writes, {'v08': v08, 'v010': v10, 'skate_head': skate_head, 'nfs_head': nfs_head}, skate_links


def make_link(link, target):
    link = os.path.normpath(link)
    target = os.path.normpath(target)
    os.makedirs(os.path.dirname(link), exist_ok=True)
    if os.path.lexists(link):
        if os.path.isdir(link) and not os.path.islink(link):
            os.rmdir(link)                  # git archive leaves an empty folder for a submodule
        else:
            os.remove(link)
    if os.name == 'nt':
        p = subprocess.run(['cmd', '/c', 'mklink', '/J', link, target], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if p.returncode != 0:
            raise RuntimeError('mklink /J failed for %s: %s' % (link, p.stderr.decode(errors='replace') + p.stdout.decode(errors='replace')))
    else:
        os.symlink(target, link, target_is_directory=True)


def is_link(path):
    """Symlink, or a Windows junction/other reparse point."""
    if os.path.islink(path):
        return True
    if os.name == 'nt':
        try:
            return bool(os.lstat(path).st_file_attributes & 0x400)     # FILE_ATTRIBUTE_REPARSE_POINT
        except OSError:
            return False
    return False


def remove_links_only(root):
    """Delete every link/junction under root WITHOUT following it. rmtree on older Pythons would walk into a junction and
    delete the target (= your real third-party checkouts), so links must be removed first."""
    for dirpath, dirnames, filenames in os.walk(root, topdown=True, followlinks=False):
        keep = []
        for d in dirnames:
            full = os.path.join(dirpath, d)
            if is_link(full):
                if os.path.islink(full):
                    os.unlink(full)
                else:
                    os.rmdir(full)                  # removes the junction only
            else:
                keep.append(d)
        dirnames[:] = keep


def build_tree(args, res, writes, skate_links, meta):
    out = os.path.abspath(args.out)
    if os.path.exists(out):
        if not args.force:
            raise SystemExit('%s already exists. It is a git repo you may be editing; re-run with --force to regenerate it from scratch.' % out)
        if not os.path.exists(os.path.join(out, MARKER)):
            raise SystemExit('refusing to delete %s: it has no %s marker, so it was not created by this tool.' % (out, MARKER))
        remove_links_only(out)
        shutil.rmtree(out, onerror=lambda f, p, e: (os.chmod(p, 0o700), f(p)))
    os.makedirs(out)

    log('== extracting the Skate SDK (tracked files at HEAD) into %s' % out)
    tarp = os.path.join(tempfile.gettempdir(), 'skate3nx-sdk-%d.tar' % os.getpid())
    with open(tarp, 'wb') as f:
        p = subprocess.run(['git', '-C', args.skate_sdk, 'archive', '--format=tar', 'HEAD'], stdout=f, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise RuntimeError('git archive failed: ' + p.stderr.decode(errors='replace'))
    with tarfile.open(tarp) as tf:
        try:
            tf.extractall(out, filter='data')
        except TypeError:
            tf.extractall(out)
    os.remove(tarp)

    log('== linking the SDK third-party libraries (read-only reuse of your existing checkouts)')
    linked, ignore = 0, []
    for rel in sorted(skate_links):
        src = os.path.join(args.skate_sdk, rel)
        if os.path.isdir(src) and os.listdir(src):
            make_link(os.path.join(out, rel), src)
            ignore.append(rel + '/')
            linked += 1
    tp = os.path.join(args.skate_sdk, 'thirdparty')
    if os.path.isdir(tp):
        for name in sorted(os.listdir(tp)):
            src = os.path.join(tp, name)
            rel = 'thirdparty/' + name
            dst = os.path.join(out, 'thirdparty', name)
            if not os.path.isdir(src) or rel in skate_links or not os.listdir(src):
                continue
            if os.path.isdir(dst) and os.listdir(dst):
                continue                                        # tracked content already extracted
            make_link(dst, src)                                 # e.g. a library cloned by hand that the SDK commit does not pin
            ignore.append(rel + '/')
            linked += 1
    log('  %d third-party folders linked' % linked)

    with open(os.path.join(out, '.gitignore.skate3nx'), 'w', newline='\n') as f:
        f.write('\n'.join(ignore) + '\n')
    # use a local exclude file so the SDK's own .gitignore stays untouched
    git(out, 'init', '-q')
    with open(os.path.join(out, '.git', 'info', 'exclude'), 'a', newline='\n') as f:
        f.write('\n'.join(ignore + ['.gitignore.skate3nx', MARKER]) + '\n')
    with open(os.path.join(out, MARKER), 'w') as f:
        f.write('created by port_horizon.py\n')
    ident = ['-c', 'user.name=skate3nx-port', '-c', 'user.email=skate3nx@localhost', '-c', 'commit.gpgsign=false']
    git(out, 'add', '-A')
    git(out, *ident, 'commit', '-q', '-m', 'baseline: Skate SDK fork at ' + meta['skate_head'][:12])

    log('== writing %d ported files' % len(writes))
    for rel, data in writes.items():
        dst = os.path.join(out, rel.replace('/', os.sep))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst, 'wb') as f:
            f.write(data)
    git(out, 'add', '-A')
    msg = 'horizon port (automatic): %d new, %d merged clean, %d with conflict markers' % (
        len(res['horizon_new']), len(res['merged_clean']), len(res['merged_conflict']))
    git(out, *ident, 'commit', '-q', '-m', msg, '--allow-empty')
    return out


def conflict_hunks(out, conflicted):
    """Collect every conflict region with a little context, ready to paste into a chat or bug report."""
    lines_out = []
    for item in conflicted:
        path = item['path']
        with open(os.path.join(out, path.replace('/', os.sep)), 'rb') as f:
            text = f.read().decode('utf-8', 'replace').split('\n')
        i = 0
        while i < len(text):
            if text[i].startswith('<<<<<<< '):
                j = i
                while j < len(text) and not text[j].startswith('>>>>>>> '):
                    j += 1
                lo, hi = max(0, i - 3), min(len(text), j + 4)
                lines_out.append('=' * 100)
                lines_out.append('%s  (lines %d-%d)' % (path, i + 1, j + 1))
                lines_out.append('=' * 100)
                lines_out.extend(text[lo:hi])
                lines_out.append('')
                i = j
            i += 1
    return '\n'.join(lines_out)


def write_report(args, res, meta, out):
    os.makedirs(args.report, exist_ok=True)
    conflicted = sorted(res['merged_conflict'], key=lambda c: -c['conflicts'])
    summary = {
        'meta': meta,
        'counts': {k: (len(v) if isinstance(v, list) else v) for k, v in res.items()},
        'out': out,
    }
    with open(os.path.join(args.report, 'report.json'), 'w') as f:
        json.dump({'summary': summary, 'results': res}, f, indent=1)
    with open(os.path.join(args.report, 'conflict_hunks.txt'), 'w', encoding='utf-8', newline='\n') as f:
        f.write(conflict_hunks(out, conflicted) if conflicted else 'no conflicts\n')

    def sect(title, items, fmt=lambda x: x):
        s = '\n## %s (%d)\n' % (title, len(items))
        return s + ''.join('- `%s`\n' % fmt(i) for i in items) if items else s + '_none_\n'

    md = ['# Horizon port report', '',
          '| | |', '|---|---|',
          '| upstream v0.8.0 | %s |' % (meta['v08'] or 'not found'),
          '| upstream v0.10.0 | %s |' % meta['v010'],
          '| Skate SDK | %s |' % meta['skate_head'],
          '| nfsmw-nx | %s |' % meta['nfs_head'],
          '| port tree | `%s` |' % out, '',
          '**%d** Horizon-only files copied, **%d** merged cleanly, **%d** need manual conflict resolution, '
          '**%d** edits target files the Skate SDK does not have.' % (
              len(res['horizon_new']), len(res['merged_clean']), len(res['merged_conflict']), len(res['missing_in_skate']))]
    md.append(sect('Conflicts - fix these first (most conflicting hunks first)', conflicted, lambda c: '%s  [%d hunk(s)]' % (c['path'], c['conflicts'])))
    md.append(sect('Horizon edits to files MISSING in the Skate SDK (added upstream after v0.8.0)', res['missing_in_skate']))
    md.append(sect('Horizon-only new files', res['horizon_new']))
    md.append(sect('Name clashes (Skate already has a file at that path; Horizon copy saved as *.nfs-horizon)', res['new_clash']))
    md.append(sect('Binary files (Skate version kept)', res['binary_kept_skate']))
    md.append(sect('Third-party overlay files (parked in thirdparty/_nfs_overlay/, apply by hand)', res['overlay_thirdparty']))
    md.append(sect('Errors', res['errors']))
    md.append(sect('Merged cleanly (textually - NOT proof it compiles)', res['merged_clean']))
    md.append('\n_%d docs/tests/CI files differing from upstream were ignored; %d Horizon-side files were identical to upstream._\n' % (
        len(res['skipped_docs_tests']), res['untouched_by_horizon']))
    with open(os.path.join(args.report, 'report.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(md))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--skate-sdk', required=True, help='skate3recomp/third_party/rexglue-sdk (a git checkout)')
    ap.add_argument('--nfs-repo', help='nfsmw-nx git checkout (use this OR --nfs-dir)')
    ap.add_argument('--nfs-dir', help="plain folder with the Horizon SDK, e.g. the unzipped nfsmw-nx release's sdk/ (use this OR --nfs-repo)")
    ap.add_argument('--nfs-sdk-prefix', default='sdk', help="folder of the SDK inside nfsmw-nx (default 'sdk')")
    ap.add_argument('--upstream', required=True, help='clone of https://github.com/rexglue/rexglue-sdk (needs tags)')
    ap.add_argument('--v08', default='v0.8.0')
    ap.add_argument('--v010', default='v0.10.0')
    ap.add_argument('--out', required=True, help='port tree to create')
    ap.add_argument('--report', required=True, help='folder for report.md / report.json / conflict_hunks.txt')
    ap.add_argument('--force', action='store_true', help='regenerate --out (only if it was created by this tool)')
    ap.add_argument('--dry-run', action='store_true', help='classify and report only; do not create --out')
    args = ap.parse_args()
    if bool(args.nfs_repo) == bool(args.nfs_dir):
        ap.error('give exactly one of --nfs-repo or --nfs-dir')
    for k in ('skate_sdk', 'nfs_repo', 'nfs_dir', 'upstream', 'out', 'report'):
        if getattr(args, k):
            setattr(args, k, os.path.abspath(getattr(args, k)))

    if os.path.exists(args.out) and not args.force and not args.dry_run:
        raise SystemExit('%s already exists. It is a git repo you may be editing; re-run with --force to regenerate it from scratch.' % args.out)
    res, writes, meta, skate_links = classify_and_merge(args)
    out = os.path.abspath(args.out)
    if not args.dry_run:
        out = build_tree(args, res, writes, skate_links, meta)
        write_report(args, res, meta, out)
    c = res
    log('')
    log('== RESULT')
    log('  Horizon-only new files copied : %d' % len(c['horizon_new']))
    log('  merged cleanly                : %d' % len(c['merged_clean']))
    log('  merged WITH CONFLICTS         : %d' % len(c['merged_conflict']))
    log('  edits to files Skate lacks    : %d' % len(c['missing_in_skate']))
    log('  name clashes                  : %d' % len(c['new_clash']))
    log('  third-party overlay files     : %d' % len(c['overlay_thirdparty']))
    log('  errors                        : %d' % len(c['errors']))
    if not args.dry_run:
        log('  port tree : %s' % out)
        log('  report    : %s' % os.path.join(args.report, 'report.md'))
    return 0 if not c['errors'] else 2


if __name__ == '__main__':
    sys.exit(main())
