#!/usr/bin/env python3
"""
switch_inspect.py - check that the files the build produces are properly formatted Switch files.

  nro    <file.nro>  [--name N] [--author A] [--require-icon]
  icon   <file.jpg>
  nsp    <file.nsp>
  layout <sdcard-root> --folder skate3-nx --nro skate3-nx.nro [--game-dir game] [--require default.xex ...]

Exit code 0 = no errors (warnings may be printed), 1 = at least one error, 2 = usage / unreadable file.

The NRO / ASET / NACP offsets below were verified against a real, working homebrew NRO (nfsmw-nx's release build, 63 MB):
  NRO0 at 0x10, size field at 0x18, text/ro/data segment headers at 0x20 (contiguous, 0x1000-aligned), MOD0 at the offset
  stored at 0x4, an "ASET" block right after the NRO image with a 256x256 JFIF icon (no EXIF) and a 0x4000-byte NACP.
NSP = PFS0 container. hacBrewPack/NTON write NCAs plus (optionally) cnmt.xml / tik / cert entries.
Only the Python standard library is used.
"""
import argparse
import os
import struct
import sys

ERR, WARN, INFO = [], [], []


def err(m):
    ERR.append(m)
    print('  [ERROR] ' + m)


def warn(m):
    WARN.append(m)
    print('  [warn]  ' + m)


def info(m):
    INFO.append(m)
    print('  [ok]    ' + m)


def cstr(b):
    return b.split(b'\0', 1)[0].decode('utf-8', 'replace')


# ------------------------------------------------------------------------------------------------------------ JPEG
def jpeg_info(data):
    """-> (width, height, has_exif, progressive) or None if it is not a JPEG."""
    if len(data) < 4 or data[0:2] != b'\xff\xd8':
        return None
    i, w, h, exif, prog = 2, None, None, False, False
    while i + 4 <= len(data):
        if data[i] != 0xFF:
            i += 1
            continue
        m = data[i + 1]
        if m == 0xFF:
            i += 1
            continue
        if m in (0xD8, 0x01) or 0xD0 <= m <= 0xD7:
            i += 2
            continue
        if m == 0xD9:
            break
        seg_len = struct.unpack_from('>H', data, i + 2)[0]
        if m == 0xE1 and data[i + 4:i + 10] == b'Exif\0\0':
            exif = True
        if m in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
            h, w = struct.unpack_from('>HH', data, i + 5)
            prog = (m == 0xC2)
            break
        i += 2 + seg_len
    if w is None:
        return None
    return w, h, exif, prog


def check_icon_bytes(data, label):
    ji = jpeg_info(data)
    if ji is None:
        err('%s is not a valid JPEG' % label)
        return
    w, h, exif, prog = ji
    if (w, h) != (256, 256):
        err('%s is %dx%d, the Switch expects exactly 256x256' % (label, w, h))
    else:
        info('%s: JPEG 256x256, %d bytes' % (label, len(data)))
    if exif:
        warn('%s carries EXIF data; Home-menu forwarders show a "?" icon for that (NTON strips it, elf2nro does not)' % label)
    if prog:
        warn('%s is a progressive JPEG; use a baseline JPEG to be safe' % label)
    if len(data) > 0x20000:
        warn('%s is %d bytes; the NSP icon limit is 128 KB' % (label, len(data)))


def cmd_icon(a):
    with open(a.file, 'rb') as f:
        data = f.read()
    print('icon: %s' % a.file)
    check_icon_bytes(data, os.path.basename(a.file))


# ------------------------------------------------------------------------------------------------------------ NRO
def cmd_nro(a):
    print('nro: %s' % a.file)
    size_on_disk = os.path.getsize(a.file)
    with open(a.file, 'rb') as f:
        d = f.read()
    if len(d) < 0x80 or d[0x10:0x14] != b'NRO0':
        err('missing NRO0 magic at 0x10 (header %r) - not an NRO' % d[0x10:0x14])
        return
    info('NRO0 magic')
    ver, nro_size, flags = struct.unpack_from('<III', d, 0x14)
    segs = [struct.unpack_from('<II', d, 0x20 + 8 * i) for i in range(3)]
    bss = struct.unpack_from('<I', d, 0x38)[0]
    names = ('text', 'ro', 'data')
    ok = True
    if segs[0][0] != 0:
        err('text segment does not start at 0'); ok = False
    for i in (1, 2):
        if segs[i][0] != segs[i - 1][0] + segs[i - 1][1]:
            err('%s segment is not contiguous after %s' % (names[i], names[i - 1])); ok = False
    for i in range(3):
        if segs[i][0] % 0x1000 or segs[i][1] % 0x1000:
            err('%s segment is not 0x1000-aligned (off=%#x size=%#x)' % (names[i], segs[i][0], segs[i][1])); ok = False
    if segs[2][0] + segs[2][1] != nro_size:
        err('segments end at %#x but the header says the image is %#x bytes' % (segs[2][0] + segs[2][1], nro_size)); ok = False
    if nro_size > len(d):
        err('header says %d bytes, file has only %d (truncated?)' % (nro_size, len(d))); ok = False
    if ok:
        info('image %.1f MB: text %.1f MB, ro %.1f MB, data %.2f MB, bss %.1f MB (version %d, flags %#x)' % (
            nro_size / 1048576, segs[0][1] / 1048576, segs[1][1] / 1048576, segs[2][1] / 1048576, bss / 1048576, ver, flags))
    mod = struct.unpack_from('<I', d, 0x4)[0]
    if mod + 4 <= len(d) and d[mod:mod + 4] == b'MOD0':
        info('MOD0 at %#x' % mod)
    else:
        err('no MOD0 header at the offset stored at 0x4 (%#x): the loader cannot relocate this image' % mod)
    if segs[0][1] > 0 and struct.unpack_from('<I', d, 0)[0] >> 26 != 0x05:
        warn('first instruction is not an unconditional branch (b); unusual for libnx homebrew')

    a0 = nro_size
    if len(d) < a0 + 0x38 or d[a0:a0 + 4] != b'ASET':
        warn('no ASET block after the image: no icon / NACP inside the NRO, hbmenu will show defaults (build with elf2nro --icon --nacp)')
        if a.require_icon:
            err('--require-icon: the NRO has no ASET block')
        return
    aver = struct.unpack_from('<I', d, a0 + 4)[0]
    ic_off, ic_sz, nc_off, nc_sz, rf_off, rf_sz = struct.unpack_from('<QQQQQQ', d, a0 + 8)
    info('ASET v%d: icon %d B, nacp %d B, romfs %d B' % (aver, ic_sz, nc_sz, rf_sz))
    for nm, off, sz in (('icon', ic_off, ic_sz), ('nacp', nc_off, nc_sz), ('romfs', rf_off, rf_sz)):
        if sz and a0 + off + sz > len(d):
            err('ASET %s runs past the end of the file' % nm)
    if rf_sz and getattr(a, 'forbid_romfs', False):
        err('the NRO carries a romfs; the embedded (romfs-mode) NSP forwarder cannot be used with it')
    elif rf_sz:
        warn('the NRO carries a romfs; romfs-mode NSP forwarders cannot be used with it')
    if ic_sz:
        check_icon_bytes(d[a0 + ic_off:a0 + ic_off + ic_sz], 'embedded icon')
    elif a.require_icon:
        err('--require-icon: the NRO has no icon (libnx default will be used)')
    else:
        warn('no icon in the NRO; hbmenu and NTON will use the default libnx icon')
    if nc_sz != 0x4000:
        err('NACP is %d bytes, expected 16384' % nc_sz)
        return
    n = d[a0 + nc_off:a0 + nc_off + nc_sz]
    name, pub = cstr(n[0:0x200]), cstr(n[0x200:0x300])
    langs = sum(1 for i in range(16) if n[i * 0x300] != 0)
    ver_s = cstr(n[0x3060:0x3070])
    info('NACP: title %r, publisher %r, version %r, %d language entries' % (name, pub, ver_s, langs))
    if not name:
        err('NACP title is empty')
    if not pub:
        warn('NACP publisher is empty')
    if a.name and name != a.name:
        warn('NACP title is %r, expected %r' % (name, a.name))
    if a.author and pub != a.author:
        warn('NACP publisher is %r, expected %r' % (pub, a.author))
    usd, usj = struct.unpack_from('<QQ', n, 0x3080)
    dsd, dsj = struct.unpack_from('<QQ', n, 0x3090)
    if usd or dsd:
        info('NACP save data: user %d B + %d B journal, device %d B (fine for an NRO; NTON zeroes these in the NSP it builds)' % (usd, usj, dsd))
    if size_on_disk > nro_size + 0x20000 + 0x4000 + 0x100:
        warn('%d unexpected extra bytes after the ASET block' % (size_on_disk - nro_size))


# ------------------------------------------------------------------------------------------------------------ NSP / PFS0
def cmd_nsp(a):
    print('nsp: %s' % a.file)
    total = os.path.getsize(a.file)
    with open(a.file, 'rb') as f:
        head = f.read(0x10)
        if head[0:4] != b'PFS0':
            err('not a PFS0/NSP file (header %r)' % head[0:4])
            return
        count, strsz, _ = struct.unpack_from('<III', head, 4)
        if count == 0 or count > 4096:
            err('implausible file count %d' % count)
            return
        table = f.read(0x18 * count)
        strtab = f.read(strsz)
    if len(table) < 0x18 * count or len(strtab) < strsz:
        err('PFS0 header is truncated')
        return
    data_start = 0x10 + 0x18 * count + strsz
    entries, ends = [], []
    for i in range(count):
        off, size, noff, _ = struct.unpack_from('<QQII', table, 0x18 * i)
        end_name = strtab.find(b'\0', noff)
        name = strtab[noff:end_name if end_name >= 0 else None].decode('utf-8', 'replace')
        entries.append((name, data_start + off, size))
        ends.append(data_start + off + size)
        if '/' in name or '\\' in name or name.startswith('.'):
            err('suspicious entry name %r' % name)
        if data_start + off + size > total:
            err('entry %r extends past the end of the file (truncated?)' % name)
    names = [e[0] for e in entries]
    if len(set(names)) != len(names):
        err('duplicate entry names')
    ncas = [e for e in entries if e[0].endswith('.nca') and not e[0].endswith('.cnmt.nca')]
    meta = [e for e in entries if e[0].endswith('.cnmt.nca')]
    xmls = [e for e in entries if e[0].endswith('.xml')]
    tiks = [e for e in entries if e[0].endswith('.tik')]
    info('PFS0 with %d entries, %.2f MB; %d content NCA(s), %d meta NCA(s), %d xml, %d ticket(s)' % (
        count, total / 1048576, len(ncas), len(meta), len(xmls), len(tiks)))
    for n_, o_, s_ in sorted(entries, key=lambda e: -e[2])[:8]:
        print('           %-48s %10d B' % (n_, s_))
    if not meta:
        err('no *.cnmt.nca (meta NCA): the console cannot install this as a title')
    if len(ncas) < 2:
        err('only %d content NCA(s); an application needs at least a Program and a Control NCA' % len(ncas))
    if max(ends) < total:
        warn('%d byte(s) after the last entry' % (total - max(ends)))
    if tiks:
        warn('NSP contains a ticket: it is not standard-crypto, most installers need it imported too')
    if not xmls:
        warn('no cnmt.xml entry (not needed by the console, some installers/tools expect it)')


# ------------------------------------------------------------------------------------------------------------ SD layout
def cmd_layout(a):
    print('layout: %s' % a.root)
    folder = os.path.join(a.root, 'switch', a.folder)
    if not os.path.isdir(folder):
        err('missing folder %s' % folder)
        return
    nro = os.path.join(folder, a.nro)
    if not os.path.isfile(nro):
        err('missing %s' % nro)
    else:
        info('/switch/%s/%s present (%.1f MB)' % (a.folder, a.nro, os.path.getsize(nro) / 1048576))
        # the NSP forwarder has the path /switch/<folder>/<nro> built in: it must be exactly that
        a2 = argparse.Namespace(file=nro, name=None, author=None, require_icon=False, forbid_romfs=False)
        cmd_nro(a2)
    gdir = os.path.join(folder, a.game_dir) if (a.game_dir and not a.no_game) else None
    if gdir:
        if not os.path.isdir(gdir):
            warn('no %s folder (the game files are expected there)' % a.game_dir)
        else:
            files, big, total = 0, [], 0
            for dp, _, fn in os.walk(gdir):
                for f in fn:
                    p = os.path.join(dp, f)
                    files += 1
                    s = os.path.getsize(p)
                    total += s
                    if s >= 4 * 1024 ** 3:
                        big.append((os.path.relpath(p, gdir), s))
            info('%s: %d files, %.2f GB' % (a.game_dir, files, total / 1024 ** 3))
            for req in a.require or []:
                if not os.path.isfile(os.path.join(gdir, *req.replace('\\', '/').split('/'))):
                    err('required game file missing: %s\\%s' % (a.game_dir, req))
            for rel, s in big[:5]:
                warn('%s is %.2f GB: the SD card must be exFAT (FAT32 caps files at 4 GiB)' % (rel, s / 1024 ** 3))
    for sub in os.listdir(folder):
        if sub.lower().endswith(('.nro',)) and sub != a.nro:
            warn('extra NRO in the folder: %s (the forwarder only starts %s)' % (sub, a.nro))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('nro'); p.add_argument('file'); p.add_argument('--name'); p.add_argument('--author'); p.add_argument('--require-icon', action='store_true'); p.add_argument('--forbid-romfs', action='store_true'); p.set_defaults(fn=cmd_nro)
    p = sp.add_parser('icon'); p.add_argument('file'); p.set_defaults(fn=cmd_icon)
    p = sp.add_parser('nsp'); p.add_argument('file'); p.set_defaults(fn=cmd_nsp)
    p = sp.add_parser('layout'); p.add_argument('root'); p.add_argument('--folder', required=True); p.add_argument('--nro', required=True)
    p.add_argument('--game-dir', default='game'); p.add_argument('--no-game', action='store_true'); p.add_argument('--require', nargs='*'); p.set_defaults(fn=cmd_layout)
    a = ap.parse_args()
    try:
        a.fn(a)
    except (OSError, struct.error) as e:
        print('  [ERROR] cannot read: %s' % e)
        return 2
    print('  result: %d error(s), %d warning(s)' % (len(ERR), len(WARN)))
    return 1 if ERR else 0


if __name__ == '__main__':
    sys.exit(main())
