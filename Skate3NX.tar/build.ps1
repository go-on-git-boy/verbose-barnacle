<#
.SYNOPSIS
  Windows build driver for the Skate 3 Recomp -> Switch (.nro) port.

.DESCRIPTION
  Stages (run one or several with -Stage, or -Stage All):
    Prereqs  Check the Windows toolchain (devkitA64+libnx, CMake, Ninja, Clang, Python, Git, RAM)
             and INSTALL whatever is missing (winget + devkitPro), after one confirmation.
             Runs automatically before any other stage unless -SkipPrereqs / -NoInstall.
    Extract  Unpack -IsoPath (Xbox 360 .iso, or a .7z/.zip/.rar containing it, e.g. the Vimm download) to out\game,
             like skate3recomp's "Select ISO" installer. 7-Zip is installed via winget when an archive is used.
             Skipped when -GameDir is given or the same ISO was already extracted.
    Fetch    Clone skate3recomp (pinned tag + submodule) and nfsmw-nx (pinned commit, reference only).
    Verify   Check the pinned SDK commit and that every rex/... header src/ includes exists.
    Codegen  Build the HOST (x86-64) project and run its `generate-all` target.
    Mesa     Clone mesa-switch at the pinned commit, apply the patch, locate the NVK SDK folder.
    Nro      Cross-compile the `skate3` target with devkitA64 and find the .nro.
    Sd       Stage out\sd\switch\skate3-nx\ (and optionally copy it to a mounted SD card).

  STATUS (read this): written against the Phase 0 findings and nfsmw-nx's docs/building.md.
  NOT RUN: it was authored without a Windows machine or network. Prereqs, Fetch, Verify and Sd
  are plain git/filesystem logic. Codegen assumes a Windows CMake preset exists in skate3recomp
  (auto-detected, or pass -HostPreset). Mesa is only partly automated: the actual driver build
  (MSYS2 MINGW64 + Rust) is described in nfsmw-nx mesa/README.md, which has not been read yet.
  Nro will fail until Phase 3/4 exist (Horizon SDK layer + a Switch target in skate3recomp's
  CMake); it checks for that and says what is missing instead of guessing.

  Downloads: missing tools come from winget (Git, CMake, Ninja, Python, LLVM, and for the Mesa
  build only: MSYS2, Rustup) and the official devkitPro installer from GitHub. Missing repos are
  cloned automatically by whichever stage needs them. You are asked once before any install.
  Nothing here downloads game data. -GameDir and -TitleUpdate are YOUR files, used in place.
  The script never touches an SD card unless you pass -SdRoot, and then it asks first.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File tools\build.ps1 -Stage Prereqs
  powershell -ExecutionPolicy Bypass -File tools\build.ps1 -Stage Fetch,Verify
  powershell -ExecutionPolicy Bypass -File tools\build.ps1 -Stage Codegen `
      -GameDir D:\dumps\skate3 -TitleUpdate D:\dumps\TU_12K2276_000000C000000.00000000000O3
#>
[CmdletBinding()]
param(
    [ValidateSet('Prereqs', 'Extract', 'Fetch', 'Verify', 'Codegen', 'Port', 'Mesa', 'Nro', 'SwitchFinal', 'Sd', 'All')]
    [string[]]$Stage = @('Prereqs'),

    # Working folder. Repos are cloned into it; outputs go to <WorkDir>\out.
    [string]$WorkDir = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path,

    # Your Skate 3 dump (contains default.xex and data\webkit\EAWebkit.xex).
    [string]$GameDir,
    # Alternative to -GameDir: your Skate 3 Xbox 360 ROM - a plain .iso, or the .7z/.zip/.rar download that contains it
    # (Vimm's Lair Xbox 360 vault #78455, "Skate 3", USA/Europe v1.0, delivered as .7z). The Extract stage unpacks the
    # archive with 7-Zip if needed, then extracts the game to <WorkDir>\out\game using the same XDVDFS method as
    # skate3recomp's own ISO installer.
    [string]$IsoPath,
    # Your Title Update 3 package file (TU_12K2276_000000C000000.00000000000O3).
    [string]$TitleUpdate,

    # CMake configure preset for the HOST codegen build. Auto-detected if omitted.
    [string]$HostPreset,
    # Use a different SDK checkout (e.g. your Horizon branch). Skips the SDK commit pin check.
    [string]$SdkDir,
    # Existing local skate3recomp checkout to use instead of cloning (auto-detected in common places if omitted).
    [string]$Skate3RecompDir,

    # <mesa-sdk>\opt\devkitpro\portlibs\switch  (must contain lib\libvulkan.a)
    [string]$MesaSdk,
    # Patch to apply to mesa-switch. Default: nfsmw-nx's mesa-switch-nfsmw.patch, UNMODIFIED.
    [string]$MesaPatch,
    # Optional script that performs the actual Mesa build; called with the mesa-switch dir.
    [string]$MesaBuildScript,

    # Switch CMake toolchain file. Default: <skate3recomp>\tools\switch\cmake\switch-devkitA64.cmake
    [string]$ToolchainFile,
    # Switch-capable ReXGlue SDK. Defaults to nfsmw-nx's proven Horizon/libnx SDK fork.
    [string]$SwitchSdkDir,
    # Use the UNZIPPED nfsmw-nx release instead of a git clone: point this at its sdk\ folder (e.g. ...\nfsmw-nx-1.0.0\sdk). Its
    # tools\ and mesa\ folders next to it supply the toolchain file and the Mesa patch.
    [string]$NfsSdkDir,
    [switch]$RebuildPort,                 # Port: regenerate out\horizon-sdk from scratch (discards your conflict fixes there!)
    [string]$UpstreamUrl = 'https://github.com/rexglue/rexglue-sdk.git',
    # Switch devkitA64 toolchain. Defaults to nfsmw-nx's tested toolchain.
    [string]$SwitchToolchainFile,
    [string]$NroTarget = 'skate3',
    [string[]]$ExtraCMakeArgs = @(),
    [int]$Jobs = 4,                       # compile jobs. If not given, chosen from the RAM budget below (nfsmw-nx: -j 4 on ~16 GB)
    # --- memory tuning: the devkitA64 compile + LTO link are RAM-bound, so spend RAM on parallelism ---
    [int]$MemoryBudgetGB = 20,            # most RAM the Switch build may plan to use (also capped at 85% of what is free right now)
    [int]$LtoJobs = 0,                    # parallel LTO workers at link time; 0 = choose from the budget (nfsmw-nx used 2 on ~16 GB)
    [switch]$NoMemoryTuning,              # keep the toolchain's own settings and nfsmw-nx's -j 4 / -flto=2

    [string]$ConfigToml,                  # your skate3-nx config TOML, copied if given
    [string]$SdRoot,                      # e.g. E:\  (mounted SD card). Asks before copying.
    # --- final Switch packaging (SwitchFinal stage) ---
    [string]$SdFolder = 'skate3-nx',       # /switch/<SdFolder>/<SdFolder>.nro on the SD card (nfsmw-nx uses /switch/nfsmw-nx/nfsmw-nx.nro)
    [string]$GameFolder = 'game',         # game files live in /switch/<SdFolder>/<GameFolder>/ (nfsmw-nx: game_root). UNVERIFIED for skate3recomp: set to what its app looks for
    [string]$IconPath,                    # optional 256x256 baseline JPEG for the NRO (defaults to tools\switch\skate3_icon.jpg); the on-console NSP generator reads it from the NRO
    [switch]$SkipNsp,                     # SwitchFinal: do not stage the on-console NSP generator
    [switch]$ForceSwitchSdk,              # Nro: build even if the Switch SDK lacks headers skate3recomp includes (will not link)
    [switch]$KeepIso,                     # keep the .iso unpacked from a .7z (otherwise it is deleted after extraction)
    [switch]$SkipGameCopy,                # stage everything except the multi-GB game\ folder
    [switch]$NoPause,                     # don't wait for SPACE after an error (the launcher passes this)
    [switch]$NoInstall,                   # only check prerequisites; never install anything
    [switch]$SkipPrereqs,                 # don't auto-run the prerequisite check before other stages
    [switch]$Yes                          # skip confirmation prompts (installs, -SdRoot copy)
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------- pins (from Phase 0 NOTES.md)
$Pin = @{
    SkateUrl    = 'https://github.com/mchughalex/skate3recomp.git'
    SkateTag    = 'v2.0.2'
    SkateCommit = 'f6e0ae87fdfe'
    SdkCommit   = '7eb0faf7787f'    # third_party/rexglue-sdk (mchughalex/rexglue-skate3, skate3-sdk-clean)
    NfsUrl      = 'https://github.com/StevensND/nfsmw-nx.git'
    NfsCommit   = '4e3ffc24fe80'
    UpstreamTag08 = 'v0.8.0'
    AppName     = 'Skate 3'
    AppAuthor   = 'Skate3Recomp'
    UpstreamTag10 = 'v0.10.0'
    MesaUrl     = 'https://github.com/danfromtico/mesa-switch.git'
    MesaCommit  = '1a8c1a66d6f'
    # No-Intro "Unofficial - Microsoft - Xbox 360 (Title Updates)" / Skate 3 (World) (v3), entry 5C087C2C\TU_12K2276_...O3
    TuName      = 'TU_12K2276_000000C000000.00000000000O3'
    TuSize      = 1773568
    TuSha1      = '0e362b6d2483317605302e64542ef29c411871ca'
}

# ---------------------------------------------------------------- local-first discovery (runs before any clone/install)
# Pure functions (no helpers defined later), because they run at load time.
function Get-FixedDriveRoots {
    @([IO.DriveInfo]::GetDrives() | Where-Object { $_.DriveType -eq 'Fixed' } | ForEach-Object { $_.Name })
}

function Test-SkateRepo([string]$d) {
    if (-not $d -or -not (Test-Path -LiteralPath $d)) { return $false }
    return ((Test-Path -LiteralPath (Join-Path $d 'CMakePresets.json')) -and
            ((Test-Path -LiteralPath (Join-Path $d 'src\skate3_app_common.cpp')) -or (Test-Path -LiteralPath (Join-Path $d 'cmake\CodegenTargets.cmake'))))
}

function Get-RepoSearchDirs([string]$Name) {
    $c = @("$WorkDir\$Name", "$PSScriptRoot\$Name", "$(Split-Path $WorkDir -Parent)\$Name", "$(Split-Path $PSScriptRoot -Parent)\$Name",
           "$env:USERPROFILE\$Name", "$env:USERPROFILE\source\repos\$Name", "$env:USERPROFILE\Documents\GitHub\$Name",
           "$env:USERPROFILE\Desktop\$Name", "$env:USERPROFILE\Downloads\$Name")
    foreach ($r in (Get-FixedDriveRoots)) { $c += (Join-Path $r $Name) }
    return $c
}

function Find-Skate3Recomp {
    if ($Skate3RecompDir) { if (Test-SkateRepo $Skate3RecompDir) { return (Resolve-Path -LiteralPath $Skate3RecompDir).Path } else { return $null } }
    # the scripts may live inside the repo (tools\ under it) or next to it
    $cands = @($WorkDir, (Split-Path $PSScriptRoot -Parent)) + (Get-RepoSearchDirs 'skate3recomp')
    foreach ($d in ($cands | Where-Object { $_ } | Select-Object -Unique)) { if (Test-SkateRepo $d) { return (Resolve-Path -LiteralPath $d).Path } }
    return $null
}

function Find-LocalRepo([string]$Name, [string]$Marker, [string]$Beside) {
    $cands = @(Get-RepoSearchDirs $Name)
    if ($Beside) { $cands = @("$(Split-Path $Beside -Parent)\$Name", "$Beside\third_party\$Name") + $cands }
    foreach ($d in ($cands | Where-Object { $_ } | Select-Object -Unique)) {
        if ((Test-Path -LiteralPath (Join-Path $d '.git')) -and (Test-Path -LiteralPath (Join-Path $d $Marker))) { return (Resolve-Path -LiteralPath $d).Path }
    }
    return $null
}

# ---------------------------------------------------------------- paths
$SkateFound = Find-Skate3Recomp
if ($SkateFound)            { $Skate = $SkateFound;        $SkateIsLocal = $true }
elseif ($Skate3RecompDir)   { $Skate = $Skate3RecompDir;   $SkateIsLocal = $false }
else                        { $Skate = Join-Path $WorkDir 'skate3recomp'; $SkateIsLocal = $false }
$NfsFound  = Find-LocalRepo 'nfsmw-nx' 'sdk\CMakeLists.txt' $Skate
$Nfs       = if ($NfsFound)  { $NfsFound }  else { Join-Path $WorkDir 'nfsmw-nx' };    $NfsIsLocal  = [bool]$NfsFound
$NfsFromFolder = [bool]$NfsSdkDir
if ($NfsFromFolder) {
    if (-not (Test-Path -LiteralPath (Join-Path $NfsSdkDir 'cmake\rexglue_switch.cmake'))) { throw "-NfsSdkDir '$NfsSdkDir' has no cmake\rexglue_switch.cmake - point it at the sdk folder of nfsmw-nx" }
    $NfsSdkDir = (Resolve-Path -LiteralPath $NfsSdkDir).Path
    $Nfs = Split-Path $NfsSdkDir -Parent          # release root: contains sdk\, tools\, mesa\
}
$MesaFound = Find-LocalRepo 'mesa-switch' 'meson.build' $Skate
$MesaSrc   = if ($MesaFound) { $MesaFound } else { Join-Path $WorkDir 'mesa-switch' }; $MesaIsLocal = [bool]$MesaFound
$Out       = Join-Path $WorkDir 'out'
$LogDir    = Join-Path $Out 'logs'
$NroBuild  = Join-Path $Out 'nro'
$SdStage   = Join-Path $Out ('sd\switch\' + $SdFolder)
$SdNroName = $SdFolder + '.nro'
$SdNroPath = '/switch/' + $SdFolder + '/' + $SdNroName      # the path an NSP forwarder has built in
$SwitchFinal = Join-Path $Out 'SWITCHFINAL'
if (-not $SdkDir)        { $SdkDir = Join-Path $Skate 'third_party\rexglue-sdk'; $SdkIsPinned = $true } else { $SdkIsPinned = $false }
if (-not $MesaSdk) {
    # mesa-switch's build-unified.sh installs into <mesa-switch>\mesa-unified-install (see nfsmw-nx mesa/build_mesa_msys2.sh)
    $mesaBuilt = Join-Path $MesaSrc 'mesa-unified-install\opt\devkitpro\portlibs\switch'
    if (Test-Path -LiteralPath (Join-Path $mesaBuilt 'lib\libvulkan.a')) { $MesaSdk = $mesaBuilt } else { $MesaSdk = Join-Path $Out 'mesa-sdk\opt\devkitpro\portlibs\switch' }
}
# Game icon: the bundled 256x256 baseline JPEG (tools\switch\skate3_icon.jpg, made from the supplied Skate 3 art) unless -IconPath is given.
if (-not $IconPath) {
    $bundledIcon = Join-Path $PSScriptRoot 'switch\skate3_icon.jpg'
    if (Test-Path -LiteralPath $bundledIcon) { $IconPath = $bundledIcon }
}
$PortSdk = Join-Path $Out 'horizon-sdk'
$PortReport = Join-Path $Out 'horizon-port'
$SwitchSdkExplicit = [bool]$SwitchSdkDir
if (-not $SwitchSdkDir) {
    # Preferred: the Horizon layer ported onto the Skate SDK fork (Port stage). Fallback: nfsmw-nx's own SDK (v0.10 line).
    if (Test-Path -LiteralPath (Join-Path $PortSdk 'cmake\rexglue_switch.cmake')) { $SwitchSdkDir = $PortSdk } else { $SwitchSdkDir = Join-Path $Nfs 'sdk' }   # with -NfsSdkDir, $Nfs is the release root, so this is that sdk folder
}
if (-not $SwitchToolchainFile) { $SwitchToolchainFile = Join-Path $Nfs 'tools\switch\cmake\switch-devkitA64.cmake' }
# Retain the old parameter as an explicit override for compatibility with earlier scripts.
if ($ToolchainFile) { $SwitchToolchainFile = $ToolchainFile }
if (-not $MesaPatch)     { $MesaPatch = Join-Path $Nfs 'mesa\mesa-switch-nfsmw.patch' }

$JobsAuto = -not $PSBoundParameters.ContainsKey('Jobs')      # decided in Stage-Nro from the memory plan

# ---------------------------------------------------------------- helpers
function Write-Step($m) { Write-Host "`n== $m" -ForegroundColor Cyan }
function Write-Ok($m)   { Write-Host "  [ok]   $m" -ForegroundColor Green }
function Write-Warn2($m){ Write-Host "  [warn] $m" -ForegroundColor Yellow }
function Fail($m)       { throw $m }

function Invoke-Native {
    param([Parameter(Mandatory)][string]$Exe, [string[]]$ArgList = @(), [switch]$AllowFail)
    # Git is the one tool here with a real RAM-for-speed setting: the delta-base cache defaults to 96 MB, which makes
    # checkouts of large repositories (FFmpeg, mesa) re-inflate the same objects. 2 GB is a small slice of the budget.
    if ($Exe -eq 'git' -and -not $NoMemoryTuning) { $ArgList = @('-c', 'core.deltaBaseCacheLimit=2g') + $ArgList }
    Write-Host "  > $Exe $($ArgList -join ' ')" -ForegroundColor DarkGray
    # Route the tool's stdout+stderr through Write-Host so it lands in the log file too
    # (PowerShell 5.1 transcripts do not record native output otherwise). 'Continue' stops stderr lines
    # from being turned into terminating errors; the exit code decides success.
    $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $Script:LastNativeOutput = New-Object System.Collections.ArrayList
    try {
        & $Exe @ArgList 2>&1 | ForEach-Object {
            $txt = if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.Exception.Message } else { "$_" }
            Write-Host $txt
            if ($Script:LastNativeOutput.Count -lt 600) { [void]$Script:LastNativeOutput.Add($txt) }
        }
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $eap }
    if ($AllowFail) { return $code }
    if ($code -ne 0) { Fail "'$Exe' exited with code $code (its output is above)" }
}

function Get-Tool([string]$Name) {
    $c = Get-Command $Name -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($c) { return $c.Source } else { return $null }
}

function Get-Ver([string]$Text) {
    if ($Text -match '(\d+)\.(\d+)(?:\.(\d+))?') { return [version]("{0}.{1}" -f $Matches[1], $Matches[2]) }
    return $null
}

function Get-SubmodulePaths([string]$Repo) {
    # Submodule paths declared in <Repo>\.gitmodules (works even when 'git submodule status' prints nothing).
    if (-not (Test-Path -LiteralPath (Join-Path $Repo '.gitmodules'))) { return @() }
    $found = @()
    $lines = @(& git -C $Repo config -f .gitmodules --get-regexp '^submodule\..*\.path$' 2>$null)
    foreach ($l in $lines) { if ("$l" -match '^submodule\..+\.path (.+)$') { $found += $Matches[1].Trim() } }
    return $found
}

function Get-SubmoduleName([string]$Owner, [string]$Rel) {
    $lines = @(& git -C $Owner config -f .gitmodules --get-regexp '^submodule\..*\.path$' 2>$null)
    foreach ($l in $lines) { if ("$l" -match '^submodule\.(.+)\.path (.+)$' -and $Matches[2].Trim() -eq $Rel) { return $Matches[1] } }
    return $Rel
}

function Resolve-SubmoduleStandIn {
    # The commit a submodule is pinned to can disappear from its upstream (typically a force-pushed branch such as imgui's
    # 'docking'); GitHub then answers "not our ref" and no clone of the SDK can fetch it any more. As a stand-in we take
    # the newest commit on the submodule's branch (.gitmodules branch, then docking, master, main) that is not newer than
    # the moment the pin was recorded. This is an APPROXIMATION of what the author built against, and is reported as such.
    param([string]$Owner, [string]$Rel)
    $sub  = Join-Path $Owner $Rel.Replace('/', '\')
    $name = Get-SubmoduleName $Owner $Rel
    $pinLine = @(& git -C $Owner ls-tree HEAD -- $Rel 2>$null) | Select-Object -First 1
    $pinSha = ''
    if ("$pinLine" -match '^160000 commit ([0-9a-f]{40})') { $pinSha = $Matches[1] }
    $pinDate = (@(& git -C $Owner log -1 --format=%cI HEAD -- $Rel 2>$null) | Select-Object -First 1)
    if (-not $pinDate) { $pinDate = (@(& git -C $Owner log -1 --format=%cI HEAD 2>$null) | Select-Object -First 1) }
    $url = (@(& git -C $Owner config -f .gitmodules --get "submodule.$name.url" 2>$null) | Select-Object -First 1)
    $cfgBranch = (@(& git -C $Owner config -f .gitmodules --get "submodule.$name.branch" 2>$null) | Select-Object -First 1)
    Write-Host "  --- stand-in search for $Rel ---"
    Write-Host "  url:           $url"
    Write-Host "  pinned commit: $pinSha  (not available from that url)"
    Write-Host "  pin recorded:  $pinDate"

    if (-not (Test-Path -LiteralPath (Join-Path $sub '.git'))) {
        Fail "$Rel : the clone failed before any files were fetched (network / URL problem), so no stand-in can be chosen. See the git output above."
    }
    $branches = @($cfgBranch, 'docking', 'master', 'main') | Where-Object { $_ } | Select-Object -Unique
    foreach ($b in $branches) {
        $rc = Invoke-Native git @('-C', $sub, 'fetch', '--quiet', 'origin', $b) -AllowFail
        if ($rc -ne 0) { Write-Host "  branch '$b': not available"; continue }
        $pick = (@(& git -C $sub rev-list -1 "--before=$pinDate" FETCH_HEAD 2>$null) | Select-Object -First 1)
        if (-not $pick) { Write-Host "  branch '$b': no commit older than the pin date"; continue }
        Invoke-Native git @('-C', $sub, 'checkout', '--quiet', '--detach', $pick)
        $short = $pick.Substring(0, 12)
        Write-Warn2 "$Rel : pinned commit $($pinSha.Substring(0, [math]::Min(12, $pinSha.Length))) is gone upstream. Using $short (newest on '$b' as of $pinDate) as a stand-in."
        Write-Warn2 "If compiling the SDK later fails inside $Rel, this stand-in is the first suspect."
        [void]$Script:StandIns.Add("$Rel -> $short ($b @ $pinDate)")
        return
    }
    Fail "$Rel : pinned commit $pinSha is unavailable and no stand-in could be found on: $($branches -join ', ')"
}

function Resolve-UnpinnedSubmodule {
    # A submodule that .gitmodules declares and the SDK's CMake needs, but whose commit is NOT recorded in the SDK commit
    # (no gitlink in the tree - `git submodule update` silently does nothing for it; seen with thirdparty\o1heap in the
    # Skate fork). Clone it from its .gitmodules URL and use the newest commit not newer than the SDK commit itself.
    param([string]$Owner, [string]$Rel)
    $sub  = Join-Path $Owner $Rel.Replace('/', '\')
    $name = Get-SubmoduleName $Owner $Rel
    $url  = (@(& git -C $Owner config -f .gitmodules --get "submodule.$name.url" 2>$null) | Select-Object -First 1)
    $cfgBranch = (@(& git -C $Owner config -f .gitmodules --get "submodule.$name.branch" 2>$null) | Select-Object -First 1)
    $date = (@(& git -C $Owner log -1 --format=%cI HEAD 2>$null) | Select-Object -First 1)
    if (-not $url) { Fail "$Rel : declared in .gitmodules without a url and not pinned by the SDK commit - cannot download it" }
    Write-Warn2 "$Rel is declared in .gitmodules but this SDK commit does not pin a version of it - cloning $url and picking a version by date"
    if (Test-Path -LiteralPath $sub) {
        $left = @(Get-ChildItem -LiteralPath $sub -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne '.git' })
        if ($left.Count -eq 0) { Remove-Item -LiteralPath $sub -Recurse -Force }
        else { Fail "$sub is not empty - not touching it" }
    }
    Invoke-Native git @('clone', '--quiet', $url, $sub)
    $ref = 'HEAD'
    if ($cfgBranch) { $ref = "origin/$cfgBranch" }
    $pick = $null
    if ($date) { $pick = (@(& git -C $sub rev-list -1 "--before=$date" $ref 2>$null) | Select-Object -First 1) }
    if (-not $pick) { $pick = (@(& git -C $sub rev-parse $ref 2>$null) | Select-Object -First 1) }
    if (-not $pick) { Fail "$Rel : cloned, but could not choose a commit" }
    Invoke-Native git @('-C', $sub, 'checkout', '--quiet', '--detach', $pick)
    $short = $pick.Substring(0, 12)
    Write-Warn2 "$Rel : using $short (newest as of $date). The SDK does not say which version it wants."
    [void]$Script:StandIns.Add("$Rel -> $short (unpinned, as of $date)")
}

function Test-SubmoduleWorktree([string]$Owner, [string]$Rel) {
    # `git submodule update` can return 0 when the submodule repository is initialized
    # but its working tree is still empty (for example after a stale/incomplete checkout).
    # Do not treat that state as success: CMake needs the actual files.
    $dir = Join-Path $Owner $Rel.Replace('/', '\')
    if (-not (Test-Path -LiteralPath $dir)) { return $false }
    $items = @(Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue |
               Where-Object { $_.Name -ne '.git' })
    return ($items.Count -gt 0)
}

function Update-OneSubmodule {
    param([string]$Owner, [string]$Rel)
    # No gitlink recorded for this path in the owner's commit -> `submodule update` would do nothing at all.
    $pin = (@(& git -C $Owner ls-tree HEAD -- $Rel 2>$null) | Select-Object -First 1)
    if ("$pin" -notmatch '^160000 commit') { Resolve-UnpinnedSubmodule $Owner $Rel; return }

    Invoke-Native git @('-C', $Owner, 'submodule', 'sync', '--', $Rel)
    $rc = Invoke-Native git @('-C', $Owner, 'submodule', 'update', '--init', '--', $Rel) -AllowFail

    # IMPORTANT: a zero exit status is not enough. Some Git/submodule states leave only
    # the .git metadata directory/file behind, which made the old build script retry the
    # same "successful" update six times and then fail Assert-SdkThirdparty.
    if ($rc -eq 0 -and (Test-SubmoduleWorktree $Owner $Rel)) { return }

    if ($rc -eq 0) {
        Write-Warn2 "$Rel reported success but its working tree is empty; forcing a real checkout"
    } else {
        Write-Warn2 "$Rel could not be checked out at its pinned commit (git exit $rc); forcing a real checkout"
    }

    # First repair the existing Git submodule metadata. --force/--checkout handles
    # partially initialized submodules without changing the parent repository.
    $repair = Invoke-Native git @('-C', $Owner, 'submodule', 'update', '--init', '--force', '--checkout', '--', $Rel) -AllowFail
    if ($repair -eq 0 -and (Test-SubmoduleWorktree $Owner $Rel)) {
        Write-Ok "$Rel checked out"
        return
    }

    # If Git still leaves an empty worktree, use the exact gitlink commit directly.
    # This is safe here because the directory is known to be empty apart from .git.
    Write-Warn2 "$Rel is still empty after forced checkout; cloning the exact pinned commit directly"
    $sub = Join-Path $Owner $Rel.Replace('/', '\')
    $name = Get-SubmoduleName $Owner $Rel
    $url = (@(& git -C $Owner config -f .gitmodules --get "submodule.$name.url" 2>$null) | Select-Object -First 1)
    $pinSha = ''
    if ("$pin" -match '^160000 commit ([0-9a-f]{40})') { $pinSha = $Matches[1] }
    if (-not $url -or -not $pinSha) {
        Fail "$Rel : cannot repair empty submodule; missing .gitmodules URL or pinned commit"
    }

    if (Test-Path -LiteralPath $sub) {
        $left = @(Get-ChildItem -LiteralPath $sub -Force -ErrorAction SilentlyContinue |
                  Where-Object { $_.Name -ne '.git' })
        if ($left.Count -gt 0) {
            Fail "$sub is not empty; refusing to replace it"
        }
        Remove-Item -LiteralPath $sub -Recurse -Force
    }

    Invoke-Native git @('clone', '--quiet', $url, $sub)
    $rcFetch = Invoke-Native git @('-C', $sub, 'fetch', '--quiet', 'origin', $pinSha) -AllowFail
    if ($rcFetch -ne 0) {
        # The pinned commit no longer exists upstream (force-pushed branch, e.g. imgui 'docking').
        Write-Warn2 "$Rel : pinned commit $($pinSha.Substring(0, 12)) is not available from $url - choosing a stand-in by date"
        Resolve-SubmoduleStandIn $Owner $Rel
        return
    }
    Invoke-Native git @('-C', $sub, 'checkout', '--quiet', '--detach', $pinSha)
    if (-not (Test-SubmoduleWorktree $Owner $Rel)) {
        Fail "$Rel : direct checkout completed but the worktree is still empty"
    }
    Write-Ok "$Rel checked out at $($pinSha.Substring(0, 12))"
}

function Initialize-MissingSubmodules {
    # Checks out every submodule whose folder is empty/missing, including the nested ones inside the SDK
    # (thirdparty\spdlog, xxHash, snappy, volk, Vulkan headers, ...). Driven by the .gitmodules files, so it does not
    # depend on 'git submodule status'. Folders that already have content are never touched - your own commits or
    # branches inside them are safe. Repeats because a freshly checked-out submodule can contain more submodules.
    param([string]$Repo)
    if (-not (Test-Path (Join-Path $Repo '.git'))) { Write-Warn2 "$Repo is not a git checkout - submodules not checked"; return }
    $checked = 0; $fetched = New-Object System.Collections.ArrayList
    for ($pass = 0; $pass -lt 6; $pass++) {
        $queue = New-Object System.Collections.Queue
        $queue.Enqueue($Repo)
        $did = $false; $checked = 0
        while ($queue.Count -gt 0) {
            $owner = $queue.Dequeue()
            foreach ($rel in (Get-SubmodulePaths $owner)) {
                $checked++
                $dir = Join-Path $owner $rel.Replace('/', '\')
                $filled = $false
                if (Test-Path -LiteralPath $dir) {
                    $items = @(Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne '.git' })
                    $filled = ($items.Count -gt 0)
                }
                if (-not $filled) {
                    Write-Host "  submodule not checked out (downloading): $dir"
                    Update-OneSubmodule $owner $rel
                    [void]$fetched.Add($rel); $did = $true
                }
                if (Test-Path -LiteralPath (Join-Path $dir '.git')) { $queue.Enqueue($dir) }
            }
        }
        if (-not $did) { break }
    }
    Write-Ok ("submodules of {0}: {1} checked, {2} downloaded this run" -f (Split-Path $Repo -Leaf), $checked, $fetched.Count)
    foreach ($si in $Script:StandIns) { Write-Warn2 "stand-in in use: $si" }
}


function Apply-SdkCompatibilityPatches {
    # rexglue-sdk 7eb0faf7787f expects the old ImGui ImFontConfig::RasterizerGamma
    # member. The vendored/current ImGui used by this checkout no longer exposes
    # that member, so imgui_drawer.cpp fails at the two assignments below.
    #
    # The upstream SDK code only used these assignments to tune the legacy
    # rasterizer. Removing them is the correct compatibility fix for the newer
    # ImGui API; do not substitute RasterizerMultiply because it has different
    # semantics.
    param([string]$Sdk)

    $file = Join-Path $Sdk 'src\ui\imgui_drawer.cpp'
    if (-not (Test-Path -LiteralPath $file)) {
        Fail "ImGui compatibility patch: source file not found: $file"
    }

    $text = [IO.File]::ReadAllText($file)
    $patterns = @(
        '(?m)^[ \t]*config\.RasterizerGamma[ \t]*=[ \t]*0\.62f;[ \t]*\r?\n',
        '(?m)^[ \t]*config_on_light\.RasterizerGamma[ \t]*=[ \t]*1\.0f;[ \t]*\r?\n'
    )

    $changed = 0
    foreach ($pattern in $patterns) {
        $newText = [regex]::Replace($text, $pattern, '')
        if ($newText -ne $text) {
            $changed++
            $text = $newText
        }
    }

    if ($changed -gt 0) {
        [IO.File]::WriteAllText($file, $text, [Text.UTF8Encoding]::new($false))
        Write-Warn2 "Applied ImGui compatibility fix: removed $changed obsolete RasterizerGamma assignment(s) from src\ui\imgui_drawer.cpp"
    } else {
        # Make this safe to run repeatedly, but don't silently accept a different
        # source layout where the expected incompatibility is still present.
        if ($text -match 'RasterizerGamma') {
            Fail "ImGui compatibility patch: RasterizerGamma is still present in $file but did not match the expected assignments. Inspect the file before building."
        }
        Write-Ok 'ImGui compatibility fix already applied (no RasterizerGamma assignments remain)'
    }
}

function Assert-SdkThirdparty {
    # Fail early, with evidence, instead of letting CMake print 15 errors.
    param([string]$Sdk)
    $need = @('thirdparty\xxHash\cmake_unofficial\CMakeLists.txt', 'thirdparty\spdlog\CMakeLists.txt', 'thirdparty\snappy\CMakeLists.txt',
              'thirdparty\utfcpp\CMakeLists.txt', 'thirdparty\vulkan-headers\CMakeLists.txt',
              'thirdparty\vulkan-memory-allocator\CMakeLists.txt', 'thirdparty\volk\CMakeLists.txt', 'thirdparty\o1heap\o1heap\o1heap.c')
    $missing = @($need | Where-Object { -not (Test-Path -LiteralPath (Join-Path $Sdk $_)) })
    if (-not $missing.Count) { Write-Ok 'SDK third-party libraries are present'; return }
    Write-Warn2 "SDK third-party files still missing: $($missing -join ', ')"
    Write-Host "  --- diagnostics for $Sdk ---"
    Write-Host ("  .gitmodules present: {0}" -f (Test-Path -LiteralPath (Join-Path $Sdk '.gitmodules')))
    Write-Host ("  .git present:        {0}" -f (Test-Path -LiteralPath (Join-Path $Sdk '.git')))
    $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try {
        Write-Host '  git submodule status:'
        & git -C $Sdk submodule status 2>&1 | ForEach-Object { Write-Host "    $_" }
        Write-Host '  submodule urls:'
        & git -C $Sdk config -f .gitmodules --get-regexp 'url' 2>&1 | ForEach-Object { Write-Host "    $_" }
    } finally { $ErrorActionPreference = $eap }
    if (Test-Path -LiteralPath (Join-Path $Sdk 'thirdparty')) {
        Write-Host '  thirdparty folder contents (entries per folder):'
        Get-ChildItem -LiteralPath (Join-Path $Sdk 'thirdparty') -Directory | ForEach-Object {
            $n = @(Get-ChildItem -LiteralPath $_.FullName -Force | Where-Object { $_.Name -ne '.git' }).Count
            Write-Host ("    {0,-28} {1}" -f $_.Name, $n)
        }
    }
    Fail 'The SDK third-party libraries could not be checked out (see the diagnostics above). Check your internet connection / git access to GitHub, or run: git -C third_party\rexglue-sdk submodule update --init --recursive'
}

function Ensure-Repo {
    param([string]$Url, [string]$Dir, [string]$Rev, [switch]$Submodules, [switch]$Local)
    if ($Local) {
        # An existing checkout found on this machine: use it as-is. Never fetch/checkout/reset the user's own copy.
        Write-Ok "using local copy (not re-downloaded): $Dir"
        if (Test-Path (Join-Path $Dir '.git')) {
            $dirty = @(& git -C $Dir status --porcelain 2>$null).Count
            if ($dirty) { Write-Warn2 "$dirty uncommitted change(s) in $Dir - left untouched" }
            if ($Submodules) { Initialize-MissingSubmodules $Dir }
        }
        return
    }
    if (-not (Test-Path (Join-Path $Dir '.git'))) {
        Invoke-Native git @('clone', $Url, $Dir)
    }
    Invoke-Native git @('-C', $Dir, 'fetch', '--tags', '--quiet', 'origin')
    Invoke-Native git @('-C', $Dir, 'checkout', '--quiet', $Rev)
    if ($Submodules) { Invoke-Native git @('-C', $Dir, 'submodule', 'update', '--init', '--recursive') }
}

function Assert-HeadIs([string]$Dir, [string]$Prefix, [string]$What, [switch]$WarnOnly) {
    if (-not (Test-Path (Join-Path $Dir '.git'))) {
        if ($WarnOnly) { Write-Warn2 "$What : not a git checkout, can't verify the pinned commit ($Prefix...)"; return }
        Fail "$What : $Dir is not a git checkout"
    }
    $head = (& git -C $Dir rev-parse HEAD).Trim()
    if (-not $head.StartsWith($Prefix)) {
        if ($WarnOnly) { Write-Warn2 "$What is at $($head.Substring(0, 12)); the pinned commit is $Prefix. Using your local copy as-is."; return }
        Fail "$What is at $head, expected $Prefix..."
    }
    Write-Ok "$What = $($head.Substring(0, 12))"
}

function Set-DevkitEnv {
    if (-not $env:DEVKITPRO) { $env:DEVKITPRO = 'C:/devkitPro' }
    $env:DEVKITA64 = "$($env:DEVKITPRO)/devkitA64"
    $add = @("$($env:DEVKITPRO)\devkitA64\bin", "$($env:DEVKITPRO)\tools\bin")
    foreach ($p in $add) { if (($env:Path -split ';') -notcontains $p) { $env:Path = "$p;$env:Path" } }
}

# ---------------------------------------------------------------- stages
function Update-SessionPath {
    # Pick up PATH changes made by installers in this same session.
    $m = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $u = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$m;$u"
    $extra = @("$env:USERPROFILE\.cargo\bin", "$env:LOCALAPPDATA\Microsoft\WinGet\Links", 'C:\Program Files\LLVM\bin', 'C:\Program Files\7-Zip')
    foreach ($e in $extra) { if ((Test-Path $e) -and (($env:Path -split ';') -notcontains $e)) { $env:Path += ";$e" } }
    Set-DevkitEnv
    Remove-MsysFromPath
    foreach ($d in $Script:ChosenDirs) { Add-ToPath $d }       # tools picked by Find-LocalTool stay first
}

$Script:ChosenDirs = New-Object System.Collections.ArrayList
$Script:MsysPattern = '\\(msys64|msys32|msys2|cygwin64|cygwin)\\'
$Script:MsysWarned = $false
$Script:StandIns = New-Object System.Collections.ArrayList
$Script:GpuShown = $false
$Script:LastNativeOutput = New-Object System.Collections.ArrayList
$Script:VsEnvLoaded = $false

function Remove-MsysFromPath {
    # devkitPro's installer puts C:\devkitPro\msys2\usr\bin on the system PATH. That folder has its own cmake.exe/git.exe/
    # python, which shadow the native Windows tools. The host build must use Windows CMake (nfsmw-nx docs: "Windows
    # CMake, not the MSYS one"), so MSYS/Cygwin bin folders are removed from THIS session's PATH (your system PATH is
    # not changed). devkitPro's bash is always called by full path, so nothing else needs them.
    $parts = @($env:Path -split ';' | Where-Object { $_ })
    $drop  = @($parts | Where-Object { ($_ + '\') -match $Script:MsysPattern })
    if ($drop.Count) {
        $env:Path = (@($parts | Where-Object { $drop -notcontains $_ }) -join ';')
        if (-not $Script:MsysWarned) { Write-Warn2 ("MSYS folders removed from this session's PATH so Windows tools are used: " + ($drop -join ', ')); $Script:MsysWarned = $true }
    }
}

function Test-ToolVer([string]$Name, [string]$Min) {
    $exe = Get-Tool $Name
    if (-not $exe) { return $false }
    try { $line = (& $exe --version 2>&1 | Select-Object -First 1) } catch { return $false }
    $v = Get-Ver "$line"
    return [bool]($v -and $v -ge [version]$Min)
}

function Install-Winget([string]$Id) {
    if (-not (Get-Tool 'winget')) {
        Fail "winget not found, so I can't install $Id automatically. Install 'App Installer' from the Microsoft Store, or install it manually."
    }
    $common = @('--id', $Id, '-e', '--accept-source-agreements', '--accept-package-agreements', '--silent')
    & winget install @common
    if ($LASTEXITCODE -ne 0) { & winget upgrade @common }   # already installed but too old
}

function Test-DkpBase  { return (Test-Path (Join-Path $env:DEVKITPRO 'msys2\usr\bin\bash.exe')) }
function Test-DkpSwitch {
    return ((Test-Path (Join-Path $env:DEVKITPRO 'devkitA64\bin\aarch64-none-elf-gcc.exe')) -and
            (Test-Path (Join-Path $env:DEVKITPRO 'libnx')) -and
            [bool](Get-Tool 'elf2nro'))
}

function Install-DevkitPro {
    if (-not (Test-DkpBase)) {
        $exe = Find-LocalInstaller 'devkitProUpdater*.exe'
        if ($exe) { Write-Ok "using installer already on disk: $exe" }
        else {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $rel = Invoke-RestMethod 'https://api.github.com/repos/devkitPro/installer/releases/latest' -Headers @{ 'User-Agent' = 'skate3-nx-build' }
            $asset = $rel.assets | Where-Object { $_.name -match '^devkitProUpdater.*\.exe$' } | Select-Object -First 1
            if (-not $asset) { Fail 'Could not find devkitProUpdater*.exe in the latest devkitPro/installer release. Install devkitPro manually from https://devkitpro.org/wiki/Getting_Started' }
            $dl = Join-Path $Out 'downloads'
            New-Item -ItemType Directory -Force $dl | Out-Null
            $exe = Join-Path $dl $asset.name
            Write-Host "  downloading $($asset.browser_download_url)"
            Invoke-WebRequest $asset.browser_download_url -OutFile $exe -UseBasicParsing
        }
        Write-Host '  Launching the devkitPro installer. Accept the default install path (C:\devkitPro).'
        Write-Host '  Tick the Switch development components if offered; I will also run pacman for switch-dev after.'
        Start-Process $exe -Wait
        Update-SessionPath
    }
    if (-not (Test-DkpBase)) {
        Fail "devkitPro's MSYS2 not found at $env:DEVKITPRO\msys2. Finish the installer, then open its MSYS2 shell and run: pacman -S --needed switch-dev"
    }
    $bash = Join-Path $env:DEVKITPRO 'msys2\usr\bin\bash.exe'
    # switch-dev = devkitA64 + libnx + switch tools (elf2nro etc.). Command per devkitPro docs; not verified here.
    Invoke-Native $bash @('-lc', 'pacman -S --needed --noconfirm switch-dev')
    Update-SessionPath
}

function Install-Rustup {
    Install-Winget 'Rustlang.Rustup'
    Update-SessionPath
    if (Get-Tool 'rustup') { Invoke-Native rustup @('toolchain', 'install', 'stable-x86_64-pc-windows-gnu') }
}

$Script:ToolCache = @{}
$Script:KnownDirs = $null

function Get-KnownDirs {
    if ($Script:KnownDirs) { return $Script:KnownDirs }
    $pf = $env:ProgramFiles; $pf86 = ${env:ProgramFiles(x86)}; $lad = $env:LOCALAPPDATA
    $vs = @("$pf\Microsoft Visual Studio\*\*", "$pf86\Microsoft Visual Studio\*\*")      # VS bundles CMake, Ninja and LLVM
    $Script:KnownDirs = @{
        git    = @("$pf\Git\cmd", "$pf\Git\bin", "$lad\Programs\Git\cmd")
        cmake  = @("$pf\CMake\bin") + @($vs | ForEach-Object { "$_\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin" })
        ninja  = @("$pf\ninja", "$lad\Microsoft\WinGet\Links", "$lad\Programs\Python\Python3*\Scripts") + @($vs | ForEach-Object { "$_\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja" })
        python = @("$lad\Programs\Python\Python3*", "$pf\Python3*", 'C:\Python3*')
        clang  = @("$pf\LLVM\bin", 'C:\LLVM\bin') + @($vs | ForEach-Object { "$_\VC\Tools\Llvm\x64\bin" })
        sevenz = @("$pf\7-Zip", "$pf86\7-Zip", "$lad\Programs\7-Zip")
    }
    return $Script:KnownDirs
}

function Add-ToPath([string]$dir) {
    # Put $dir FIRST on this session's PATH (moving it if it is already further down).
    $rest = @($env:Path -split ';' | Where-Object { $_ -and ($_.TrimEnd('\\') -ne $dir.TrimEnd('\\')) })
    $env:Path = (@($dir) + $rest) -join ';'
}

function Get-ExeVersion([string]$exe) {
    try { $line = (& $exe --version 2>&1 | Select-Object -First 1) } catch { return $null }
    return (Get-Ver "$line")
}

function Find-LocalTool {
    # Looks for an already-installed tool BEFORE anything is downloaded:
    #   1) PATH   2) well-known install folders (incl. Visual Studio's bundled CMake/Ninja/LLVM)   3) the skate3recomp folder.
    # Returns the exe path (and adds its folder to this session's PATH) or $null.
    param([string]$Label, [string]$Exe, [string]$Min = '0.0', [string[]]$KnownDirs = @(), [switch]$NoVersion, [switch]$AllowMsys)
    if ($Script:ToolCache.ContainsKey($Label)) { return $Script:ToolCache[$Label] }
    $minV = [version]$Min
    # MSYS/Cygwin builds (e.g. C:\devkitPro\msys2\usr\bin\cmake.exe) are POSIX tools: they misread Windows paths and
    # cannot drive Clang/MSVC-style builds. They are skipped unless -AllowMsys (used for git as a last resort).
    $ok = {
        param($path)
        if (-not $AllowMsys -and ($path -match $Script:MsysPattern)) {
            Write-Warn2 "$Label : ignoring MSYS/Cygwin build at $path (a native Windows build is needed)"
            return $false
        }
        if ($NoVersion) { return $true }
        $v = Get-ExeVersion $path
        return [bool]($v -and $v -ge $minV)
    }
    $hit = $null; $where = ''
    foreach ($c in @(Get-Command $Exe -All -ErrorAction SilentlyContinue)) {
        if ($c.CommandType -eq 'Application' -and (& $ok $c.Source)) { $hit = $c.Source; $where = 'PATH'; break }
    }
    if (-not $hit) {
        foreach ($d in $KnownDirs) {
            foreach ($rd in @(Resolve-Path -Path $d -ErrorAction SilentlyContinue)) {          # globs allowed
                $cand = Join-Path $rd.Path $Exe
                if ((Test-Path -LiteralPath $cand) -and (& $ok $cand)) { $hit = $cand; $where = 'known install location'; break }
            }
            if ($hit) { break }
        }
    }
    if (-not $hit -and $SkateIsLocal -and (Test-Path -LiteralPath $Skate)) {
        $found = Get-ChildItem -LiteralPath $Skate -Recurse -Depth 4 -File -Filter $Exe -ErrorAction SilentlyContinue |
                 Where-Object { $_.FullName -notmatch '\\(\.git|generated|game|out)\\' }
        foreach ($f in $found) { if (& $ok $f.FullName) { $hit = $f.FullName; $where = 'skate3recomp folder'; break } }
    }
    if (-not $hit) { return $null }
    Add-ToPath (Split-Path $hit -Parent)
    [void]$Script:ChosenDirs.Add((Split-Path $hit -Parent))
    $Script:ToolCache[$Label] = $hit
    Write-Ok ("{0}: already present ({1}) {2}" -f $Label, $where, $hit)
    return $hit
}

function Find-LocalDevkitPro {
    if ($Script:ToolCache.ContainsKey('devkitPro')) { return $true }
    $cands = @()
    if ($env:DEVKITPRO) { $cands += ($env:DEVKITPRO -replace '/', '\') }
    foreach ($r in (Get-FixedDriveRoots)) { $cands += (Join-Path $r 'devkitPro') }
    $cands += "$env:USERPROFILE\devkitPro"
    if ($SkateIsLocal -and (Test-Path -LiteralPath $Skate)) {
        $g = Get-ChildItem -LiteralPath $Skate -Recurse -Depth 5 -File -Filter 'aarch64-none-elf-gcc.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($g) { $cands += (Split-Path (Split-Path (Split-Path $g.FullName -Parent) -Parent) -Parent) }     # <root>\devkitA64\bin\gcc -> <root>
    }
    $base = $null
    foreach ($c in ($cands | Where-Object { $_ } | Select-Object -Unique)) {
        if (Test-Path (Join-Path $c 'devkitA64\bin\aarch64-none-elf-gcc.exe')) {
            $env:DEVKITPRO = $c -replace '\\', '/'; Set-DevkitEnv
            if (Test-DkpSwitch) { $Script:ToolCache['devkitPro'] = $c; Write-Ok "devkitPro (devkitA64 + libnx + elf2nro): already present at $c"; return $true }
            if (-not $base) { $base = $c }
        } elseif (-not $base -and (Test-Path (Join-Path $c 'msys2\usr\bin\bash.exe'))) { $base = $c }
    }
    if ($base) {
        $env:DEVKITPRO = $base -replace '\\', '/'; Set-DevkitEnv
        Write-Warn2 "devkitPro found at $base but the Switch pieces (devkitA64 / libnx / elf2nro) are incomplete - will run pacman, not the full installer"
    }
    return $false
}

function Find-Msys2 {
    foreach ($r in (Get-FixedDriveRoots)) { $p = Join-Path $r 'msys64\usr\bin\bash.exe'; if (Test-Path $p) { Write-Ok "MSYS2: already present at $p"; return $true } }
    return $false
}

function Find-LocalInstaller([string]$Pattern) {
    # Reuse an installer that is already on disk instead of downloading it again.
    $dirs = @($PSScriptRoot, (Join-Path $Out 'downloads'), "$env:USERPROFILE\Downloads")
    if ($SkateIsLocal) { $dirs += $Skate }
    foreach ($d in $dirs) {
        if (Test-Path -LiteralPath $d) {
            $f = Get-ChildItem -LiteralPath $d -Recurse -Depth 2 -File -Filter $Pattern -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($f) { return $f.FullName }
        }
    }
    return $null
}

function Stage-Prereqs {
    Write-Step 'Prereqs (check, then install what is missing)'
    Update-SessionPath          # also removes MSYS/Cygwin bin folders from this session's PATH

    $needMesa = (($script:Plan -contains 'Mesa') -and -not (Test-MesaSdk))
    $kd = Get-KnownDirs
    Write-Host '  looking for existing installs first: PATH, standard install folders, then the skate3recomp folder'
    if ($SkateIsLocal) { Write-Ok "skate3recomp folder: $Skate" } else { Write-Host "  (no local skate3recomp found; it will be cloned to $Skate)" }
    $reqs = @(
        @{ Name = 'Git';              Test = { [bool](Find-LocalTool 'Git' 'git.exe' '2.30' -KnownDirs $kd.git) };    Install = { Install-Winget 'Git.Git' } }
        @{ Name = 'CMake >= 3.25';    Test = { [bool](Find-LocalTool 'CMake'  'cmake.exe'  '3.25' -KnownDirs $kd.cmake) };  Install = { Install-Winget 'Kitware.CMake' } }
        @{ Name = 'Ninja';            Test = { [bool](Find-LocalTool 'Ninja'  'ninja.exe'  '1.10' -KnownDirs $kd.ninja) };  Install = { Install-Winget 'Ninja-build.Ninja' } }
        @{ Name = 'Python >= 3.10';   Test = { [bool](Find-LocalTool 'Python' 'python.exe' '3.10' -KnownDirs $kd.python) }; Install = { Install-Winget 'Python.Python.3.12' } }
        @{ Name = 'Clang/LLVM >= 20'; Test = { [bool](Find-LocalTool 'Clang'  'clang.exe'  '20.0' -KnownDirs $kd.clang) };  Install = { Install-Winget 'LLVM.LLVM' } }
        @{ Name = 'devkitPro (devkitA64 + libnx + elf2nro)'; Test = { Find-LocalDevkitPro }; Install = { Install-DevkitPro } }
    )
    $need7z = ($IsoPath -and ($IsoPath -match '\.(7z|zip|rar)$') -and -not $GameDir)
    if ($need7z) {
        $reqs += @{ Name = '7-Zip (to unpack the ROM archive)'; Test = { [bool](Get-7z) }; Install = { Install-Winget '7zip.7zip' } }
    }
    if ($needMesa) {
        $reqs += @{ Name = 'MSYS2 (Mesa build)'; Test = { Find-Msys2 }; Install = { Install-Winget 'MSYS2.MSYS2' } }
        $reqs += @{ Name = 'Rust stable-x86_64-pc-windows-gnu (Mesa build)'
                    Test = { (Get-Tool 'rustup') -and ((& rustup toolchain list 2>$null) -match 'stable-x86_64-pc-windows-gnu') }
                    Install = { Install-Rustup } }
    }

    $missing = @($reqs | Where-Object { -not (& $_.Test) })

    if ($missing.Count) {
        $missing | ForEach-Object { Write-Warn2 "not found locally (PATH, standard folders, skate3recomp folder): $($_.Name)" }
        if ($NoInstall) { Fail "$($missing.Count) prerequisite(s) missing and -NoInstall was given." }
        if (-not $Yes) {
            $a = Read-Host "Install the $($missing.Count) missing item(s) above now (winget / devkitPro installer, may show UAC prompts)? (y/N)"
            if ($a -notmatch '^[yY]') { Fail 'Prerequisites missing; install them manually or re-run and answer y.' }
        }
        foreach ($r in $missing) {
            Write-Step "Installing $($r.Name) (not found locally)"
            & $r.Install
            Update-SessionPath
        }
        $still = @($missing | Where-Object { -not (& $_.Test) })
        if ($still.Count) {
            $still | ForEach-Object { Write-Warn2 "still missing after install: $($_.Name)" }
            Fail 'Some prerequisites are still missing. A new terminal may be needed for PATH changes; re-run the script.'
        }
    }

    # Informational checks
    $gcc = Join-Path $env:DEVKITPRO 'devkitA64\bin\aarch64-none-elf-gcc.exe'
    $gv = (& $gcc --version | Select-Object -First 1)
    Write-Ok "devkitA64: $gv"
    # nfsmw-nx used GCC 16; the Skate SDK fork has not been built with this toolchain yet.
    if ((Get-Ver $gv) -and (Get-Ver $gv).Major -lt 16) { Write-Warn2 'nfsmw-nx used devkitA64 GCC 16; yours is older (C++23 std::expected may fail).' }
    $ramGb = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 1)
    if ($ramGb -lt 15) { Write-Warn2 "RAM $ramGb GB; nfsmw-nx needed ~16 GB for the LTO link" } else { Write-Ok "RAM $ramGb GB" }
    [void](Show-MemoryPlan)
    # Inference, not from the README: Clang on Windows normally needs the MSVC runtime headers/libs and Windows SDK
    # (the host build includes D3D12 code). Warn only; nothing is auto-installed for this.
    $vsw = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    $vsOk = $false
    if (Test-Path $vsw) {
        $vsPath = & $vsw -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath 2>$null
        $vsOk = [bool]$vsPath
    }
    if ($vsOk) { Write-Ok 'Visual Studio C++ build tools (for Clang on Windows)' }
    else { Write-Warn2 'No Visual Studio C++ build tools / Windows SDK found. Clang on Windows usually needs them; if the host configure fails on missing headers/libs, install "Build Tools for Visual Studio" with the C++ workload.' }
    Write-Ok 'toolchain matches nfsmw-nx docs/building.md: devkitA64 + libnx, CMake 3.25+, Ninja, Git, Python 3.10+, Clang 20+ (MSYS2 + Rust only for the Mesa driver)'
    # Desktop / Documents / OneDrive are protected or synced folders on Windows; ninja's log rename can be refused there.
    $wsPaths = @($Skate, $WorkDir, $Out) | Where-Object { $_ }
    if (@($wsPaths | Where-Object { $_ -match '\\(Desktop|Documents|OneDrive[^\\]*)(\\|$)' }).Count) {
        Write-Warn2 'The workspace is under Desktop/Documents/OneDrive. If Ninja ever stops with "Permission denied" (Controlled folder access or a sync client), move the folders to a plain path such as C:\dev and re-run.'
    }
}

function Require-Repos {
    # Any stage that reads the repos clones them first if they are not there.
    if (-not (Test-Path (Join-Path $Skate '.git')) -or (-not $NfsFromFolder -and -not (Test-Path (Join-Path $Nfs '.git'))) -or
        ($SdkIsPinned -and -not (Test-Path (Join-Path $SdkDir 'include')))) {
        Write-Warn2 'repos not found locally - fetching them'
        Stage-Fetch
    }
}


# ---------------------------------------------------------------- ISO extraction (same method as skate3recomp's installer)
# Reimplementation of the documented behaviour of src/skate3_iso_installer.cpp (read via DeepWiki, source not read):
# probe XDVDFS volume offsets {0x0, 0xFB20, 0x20600, 0x2080000, 0xFD90000} for "MICROSOFT*XBOX*MEDIA" at +32 sectors,
# read root sector/size, walk the directory tree, reject unsafe paths, copy files with a 4 MB buffer, require default.xex.
$Script:IsoReaderSource = @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public class Skate3IsoReader : IDisposable
{
    const int Sector = 2048;
    static readonly long[] Offsets = new long[] { 0x0L, 0xFB20L, 0x20600L, 0x2080000L, 0xFD90000L };
    const string Magic = "MICROSOFT*XBOX*MEDIA";

    FileStream fs;
    long baseOff;
    public long PartitionOffset { get { return baseOff; } }
    public long TotalBytes;
    public List<string> Paths = new List<string>();
    public List<long> FileOffsets = new List<long>();
    public List<long> FileSizes = new List<long>();

    public static long ProbeOffset(string isoPath)
    {
        using (FileStream f = new FileStream(isoPath, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
            foreach (long o in Offsets)
            {
                long pos = o + 32L * Sector;
                if (pos + 20 > f.Length) continue;
                byte[] b = new byte[20];
                f.Position = pos;
                if (f.Read(b, 0, 20) == 20 && Encoding.ASCII.GetString(b) == Magic) return o;
            }
        }
        return -1;
    }

    public Skate3IsoReader(string isoPath)
    {
        fs = new FileStream(isoPath, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 20);
        bool found = false;
        uint rootSector = 0, rootSize = 0;
        foreach (long o in Offsets)
        {
            long pos = o + 32L * Sector;
            if (pos + 0x20 > fs.Length) continue;
            byte[] b = ReadAt(pos, 0x20);
            if (Encoding.ASCII.GetString(b, 0, 20) == Magic)
            {
                baseOff = o;
                rootSector = BitConverter.ToUInt32(b, 0x14);
                rootSize = BitConverter.ToUInt32(b, 0x18);
                found = true;
                break;
            }
        }
        if (!found) throw new InvalidDataException("No XDVDFS volume descriptor found (is this an Xbox 360 disc image?)");
        if (rootSize == 0 || rootSize > 64u * 1024u * 1024u) throw new InvalidDataException("Implausible root directory size " + rootSize);

        Queue<KeyValuePair<KeyValuePair<uint, uint>, string>> work = new Queue<KeyValuePair<KeyValuePair<uint, uint>, string>>();
        work.Enqueue(new KeyValuePair<KeyValuePair<uint, uint>, string>(new KeyValuePair<uint, uint>(rootSector, rootSize), ""));
        int dirCount = 0;
        while (work.Count > 0)
        {
            KeyValuePair<KeyValuePair<uint, uint>, string> item = work.Dequeue();
            if (++dirCount > 100000) throw new InvalidDataException("Too many directories (corrupt image?)");
            WalkDirectory(item.Key.Key, item.Key.Value, item.Value, work);
        }
    }

    byte[] ReadAt(long pos, int len)
    {
        if (pos < 0 || pos + len > fs.Length) throw new InvalidDataException("Read past end of image (truncated ISO?)");
        byte[] b = new byte[len];
        fs.Position = pos;
        int got = 0;
        while (got < len) { int n = fs.Read(b, got, len - got); if (n <= 0) throw new EndOfStreamException(); got += n; }
        return b;
    }

    static bool IsUnsafe(string name)
    {
        if (string.IsNullOrEmpty(name) || name == "." || name == "..") return true;
        if (name.EndsWith(".") || name.EndsWith(" ")) return true;
        if (name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0) return true;
        return false;
    }

    void WalkDirectory(uint sector, uint size, string prefix, Queue<KeyValuePair<KeyValuePair<uint, uint>, string>> work)
    {
        byte[] table = ReadAt(baseOff + (long)sector * Sector, (int)size);
        Stack<int> st = new Stack<int>();
        HashSet<int> seen = new HashSet<int>();
        st.Push(0);
        while (st.Count > 0)
        {
            int off = st.Pop();
            if (off < 0 || off + 14 > table.Length) throw new InvalidDataException("Directory entry out of range in " + prefix);
            if (!seen.Add(off)) continue;                       // loop guard
            ushort left = BitConverter.ToUInt16(table, off);
            if (left == 0xFFFF) continue;                       // empty directory / padding
            ushort right = BitConverter.ToUInt16(table, off + 2);
            uint sec = BitConverter.ToUInt32(table, off + 4);
            uint len = BitConverter.ToUInt32(table, off + 8);
            byte attr = table[off + 12];
            int nl = table[off + 13];
            if (off + 14 + nl > table.Length) throw new InvalidDataException("Directory entry name out of range in " + prefix);
            string name = Encoding.ASCII.GetString(table, off + 14, nl);
            if (IsUnsafe(name)) throw new InvalidDataException("Unsafe path component '" + name + "' in " + prefix);

            if ((attr & 0x10) != 0)
            {
                if (len > 0) work.Enqueue(new KeyValuePair<KeyValuePair<uint, uint>, string>(new KeyValuePair<uint, uint>(sec, len), prefix + name + "\\"));
            }
            else
            {
                long fileOff = baseOff + (long)sec * Sector;
                if (fileOff + len > fs.Length) throw new InvalidDataException("File '" + prefix + name + "' extends past end of image (truncated ISO?)");
                Paths.Add(prefix + name); FileOffsets.Add(fileOff); FileSizes.Add(len);
                TotalBytes += len;
            }
            if (left != 0) st.Push(left * 4);
            if (right != 0) st.Push(right * 4);
        }
    }

    public bool HasFile(string rel)
    {
        for (int i = 0; i < Paths.Count; i++) if (string.Equals(Paths[i], rel, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }

    public void ExtractAll(string destDir, Action<long, long> progress)
    {
        string destFull = Path.GetFullPath(destDir).TrimEnd('\\') + "\\";
        byte[] buf = new byte[4 * 1024 * 1024];
        long done = 0;
        for (int i = 0; i < Paths.Count; i++)
        {
            string target = Path.GetFullPath(Path.Combine(destFull, Paths[i]));
            if (!target.StartsWith(destFull, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Path escapes destination: " + Paths[i]);
            Directory.CreateDirectory(Path.GetDirectoryName(target));
            using (FileStream o = new FileStream(target, FileMode.Create, FileAccess.Write, FileShare.None, 1 << 20))
            {
                fs.Position = FileOffsets[i];
                long remaining = FileSizes[i];
                while (remaining > 0)
                {
                    int want = (int)Math.Min((long)buf.Length, remaining);
                    int n = fs.Read(buf, 0, want);
                    if (n <= 0) throw new EndOfStreamException("Unexpected end of image while reading " + Paths[i]);
                    o.Write(buf, 0, n);
                    remaining -= n; done += n;
                    if (progress != null) progress(done, TotalBytes);
                }
            }
        }
    }

    public void Dispose() { if (fs != null) { fs.Dispose(); fs = null; } }
}
'@

function Ensure-GitIgnore {
    # Keep game data, derived code and big downloads out of git if WorkDir is a git checkout.
    if (-not (Test-Path (Join-Path $WorkDir '.git'))) { return }
    if ($SkateIsLocal -and ((Resolve-Path $WorkDir).Path -eq $Skate)) { return }     # never edit the project repo's .gitignore
    $gi = Join-Path $WorkDir '.gitignore'
    $want = @('out/', 'game/', '*.iso', '*.nsp', '*.xci', '*.nro', 'generated/', 'TU_12K2276*', 'skate3recomp/', 'nfsmw-nx/', 'mesa-switch/', 'prod.keys', 'keys.dat', 'keys.txt')
    $have = if (Test-Path $gi) { @(Get-Content $gi) } else { @() }
    $add = @($want | Where-Object { $have -notcontains $_ })
    if ($add.Count) { Add-Content -Path $gi -Value $add; Write-Ok ".gitignore updated: $($add -join ' ')" }
}

function Ensure-GameDir {
    if (-not $script:GameDir -and $IsoPath) { Stage-Extract }
    if (-not $script:GameDir) { Fail 'Need -GameDir (extracted dump) or -IsoPath (Xbox 360 .iso).' }
}

function Get-7z {
    # PATH, standard 7-Zip folders, then the skate3recomp folder.
    return (Find-LocalTool -Label '7-Zip' -Exe '7z.exe' -NoVersion -KnownDirs (Get-KnownDirs).sevenz)
}

function Unpack-IsoFromArchive {
    # Vimm's Lair serves Xbox 360 discs as .7z. Lists the archive, picks the .iso inside, unpacks it to $dir.
    param([string]$Archive, [string]$Dir)
    $z = Get-7z
    if (-not $z) {
        if ($Yes -and -not $NoInstall) { Install-Winget '7zip.7zip'; Update-SessionPath; $z = Get-7z }
        if (-not $z) { Fail '7-Zip is required to unpack this archive. Install it (winget install 7zip.7zip) or re-run with prerequisites enabled.' }
    }
    $entries = @(); $cur = $null
    foreach ($l in (& $z l -slt -ba $Archive)) {
        if ($l -match '^Path = (.+)$')        { $cur = @{ Path = $Matches[1]; Size = 0L; Folder = $false }; $entries += $cur }
        elseif ($cur -and $l -match '^Size = (\d+)$')  { $cur.Size = [int64]$Matches[1] }
        elseif ($cur -and $l -match '^Folder = \+')    { $cur.Folder = $true }
    }
    $isoEntry = $entries | Where-Object { -not $_.Folder -and $_.Path -match '\.iso$' } | Sort-Object { $_.Size } -Descending | Select-Object -First 1
    if (-not $isoEntry) { Fail ("No .iso found inside {0}. Contents: {1}" -f (Split-Path $Archive -Leaf), (($entries | ForEach-Object { $_.Path }) -join ', ')) }
    Write-Ok ("archive contains {0} ({1:N2} GB)" -f $isoEntry.Path, ($isoEntry.Size / 1GB))

    $target = Join-Path $Dir $isoEntry.Path
    if ((Test-Path -LiteralPath $target) -and ((Get-Item -LiteralPath $target).Length -eq $isoEntry.Size)) {
        Write-Ok 'ISO already unpacked from this archive - reusing it'
        return $target
    }
    if (Test-Path $Dir) { Remove-Item -LiteralPath $Dir -Recurse -Force }
    New-Item -ItemType Directory -Force $Dir | Out-Null
    $drive = New-Object IO.DriveInfo ((Split-Path (Resolve-Path $Dir).Path -Qualifier))
    $need = $isoEntry.Size + 1GB
    if ($drive.AvailableFreeSpace -lt $need) {
        Fail ("Not enough free space on {0} to unpack the ISO: need {1:N1} GB, have {2:N1} GB (the game then needs about as much again)" -f $drive.Name, ($need / 1GB), ($drive.AvailableFreeSpace / 1GB))
    }

    $logOut = Join-Path $Dir '7z.out.log'; $logErr = Join-Path $Dir '7z.err.log'
    $argStr = 'x -y "-o{0}" "{1}" "{2}"' -f $Dir, $Archive, $isoEntry.Path
    $proc = Start-Process -FilePath $z -ArgumentList $argStr -PassThru -WindowStyle Hidden -RedirectStandardOutput $logOut -RedirectStandardError $logErr
    $null = $proc.Handle                       # keeps ExitCode readable after exit
    $last = -1
    while (-not $proc.HasExited) {
        Start-Sleep -Seconds 2
        if (Test-Path -LiteralPath $target) {
            $len = (Get-Item -LiteralPath $target).Length
            $pct = if ($isoEntry.Size -gt 0) { [int](100 * $len / $isoEntry.Size) } else { 0 }
            if ($pct -ne $last) {
                $last = $pct
                # first half of the Extract stage's progress bar
                Write-Host ("Extracting: {0}%  (unpacking archive: {1:N2} / {2:N2} GB)" -f [int]($pct / 2), ($len / 1GB), ($isoEntry.Size / 1GB))
            }
        }
    }
    if ($proc.ExitCode -ne 0) { Fail ("7-Zip failed (exit {0}): {1}" -f $proc.ExitCode, ((Get-Content $logErr, $logOut -ErrorAction SilentlyContinue | Select-Object -Last 5) -join ' | ')) }
    if (-not (Test-Path -LiteralPath $target)) { Fail "7-Zip finished but $target is missing" }
    Write-Ok "unpacked: $target"
    return $target
}

function Stage-Extract {
    Write-Step 'Extract (ROM -> game files, same XDVDFS method as skate3recomp)'
    Ensure-GitIgnore
    if ($script:GameDir) { Write-Ok "using extracted dump: $($script:GameDir)"; return }
    if (-not $IsoPath)   { Write-Warn2 'No -IsoPath given; nothing to extract.'; return }
    if (-not (Test-Path -LiteralPath $IsoPath -PathType Leaf)) { Fail "ROM not found: $IsoPath" }
    $src  = Get-Item -LiteralPath (Resolve-Path -LiteralPath $IsoPath).Path
    $dest = Join-Path $Out 'game'
    $part = Join-Path $Out 'game.partial'
    $isoDir = Join-Path $Out 'iso'
    $stamp = Join-Path $dest '.skate3-nx-source.txt'
    $sig = '{0}|{1}|{2}' -f $src.Name, $src.Length, $src.LastWriteTimeUtc.Ticks      # signature of what the user supplied

    if ((Test-Path (Join-Path $dest 'default.xex')) -and (Test-Path $stamp) -and ((Get-Content $stamp -Raw).Trim() -eq $sig)) {
        Write-Ok "already extracted from $($src.Name): $dest"
        $script:GameDir = $dest; return
    }

    $script:XBase = 0; $script:XScale = 100; $unpacked = $false
    if ($src.Extension -match '^\.(7z|zip|rar)$') {
        Write-Host "  supplied ROM is an archive ($($src.Extension)) - Vimm's Lair vault #78455 format"
        $iso = Unpack-IsoFromArchive -Archive $src.FullName -Dir $isoDir
        $script:XBase = 50; $script:XScale = 50; $unpacked = $true
    } else { $iso = $src.FullName }
    $item = Get-Item -LiteralPath $iso

    if (-not ('Skate3IsoReader' -as [type])) { Add-Type -TypeDefinition $Script:IsoReaderSource -Language CSharp }
    $off = [Skate3IsoReader]::ProbeOffset($iso)
    if ($off -lt 0) { Fail "$($item.Name) has no Xbox 360 XDVDFS volume (is it a raw/compressed/repacked image? Needs a plain 360 disc ISO)." }
    Write-Ok ("ISO {0} ({1:N2} GB), XDVDFS partition at 0x{2:X}" -f $item.Name, ($item.Length / 1GB), $off)

    $rd = New-Object Skate3IsoReader $iso
    try {
        if (-not $rd.HasFile('default.xex')) { Fail 'default.xex not found in the ISO - not a Skate 3 disc (or unsupported layout).' }
        if (-not $rd.HasFile('data\webkit\EAWebkit.xex')) { Write-Warn2 'data\webkit\EAWebkit.xex not found in the ISO; codegen needs it.' }
        Write-Host ("  {0} files, {1:N2} GB to extract" -f $rd.Paths.Count, ($rd.TotalBytes / 1GB))

        New-Item -ItemType Directory -Force $Out | Out-Null
        $drive = New-Object IO.DriveInfo ((Split-Path (Resolve-Path $Out).Path -Qualifier))
        $need = $rd.TotalBytes + 1GB
        if ($drive.AvailableFreeSpace -lt $need) {
            Fail ("Not enough free space on {0}: need {1:N1} GB, have {2:N1} GB" -f $drive.Name, ($need / 1GB), ($drive.AvailableFreeSpace / 1GB))
        }

        foreach ($d in $part, $dest) {
            if (Test-Path $d) {
                if (-not ((Resolve-Path $d).Path.StartsWith((Resolve-Path $Out).Path, [StringComparison]::OrdinalIgnoreCase))) { Fail "refusing to delete outside out\: $d" }
                Remove-Item -LiteralPath $d -Recurse -Force
            }
        }

        $script:lastPct = -1
        $cb = [Action[long, long]]{
            param($done, $total)
            $pct = if ($total -gt 0) { [int](100 * $done / $total) } else { 100 }
            if ($pct -ne $script:lastPct -and ($pct % 2 -eq 0)) {
                $script:lastPct = $pct
                $overall = [int]($script:XBase + $pct * $script:XScale / 100)
                Write-Host ("Extracting: {0}%  (copying game files: {1:N2} / {2:N2} GB)" -f $overall, ($done / 1GB), ($total / 1GB))
            }
        }
        $rd.ExtractAll($part, $cb)
    } finally { $rd.Dispose() }

    foreach ($f in 'default.xex', 'data\webkit\EAWebkit.xex') {
        if (-not (Test-Path (Join-Path $part $f))) { Fail "extraction finished but $f is missing" }
    }
    Move-Item -LiteralPath $part -Destination $dest
    Set-Content -Path $stamp -Value $sig
    Write-Ok "extracted to $dest"

    if ($unpacked -and -not $KeepIso) {
        if ((Resolve-Path $isoDir).Path.StartsWith((Resolve-Path $Out).Path, [StringComparison]::OrdinalIgnoreCase)) {
            Remove-Item -LiteralPath $isoDir -Recurse -Force
            Write-Ok 'removed the temporary unpacked .iso (use -KeepIso to keep it)'
        }
    }
    Write-Warn2 'The extracted game is your copy of the retail files: keep out\game out of git and out of anything you share.'
    $script:GameDir = $dest
}

function Stage-Fetch {
    Write-Step 'Fetch'
    # Local-first: an existing skate3recomp / nfsmw-nx checkout on this machine is used as-is; only missing ones are cloned.
    Ensure-Repo -Url $Pin.SkateUrl -Dir $Skate -Rev $Pin.SkateTag -Submodules -Local:$SkateIsLocal
    Assert-HeadIs $Skate $Pin.SkateCommit "skate3recomp $($Pin.SkateTag)" -WarnOnly:$SkateIsLocal
    if ($SdkIsPinned) { Assert-HeadIs $SdkDir $Pin.SdkCommit 'rexglue SDK submodule' -WarnOnly:$SkateIsLocal }
    # nfsmw-nx is only used for its Mesa patch, toolchain file and as the Horizon-layer reference.
    if ($NfsFromFolder) { Write-Ok "using the unzipped nfsmw-nx release: $Nfs" }
    else {
        Ensure-Repo -Url $Pin.NfsUrl -Dir $Nfs -Rev $Pin.NfsCommit -Local:$NfsIsLocal
        Assert-HeadIs $Nfs $Pin.NfsCommit 'nfsmw-nx' -WarnOnly:$NfsIsLocal
    }
}

function Stage-Verify {
    Write-Step 'Verify (SDK pin + header check)'
    Require-Repos
    if (-not (Test-Path (Join-Path $Skate 'src'))) { Fail 'skate3recomp not cloned - run -Stage Fetch' }
    if ($SdkIsPinned) { Assert-HeadIs $SdkDir $Pin.SdkCommit 'SDK' -WarnOnly:$SkateIsLocal } else { Write-Warn2 "custom SDK dir, pin check skipped: $SdkDir" }

    $headers = Get-ChildItem (Join-Path $Skate 'src') -Recurse -Include *.cpp, *.h, *.hpp, *.inl |
        Select-String -Pattern '#\s*include\s*[<"](rex/[^>"]+)[>"]' |
        ForEach-Object { $_.Matches[0].Groups[1].Value } | Sort-Object -Unique
    $missing = @()
    foreach ($h in $headers) {
        $rel = $h -replace '/', '\'
        if (-not (Test-Path (Join-Path $SdkDir "include\$rel"))) { $missing += $h }
    }
    Write-Host "  $($headers.Count) distinct rex/... headers included by src/"
    if ($missing.Count) { $missing | ForEach-Object { Write-Warn2 "missing: $_" }; Fail "$($missing.Count) header(s) missing from the SDK" }
    Write-Ok 'all headers present'

    if (-not (Resolve-TitleUpdate)) { Write-Warn2 'Title Update 3 not found (put TU_12K2276_000000C000000.00000000000O3 or its .zip next to the scripts).' }

    foreach ($p in 'generated', 'game') {
        if (Test-Path (Join-Path $Skate $p)) {
            & git -C $Skate check-ignore -q $p
            if ($LASTEXITCODE -ne 0) { Write-Warn2 "$p\ exists in the repo but is NOT git-ignored - do not commit it" } else { Write-Ok "$p\ is git-ignored" }
        }
    }
}


# ---------------------------------------------------------------- Title Update 3 discovery
function Resolve-TitleUpdate {
    # Finds the TU3 package next to these scripts (or via -TitleUpdate), verifies it against the No-Intro v3 entry,
    # and returns a path to a file with the ORIGINAL name (skate3recomp wants it under that name). Returns $null if none.
    # Accepts: the file itself (any subfolder, e.g. 5C087C2C\TU_...), a renamed copy (matched by size + SHA-1),
    # a .zip containing it, or -TitleUpdate pointing at a file or a folder.
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $stage = Join-Path $Out 'title-update'
    $files = @(); $explicitFile = $false

    if ($TitleUpdate) {
        if (-not (Test-Path -LiteralPath $TitleUpdate)) { Fail "-TitleUpdate not found: $TitleUpdate" }
        $it = Get-Item -LiteralPath $TitleUpdate
        if ($it.PSIsContainer) { $files += @(Get-ChildItem -LiteralPath $it.FullName -Recurse -Depth 3 -File -ErrorAction SilentlyContinue) }
        else { $files += $it; $explicitFile = $true }
    } else {
        $files += @(Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -Depth 3 -File -ErrorAction SilentlyContinue |
                    Where-Object { $_.Name -like 'TU_12K2276*' -or $_.Length -eq $Pin.TuSize -or $_.Extension -eq '.zip' })
        if (Test-Path $Skate) { $files += @(Get-ChildItem -LiteralPath $Skate -File -Filter 'TU_12K2276*' -ErrorAction SilentlyContinue) }
    }
    $files = @($files | Sort-Object FullName -Unique | Sort-Object {
        if ($_.Name -eq $Pin.TuName) { 0 } elseif ($_.Name -like 'TU_12K2276*') { 1 } elseif ($_.Extension -eq '.zip') { 3 } else { 2 } })

    $found = @()
    foreach ($f in $files) {
        $cand = $f.FullName; $from = ''
        if ($f.Extension -eq '.zip') {
            try {
                $zip = [IO.Compression.ZipFile]::OpenRead($f.FullName)
                try {
                    $e = $zip.Entries | Where-Object { $_.Name -like 'TU_12K2276*' -or $_.Length -eq $Pin.TuSize } | Select-Object -First 1
                    if (-not $e) { continue }
                    New-Item -ItemType Directory -Force $stage | Out-Null
                    $name = if ($e.Name -like 'TU_12K2276*') { $e.Name } else { $Pin.TuName }
                    $cand = Join-Path $stage $name
                    [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $cand, $true)
                    $from = " (from $($f.Name))"
                } finally { $zip.Dispose() }
            } catch { continue }
        }
        $item = Get-Item -LiteralPath $cand
        $sha = (Get-FileHash -LiteralPath $cand -Algorithm SHA1).Hash.ToLower()
        $isTu = ($item.Name -like 'TU_12K2276*') -or ($sha -eq $Pin.TuSha1) -or $explicitFile
        if (-not $isTu) { continue }
        # skate3recomp expects the original file name: stage a correctly named copy if needed.
        if ($item.Name -ne $Pin.TuName -and $item.Name -notlike 'TU_12K2276*') {
            New-Item -ItemType Directory -Force $stage | Out-Null
            $copy = Join-Path $stage $Pin.TuName
            Copy-Item -LiteralPath $cand -Destination $copy -Force
            $cand = $copy; $from += " (renamed copy of $($item.Name))"
        }
        $found += [pscustomobject]@{ Path = $cand; Sha1Ok = ($sha -eq $Pin.TuSha1); SizeOk = ($item.Length -eq $Pin.TuSize); From = $from; Size = $item.Length }
    }
    if (-not $found.Count) { return $null }
    $best = @($found | Where-Object { $_.Sha1Ok } | Select-Object -First 1)
    if (-not $best.Count) { $best = @($found | Select-Object -First 1) }
    $b = $best[0]
    if ($b.Sha1Ok) { Write-Ok ("Title Update 3: {0}{1} - SHA-1 matches No-Intro Skate 3 (World) (v3)" -f $b.Path, $b.From) }
    else { Write-Warn2 ("Title Update 3: {0}{1} - SHA-1 does NOT match No-Intro v3 ({2:N0} bytes, expected {3:N0}). Using it anyway; it may be a different update." -f $b.Path, $b.From, $b.Size, $Pin.TuSize) }
    return $b.Path
}

function Get-HostPreset {
    if ($HostPreset) { return $HostPreset }
    Push-Location $Skate
    $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try { $lines = @(& cmake --list-presets=configure 2>&1 | ForEach-Object { "$_" }) } finally { $ErrorActionPreference = $eap; Pop-Location }
    $names = @($lines | ForEach-Object { if ("$_" -match '^\s*"([^"]+)"') { $Matches[1] } })
    # skate3recomp README: Windows uses the unprefixed presets (relwithdebinfo, release); linux-*/macos-* are other hosts.
    $cand = @($names | Where-Object { $_ -notmatch '^(linux|macos)-' })
    $pick = $cand | Where-Object { $_ -eq 'relwithdebinfo' } | Select-Object -First 1
    if (-not $pick) { $pick = $cand | Where-Object { $_ -eq 'release' } | Select-Object -First 1 }
    if (-not $pick) { $pick = $cand | Select-Object -First 1 }
    if (-not $pick) { Fail ("No usable configure preset found. Available: " + ($names -join ', ') + ". Pass -HostPreset.") }
    Write-Ok "host preset: $pick"
    return $pick
}

function Import-VsDevEnv {
    # Loads the Visual Studio x64 developer environment (INCLUDE/LIB/WindowsSdkDir, rc/mt) into this session.
    # Inference, not from the skate3recomp README: Clang on Windows uses the MSVC headers/libs and Windows SDK, and
    # importing vcvars64 makes CMake's compiler checks and the Windows resource/manifest steps find them reliably.
    if ($Script:VsEnvLoaded) { return }
    $vsw = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path $vsw)) { Write-Warn2 'vswhere.exe not found - Visual Studio developer environment not loaded'; return }
    $vs = & $vsw -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath 2>$null
    if (-not $vs) { Write-Warn2 'Visual Studio C++ tools not found - developer environment not loaded'; return }
    $bat = Join-Path $vs 'VC\Auxiliary\Build\vcvars64.bat'
    if (-not (Test-Path $bat)) { Write-Warn2 "vcvars64.bat not found under $vs"; return }
    New-Item -ItemType Directory -Force $Out | Out-Null
    $tmp = Join-Path $Out 'vcvars-env.cmd'
    $body = @('@echo off', ('call "' + $bat + '" >nul 2>&1'), 'if errorlevel 1 exit /b 1', 'set')
    Set-Content -Path $tmp -Value $body -Encoding ASCII
    $lines = @(& cmd.exe /d /c $tmp)
    $vcCode = $LASTEXITCODE
    Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    if ($vcCode -ne 0) { Write-Warn2 'vcvars64.bat failed - developer environment not loaded'; return }
    foreach ($l in $lines) {
        $eq = $l.IndexOf('=')
        if ($eq -gt 0) { Set-Item -Path ('env:' + $l.Substring(0, $eq)) -Value $l.Substring($eq + 1) }
    }
    Remove-MsysFromPath
    foreach ($d in $Script:ChosenDirs) { Add-ToPath $d }       # our CMake/Ninja/LLVM stay ahead of VS's bundled copies
    $Script:VsEnvLoaded = $true
    Write-Ok "Visual Studio x64 developer environment loaded ($vs)"
}

function Get-PresetBinaryDir([string]$Preset) {
    # Resolve binaryDir of a configure preset (following 'inherits'); default out\build\<preset>.
    try {
        $json = Get-Content -Raw (Join-Path $Skate 'CMakePresets.json') | ConvertFrom-Json
        $byName = @{}; foreach ($p in $json.configurePresets) { $byName[$p.name] = $p }
        $queue = New-Object System.Collections.Queue; $queue.Enqueue($Preset)
        while ($queue.Count) {
            $n = $queue.Dequeue(); $p = $byName[$n]
            if (-not $p) { continue }
            if ($p.PSObject.Properties['binaryDir'] -and $p.binaryDir) {
                $d = $p.binaryDir.Replace('${sourceDir}', $Skate).Replace('${presetName}', $Preset).Replace('/', '\')
                return [IO.Path]::GetFullPath($d)
            }
            if ($p.PSObject.Properties['inherits']) { foreach ($i in @($p.inherits)) { $queue.Enqueue($i) } }
        }
    } catch { }
    return (Join-Path $Skate "out\build\$Preset")
}

function Clear-StaleCMakeCache([string]$BinDir, [string]$CMakeExe) {
    # A cache written by a different cmake.exe (e.g. the MSYS one from the failed run) makes every later configure fail.
    $cache = Join-Path $BinDir 'CMakeCache.txt'
    if (-not (Test-Path $cache)) { return }
    $line = Select-String -Path $cache -Pattern '^CMAKE_COMMAND:INTERNAL=(.*)$' | Select-Object -First 1
    $was = ''
    if ($line) { $was = $line.Matches[0].Groups[1].Value }
    $same = $false
    try {
        if ($was) {
            $a = [IO.Path]::GetFullPath($was.Replace('/', '\')).ToLowerInvariant()
            $b = [IO.Path]::GetFullPath($CMakeExe.Replace('/', '\')).ToLowerInvariant()
            $same = ($a -eq $b)
        }
    } catch { $same = $false }
    if (-not $same) {
        Write-Warn2 "Removing stale CMake cache in $BinDir (it was created by '$was', now using '$CMakeExe')"
        Remove-Item -LiteralPath (Join-Path $BinDir 'CMakeCache.txt') -Force
        if (Test-Path (Join-Path $BinDir 'CMakeFiles')) { Remove-Item -LiteralPath (Join-Path $BinDir 'CMakeFiles') -Recurse -Force }
    }
}

function Get-StaleBuildProcesses {
    # Programs from an earlier (or parallel) run that still have this build folder open. A running ninja/rexglue/clang keeps
    # .ninja_log and .ninja_deps open, and on Windows a file that is open cannot be renamed over: ninja then stops with
    # "failed recompaction: Permission denied" - the failure seen when the host configure ran while an old build was alive.
    # Only processes whose command line or executable lies under the skate3recomp folder / the given build folder are matched.
    param([string[]]$Folders)
    $needles = @()
    foreach ($f in $Folders) { if ($f) { $needles += $f.Replace('\', '/').TrimEnd('/'); $needles += $f.Replace('/', '\').TrimEnd('\') } }
    $names = '^(ninja|cmake|rexglue|clang|clang\+\+|clang-cl|lld-link|link|cl|cc1plus|aarch64-none-elf-g\+\+|aarch64-none-elf-gcc|aarch64-none-elf-ld|lto1|ld)\.exe$'
    $hits = @()
    try { $procs = @(Get-CimInstance Win32_Process -ErrorAction Stop) } catch { return @() }
    foreach ($p in $procs) {
        if ($p.ProcessId -eq $PID -or $p.Name -notmatch $names) { continue }
        $hay = ("{0} {1}" -f $p.ExecutablePath, $p.CommandLine)
        foreach ($n in $needles) {
            if ($n -and $hay.IndexOf($n, [StringComparison]::OrdinalIgnoreCase) -ge 0) { $hits += $p; break }
        }
    }
    return $hits
}

function Stop-StaleBuildProcesses {
    param([string[]]$Folders, [switch]$Quiet)
    $hits = @(Get-StaleBuildProcesses -Folders $Folders)
    if (-not $hits.Count) { return $false }
    Write-Warn2 ("{0} program(s) from an earlier build are still running and may hold the build files open:" -f $hits.Count)
    foreach ($h in $hits) {
        $cl = "$($h.CommandLine)"; if ($cl.Length -gt 140) { $cl = $cl.Substring(0, 140) + '...' }
        Write-Host ("    PID {0,-6} {1,-18} {2}" -f $h.ProcessId, $h.Name, $cl)
    }
    if (-not $Yes) {
        Fail 'Stop those programs (Task Manager) or re-run with -Yes / "install missing prerequisites" ticked so this script may stop them, then run again.'
    }
    foreach ($h in $hits) {
        # /T also ends the children (compilers started by ninja)
        & taskkill.exe /T /F /PID $h.ProcessId 2>&1 | Out-Null
    }
    Start-Sleep -Seconds 2
    Write-Ok 'stopped the stale build programs'
    return $true
}

function Invoke-CMakeRecover {
    # cmake with recovery for the Windows file-lock failure of Ninja's bookkeeping files:
    #   ninja: error: failed recompaction: Permission denied   (CMake reports it as "CMake Generate step failed")
    # 1) stop stale build programs and retry   2) delete .ninja_log/.ninja_deps (ninja re-creates them; that folder rebuilds) and retry
    # 3) fail with the likely remaining cause (real-time antivirus scanning, a synced folder, or another open window).
    param([string[]]$ArgList, [string]$BinDir)
    $rc = Invoke-Native cmake $ArgList -AllowFail
    if ($rc -eq 0) { return }
    $text = (@($Script:LastNativeOutput) -join "`n")
    if ($text -notmatch 'failed recompaction|Permission denied') { Fail "'cmake' exited with code $rc (its output is above)" }

    Write-Warn2 'Ninja could not rewrite its log files (Permission denied): another program has them open.'
    if (Stop-StaleBuildProcesses -Folders @($BinDir, $Skate, $Out) -Quiet) {
        $rc = Invoke-Native cmake $ArgList -AllowFail
        if ($rc -eq 0) { return }
    }
    $removed = @()
    foreach ($f in '.ninja_log', '.ninja_deps', '.ninja_log.recompact', '.ninja_deps.recompact') {
        $fp = Join-Path $BinDir $f
        if (Test-Path -LiteralPath $fp) {
            try { Remove-Item -LiteralPath $fp -Force -ErrorAction Stop; $removed += $f }
            catch { Fail ("Cannot delete {0}: it is locked by another program ({1}). Close other build windows / IDEs, and exclude {2} from real-time antivirus scanning (Windows Security > Virus & threat protection > Exclusions), then re-run." -f $fp, $_.Exception.Message, $BinDir) }
        }
    }
    if ($removed.Count) { Write-Warn2 ("deleted {0}; Ninja will rebuild this folder from scratch" -f ($removed -join ', ')) }
    $rc = Invoke-Native cmake $ArgList -AllowFail
    if ($rc -ne 0) {
        Fail ("'cmake' still fails (exit {0}) with a file-permission error in {1}. Likely causes: real-time antivirus scanning that folder (add an exclusion), Windows Controlled folder access or a sync client protecting Desktop/Documents/OneDrive (move the workspace to e.g. C:\dev), or another open build window. Its output is above." -f $rc, $BinDir)
    }
}

function Stage-Codegen {
    Write-Step 'Codegen (host x86-64 build -> generate-all)'
    Require-Repos
    if (-not (Test-Path $Skate)) { Fail 'skate3recomp not cloned - run -Stage Fetch' }
    Ensure-GameDir
    foreach ($f in 'default.xex', 'data\webkit\EAWebkit.xex') {
        if (-not (Test-Path (Join-Path $GameDir $f))) { Fail "$f not found under -GameDir $GameDir" }
    }
    $cfg = @("-DSKATE3_GAME_DATA_ROOT=$GameDir")
    $tu = Resolve-TitleUpdate
    if ($tu) { $cfg += "-DSKATE3_TITLE_UPDATE_PACKAGE=$tu" }
    else { Write-Warn2 'No Title Update 3 found next to the scripts or in the repo root: codegen will use the unpatched image (unresolved calls likely).' }
    if (-not $SdkIsPinned) { $cfg += "-DREXSDK_DIR=$SdkDir" }

    # The SDK's own third-party libraries (spdlog, xxHash, snappy, volk, Vulkan headers, ...) are nested submodules.
    # A local checkout often has them empty, which makes CMake fail at third_party\rexglue-sdk\thirdparty. Fill any gaps.
    Initialize-MissingSubmodules $Skate
    if (-not $SdkIsPinned) { Initialize-MissingSubmodules $SdkDir }
    Assert-SdkThirdparty $SdkDir

    # The pinned SDK source contains legacy ImGui API usage. Apply the
    # compatibility fix before CMake config/build so Ninja recompiles the
    # affected translation unit with the current vendored ImGui headers.
    Apply-SdkCompatibilityPatches $SdkDir

    # Native Windows toolchain only: MSYS cmake/git out of PATH, chosen tools first, VS environment loaded.
    Update-SessionPath
    Import-VsDevEnv
    $cmakeExe = (Get-Command cmake -ErrorAction SilentlyContinue | Select-Object -First 1)
    if (-not $cmakeExe -or $cmakeExe.Source -match $Script:MsysPattern) { Fail 'No native Windows CMake on PATH (only an MSYS one). Re-run with the Prereqs stage so it can install Kitware CMake.' }
    Write-Ok ("using cmake {0}" -f $cmakeExe.Source)
    foreach ($t in 'ninja', 'clang', 'clang++') {
        $c = Get-Command $t -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($c) { Write-Ok ("using {0} {1}" -f $t, $c.Source) } else { Write-Warn2 "$t not found on PATH" }
    }

    $preset = Get-HostPreset
    $hostBin = Get-PresetBinaryDir $preset
    [void](Stop-StaleBuildProcesses -Folders @($hostBin, $Skate))        # an old ninja/rexglue still running is what breaks the next configure
    Clear-StaleCMakeCache $hostBin $cmakeExe.Source
    Push-Location $Skate
    try {
        Invoke-CMakeRecover -ArgList (@('--preset', $preset) + $cfg) -BinDir $hostBin
        Invoke-CMakeRecover -ArgList @('--build', '--preset', $preset, '--target', 'generate-all', '--parallel') -BinDir $hostBin
        # README: reconfigure so CMake sees the generated source lists.
        Invoke-CMakeRecover -ArgList (@('--preset', $preset) + $cfg) -BinDir $hostBin
    } finally { Pop-Location }

    foreach ($f in 'generated\sources.cmake', 'generated\eawebkit\sources.cmake') {
        if (-not (Test-Path (Join-Path $Skate $f))) { Fail "codegen finished but $f is missing" }
    }
    Write-Ok 'generated\sources.cmake and generated\eawebkit\sources.cmake exist'
    Write-Warn2 'generated\ is derived from your game: keep it out of git and out of anything you share.'
}

function Apply-SwitchPackagingPatch {
    # Adds a Switch-only block to skate3recomp's top-level CMakeLists.txt, right after its rexglue_configure_target(skate3...) call.
    # Verified against nfsmw-nx 1.0.0 (sdk/cmake/rexglue_helpers.cmake, rexglue_switch.cmake, app/CMakeLists.txt):
    #  - rexglue_configure_target() already dispatches to rexglue_switch_configure_target() when REXGLUE_PLATFORM_SWITCH is ON, so the
    #    existing call is left exactly as it is (the earlier version of this script wrongly replaced it);
    #  - rexglue_switch_add_nro(<target> [NAME] [AUTHOR] [VERSION] [ICON]) packages <target>.nro next to the ELF;
    #  - LTO as nfsmw-nx does it: -flto -fno-fat-lto-objects on the game code, -flto=N -flto-partition=balanced on the executable.
    # Not copied (need data we do not have yet): PGO profile, the hot-function ordering file, tools/llamadas_directas.py.
    $cmakeLists = Join-Path $Skate 'CMakeLists.txt'
    if (-not (Test-Path -LiteralPath $cmakeLists)) { Fail "Skate 3 CMakeLists.txt not found: $cmakeLists" }
    $text = [IO.File]::ReadAllText($cmakeLists)
    if ($text.Contains('# ---- skate3-nx: Nintendo Switch block')) {
        Write-Ok 'Switch block already present in CMakeLists.txt'
        # keep the icon in sync with -IconPath / the bundled icon (an earlier run may have added the block without one)
        if ($IconPath -and (Test-Path -LiteralPath $IconPath)) {
            [void](Invoke-Inspect @('icon', $IconPath))
            $want = $IconPath.Replace('\', '/')
            $mm = [regex]::Match($text, 'rexglue_switch_add_nro\(skate3(?<args>[^)]*)\)')
            if ($mm.Success) {
                $args0 = $mm.Groups['args'].Value
                $args1 = [regex]::Replace($args0, '\s*ICON\s+"[^"]*"', '')
                $args1 = $args1.TrimEnd() + "`n        ICON `"$want`""
                if ($args1 -ne $args0) {
                    $text = $text.Substring(0, $mm.Groups['args'].Index) + $args1 + $text.Substring($mm.Groups['args'].Index + $args0.Length)
                    [IO.File]::WriteAllText($cmakeLists, $text, (New-Object Text.UTF8Encoding($false)))
                    Write-Ok "NRO icon set to $want"
                }
            }
        }
        return
    }
    $m = [regex]::Match($text, 'rexglue_configure_target\(\s*skate3\b[^)]*\)')
    if (-not $m.Success) { Fail 'Could not find a rexglue_configure_target(skate3 ...) call in CMakeLists.txt' }

    $iconArg = ''
    if ($IconPath) { [void](Invoke-Inspect @('icon', $IconPath)) }
    else { Write-Warn2 'no -IconPath: the NRO gets the default libnx icon (nfsmw-nx does the same until a 256x256 JPEG is supplied)' }
    if ($IconPath -and (Test-Path -LiteralPath $IconPath)) { $iconArg = "`n        ICON `"$($IconPath.Replace('\', '/'))`"" }
    $ver = $Pin.SkateTag.TrimStart('v')
    $block = @'

# ---- skate3-nx: Nintendo Switch block (added by build.ps1; original saved as CMakeLists.txt.bak-skate3nx)
if(REXGLUE_PLATFORM_SWITCH)
    set(SKATE3_LTO_JOBS "2" CACHE STRING "Parallel LTO workers at link time (each needs ~8 GB; nfsmw-nx: 2 on 16 GB)")
    option(SKATE3_LTO "LTO on the recompiled game code (Switch)" ON)
    if(SKATE3_LTO)
        get_property(_skate3_targets DIRECTORY PROPERTY BUILDSYSTEM_TARGETS)
        foreach(_t IN LISTS _skate3_targets)
            if(_t MATCHES "^skate3")
                get_target_property(_ty ${_t} TYPE)
                if(_ty MATCHES "STATIC_LIBRARY|OBJECT_LIBRARY|EXECUTABLE")
                    target_compile_options(${_t} PRIVATE -flto -fno-fat-lto-objects)
                endif()
            endif()
        endforeach()
        target_link_options(skate3 PRIVATE -flto=${SKATE3_LTO_JOBS} -flto-partition=balanced)
    endif()
    rexglue_switch_add_nro(skate3
        NAME "@NAME@"
        AUTHOR "@AUTHOR@"
        VERSION "@VER@"@ICON@)
endif()
'@
    $block = $block.Replace('@VER@', $ver).Replace('@ICON@', $iconArg).Replace('@NAME@', $Pin.AppName).Replace('@AUTHOR@', $Pin.AppAuthor)
    $backup = $cmakeLists + '.bak-skate3nx'
    if (-not (Test-Path -LiteralPath $backup)) { Copy-Item -LiteralPath $cmakeLists -Destination $backup }
    $text = $text.Insert($m.Index + $m.Length, $block)
    [IO.File]::WriteAllText($cmakeLists, $text, (New-Object Text.UTF8Encoding($false)))
    Write-Warn2 "Added the Switch block to $cmakeLists (original saved as CMakeLists.txt.bak-skate3nx)"
}

function Count-ConflictMarkers {
    # Files in a ported SDK that still contain unresolved merge markers (the compiler stops on the first one).
    # Only the SDK's own source folders are scanned - never thirdparty\ (junctions to large checkouts).
    param([string]$Sdk)
    $files = @()
    foreach ($d in 'src', 'include', 'cmake', 'switch_compat', 'resources', 'tests') {
        $dir = Join-Path $Sdk $d
        if (Test-Path -LiteralPath $dir) {
            $files += @(Get-ChildItem -LiteralPath $dir -Recurse -File -ErrorAction SilentlyContinue |
                        Where-Object { $_.Extension -in '.h', '.hpp', '.inl', '.inc', '.c', '.cc', '.cpp', '.cmake', '.py', '.ld', '.specs', '.txt' })
        }
    }
    $files += @(Get-ChildItem -LiteralPath $Sdk -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'CMakeLists.txt' -or $_.Extension -eq '.cmake' })
    $hits = @()
    foreach ($f in $files) {
        if (Select-String -LiteralPath $f.FullName -Pattern '^<<<<<<< (skate-fork|HEAD)' -Quiet) { $hits += $f.FullName.Substring($Sdk.Length).TrimStart('\') }
    }
    return $hits
}

function Stage-Port {
    # Phase 3: port nfsmw-nx's Horizon (Switch) layer of the ReXGlue SDK onto the Skate 3 SDK fork. All the merging is done by
    # port_horizon.py (git plumbing + `git merge-file`, tested on synthetic repos). This stage only prepares its inputs.
    Write-Step 'Port (Horizon layer -> Skate SDK fork)'
    Require-Repos
    $py = Join-Path $PSScriptRoot 'port_horizon.py'
    if (-not (Test-Path -LiteralPath $py)) { Fail "port_horizon.py not found next to build.ps1 ($py)" }
    if ($SwitchSdkExplicit) { Write-Ok "-SwitchSdkDir was given ($SwitchSdkDir) - nothing to port"; return }
    if ((Test-Path -LiteralPath (Join-Path $PortSdk '.skate3nx-port')) -and -not $RebuildPort) {
        $left = @(Count-ConflictMarkers $PortSdk)
        Write-Ok "port tree already exists: $PortSdk (not regenerated; your edits there are kept)"
        if ($left.Count) { Write-Warn2 ("{0} file(s) there still contain conflict markers - see {1}\report.md" -f $left.Count, $PortReport) } else { Write-Ok 'no conflict markers left in the port tree' }
        if (Test-Path -LiteralPath (Join-Path $PortSdk 'src\ui\imgui_drawer.cpp')) { Apply-SdkCompatibilityPatches $PortSdk }
        $script:SwitchSdkDir = $PortSdk
        return
    }
    $python = (Get-Command python.exe -ErrorAction SilentlyContinue | Select-Object -First 1)
    if (-not $python) { Fail 'python.exe not found (the Prereqs stage installs it)' }

    # upstream ReXGlue SDK (tags v0.8.0 / v0.10.0) - full clone without a checkout; cached under out\
    $up = Join-Path $Out 'upstream-rexglue-sdk'
    if (-not (Test-Path -LiteralPath (Join-Path $up '.git'))) {
        Write-Host '  cloning upstream rexglue-sdk (history + tags only, no working tree)'
        Invoke-Native git @('clone', '--no-checkout', $UpstreamUrl, $up)
    }
    Invoke-Native git @('-C', $up, 'fetch', '--tags', '--quiet', 'origin')

    $nfsArgs = @('--nfs-repo', $Nfs)
    if ($NfsFromFolder) { $nfsArgs = @('--nfs-dir', $NfsSdkDir) }
    $a = @($py, '--skate-sdk', $SdkDir) + $nfsArgs + @('--upstream', $up, '--out', $PortSdk, '--report', $PortReport,
           '--v08', $Pin.UpstreamTag08, '--v010', $Pin.UpstreamTag10)
    if ($RebuildPort) { $a += '--force' }
    Invoke-Native $python.Source $a

    $rj = Join-Path $PortReport 'report.json'
    if (Test-Path -LiteralPath $rj) {
        $c = (Get-Content -LiteralPath $rj -Raw | ConvertFrom-Json).summary.counts
        Write-Ok ("ported: {0} Horizon files added, {1} merged cleanly, {2} CONFLICTED, {3} edits target files the Skate SDK lacks" -f $c.horizon_new, $c.merged_clean, $c.merged_conflict, $c.missing_in_skate)
        if ($c.merged_conflict -gt 0 -or $c.missing_in_skate -gt 0) {
            Write-Warn2 "NEXT: resolve the conflicts in $PortSdk (it is a git repo; 'git diff HEAD~1' shows the port). Report: $PortReport\report.md , hunks to paste: $PortReport\conflict_hunks.txt"
        }
    }
    # The Skate SDK needed a small ImGui compatibility edit in your working copy (uncommitted, so the port - taken from git HEAD - lacks it).
    if (Test-Path -LiteralPath (Join-Path $PortSdk 'src\ui\imgui_drawer.cpp')) { Apply-SdkCompatibilityPatches $PortSdk }
    $script:SwitchSdkDir = $PortSdk
}

function Test-MesaSdk { return (Test-Path (Join-Path $MesaSdk 'lib\libvulkan.a')) }

function Stage-Mesa {
    Write-Step 'Mesa (mesa-switch + patch)'
    Show-GpuInfo
    Require-Repos
    if (Test-MesaSdk) { Write-Ok "libvulkan.a already at $MesaSdk"; return }
    Ensure-Repo -Url $Pin.MesaUrl -Dir $MesaSrc -Rev $Pin.MesaCommit -Local:$MesaIsLocal
    if (-not (Test-Path $MesaPatch)) { Fail "patch not found: $MesaPatch (run -Stage Fetch, or pass -MesaPatch)" }

    # Idempotent apply: skip if the patch is already in the tree.
    & git -C $MesaSrc apply --reverse --check $MesaPatch 2>$null
    if ($LASTEXITCODE -eq 0) { Write-Ok 'patch already applied' }
    else {
        Invoke-Native git @('-C', $MesaSrc, 'apply', '--check', $MesaPatch)
        Invoke-Native git @('-C', $MesaSrc, 'apply', $MesaPatch)
        Write-Ok 'patch applied'
        Write-Warn2 'This is the nfsmw-nx patch UNMODIFIED. Hunks are not yet audited for NFS-specific code (Phase 2 item 7).'
    }

    if ($MesaBuildScript) {
        Invoke-Native powershell @('-ExecutionPolicy', 'Bypass', '-File', $MesaBuildScript, $MesaSrc)
    }
    if (-not (Test-MesaSdk)) {
        Fail ("Driver not built. Follow $Nfs\mesa\README.md (MSYS2 MINGW64 + Rust stable-x86_64-pc-windows-gnu), " +
              "then re-run with -MesaSdk <folder containing lib\libvulkan.a>, or pass -MesaBuildScript.")
    }
    Write-Ok "NVK SDK: $MesaSdk"
}

function Show-GpuInfo {
    # Honest GPU report. Nothing in this pipeline can run on a GPU: Clang codegen, the devkitA64 GCC cross-compile + LTO
    # link, and the packaging steps are CPU/RAM/disk-bound and have no CUDA path. The RTX is only used when
    # you RUN the Windows host build of skate3 (D3D12/Vulkan). So this reports the GPU and sets nothing.
    if ($Script:GpuShown) { return }
    $Script:GpuShown = $true
    $nv = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $nv) { Write-Host '  GPU: nvidia-smi not found (no NVIDIA driver tools on PATH) - nothing in this pipeline needs one'; return }
    $line = ''
    try { $line = (@(& $nv.Source '--query-gpu=name,memory.total,driver_version' '--format=csv,noheader' 2>$null) | Select-Object -First 1) } catch { $line = '' }
    if ($line) { Write-Ok "GPU: $line" } else { Write-Host '  GPU: nvidia-smi gave no data' }
    Write-Host '  GPU use: none during this build (codegen, devkitA64 compile/LTO and packaging are CPU-bound); it is used when you run the Windows host build.'
}

function Test-SwitchSdkCompat {
    # Evidence-based gate for the Nro stage. skate3recomp's src/ and generated/ code was written against the Skate fork of
    # the ReXGlue SDK (v0.8 line). nfsmw-nx's Horizon SDK is the v0.10 line. Phase 0 measured 131 files that both forks
    # touched and upstream changed, so compiling skate3 against the nfsmw-nx SDK is expected to fail. Check it, don't guess.
    param([string]$Sdk)
    $problems = New-Object System.Collections.ArrayList
    if (-not (Test-Path -LiteralPath (Join-Path $Sdk 'cmake\rexglue_switch.cmake'))) { [void]$problems.Add('cmake\rexglue_switch.cmake is missing (not a Switch/Horizon SDK)') }

    $headers = Get-ChildItem -LiteralPath (Join-Path $Skate 'src') -Recurse -Include *.cpp, *.h, *.hpp, *.inl -File -ErrorAction SilentlyContinue |
        Select-String -Pattern '#\s*include\s*[<"](rex/[^>"]+)[>"]' |
        ForEach-Object { $_.Matches[0].Groups[1].Value } | Sort-Object -Unique
    $missing = @($headers | Where-Object { -not (Test-Path -LiteralPath (Join-Path $Sdk ('include\' + ($_ -replace '/', '\')))) })

    if (Test-Path -LiteralPath (Join-Path $Sdk '.skate3nx-port')) {
        $marked = @(Count-ConflictMarkers $Sdk)
        Write-Host ("  ported SDK: {0} file(s) still contain unresolved conflict markers" -f $marked.Count)
        $marked | Select-Object -First 20 | ForEach-Object { Write-Host "    conflict: $_" }
        if ($marked.Count) { [void]$problems.Add(("{0} file(s) in the ported SDK still have merge-conflict markers (see {1}\report.md)" -f $marked.Count, $PortReport)) }
    }
    $ver = { param($dir) $t = ''; $f = Join-Path $dir 'CMakeLists.txt'; if (Test-Path -LiteralPath $f) { $t = Get-Content -LiteralPath $f -Raw }; if ($t -match 'VERSION\s+(\d+\.\d+\.\d+)') { $Matches[1] } else { '?' } }
    Write-Host ("  SDK versions: skate3recomp's = {0}, Switch SDK = {1}" -f (& $ver $SdkDir), (& $ver $Sdk))
    Write-Host ("  rex/... headers used by skate3recomp src/: {0}, missing from the Switch SDK: {1}" -f $headers.Count, $missing.Count)
    if ($missing.Count) {
        $missing | Select-Object -First 25 | ForEach-Object { Write-Host "    missing: $_" }
        if ($missing.Count -gt 25) { Write-Host ("    ... and {0} more" -f ($missing.Count - 25)) }
        [void]$problems.Add(("{0} header(s) that skate3recomp includes do not exist in the Switch SDK" -f $missing.Count))
    }
    return @($problems)
}

function Get-MemoryPlan {
    # Turns "use up to 20 GB if it helps" into numbers. The cap is the smaller of -MemoryBudgetGB and 85% of the RAM that is
    # FREE right now (not total), so the plan never counts memory that other programs are holding.
    $os = Get-CimInstance Win32_OperatingSystem
    $totalGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
    $freeGB  = [math]::Round($os.FreePhysicalMemory / 1MB, 1)
    $budget  = [int][math]::Min($MemoryBudgetGB, [math]::Floor($freeGB * 0.85))
    $cores   = [Environment]::ProcessorCount
    # Per-job figures are heuristics anchored on nfsmw-nx's known-good point (16 GB machine: -j 4, -flto=2):
    #   compile job ~4 GB (assumption), LTO worker ~8 GB: nfsmw-nx's docs/building.md says -flto=2 with balanced partitions is what
    #   fits in 16 GB for 144 MB of generated C++ and "more jobs do not fit". Skate's generated code is a different size, so treat
    #   this as the same order of magnitude, not a measurement.
    $compile = [int][math]::Max(2, [math]::Min($cores, [math]::Floor($budget / 4)))
    $lto     = [int][math]::Max(1, [math]::Min([math]::Min($cores, 8), [math]::Floor($budget / 8)))
    if ($LtoJobs -gt 0) { $lto = $LtoJobs }
    if ($NoMemoryTuning) { $compile = 4; $lto = 2 }
    return [pscustomobject]@{ TotalGB = $totalGB; FreeGB = $freeGB; BudgetGB = $budget; Cores = $cores; CompileJobs = $compile; LtoJobs = $lto }
}

function Show-MemoryPlan {
    $mp = Get-MemoryPlan
    Write-Host ("  RAM: {0} GB total, {1} GB free now; planning for up to {2} GB; {3} CPU threads" -f $mp.TotalGB, $mp.FreeGB, $mp.BudgetGB, $mp.Cores)
    if ($mp.BudgetGB -lt 12 -and -not $NoMemoryTuning) { Write-Warn2 "only $($mp.BudgetGB) GB is usable right now - close browsers/other big programs before the Switch build, or the LTO link may run out of memory" }
    Write-Host ("  plan: {0} compile jobs, {1} LTO workers{2}" -f $mp.CompileJobs, $mp.LtoJobs, $(if ($NoMemoryTuning) { ' (tuning off: nfsmw-nx defaults)' } else { '' }))
    if (-not $NoMemoryTuning -and $mp.LtoJobs -lt 3 -and $mp.TotalGB -ge 28 -and $MemoryBudgetGB -lt 24) {
        Write-Host '  note: a 3rd LTO worker needs about 24 GB. With this much RAM you can allow it with -MemoryBudgetGB 24 (it leaves ~8 GB for Windows).'
    }
    return $mp
}

function Get-LtoJobsInBuild([string]$BinDir) {
    $ninja = Join-Path $BinDir 'build.ninja'
    if (-not (Test-Path -LiteralPath $ninja)) { return @() }
    $vals = @()
    foreach ($m in (Select-String -LiteralPath $ninja -Pattern '-flto=(\d+)' -AllMatches)) {
        foreach ($mm in $m.Matches) { $vals += [int]$mm.Groups[1].Value }
    }
    return @($vals | Sort-Object -Unique)
}

function Stage-Nro {
    Write-Step 'Nro (Nintendo Switch devkitA64 cross-compile -> NRO)'
    Show-GpuInfo
    Require-Repos
    Set-DevkitEnv
    if (-not (Test-Path (Join-Path $Skate 'generated\sources.cmake'))) { Fail 'generated\ missing - run -Stage Codegen first' }
    if (-not (Test-MesaSdk)) { Fail "libvulkan.a not found under -MesaSdk $MesaSdk - run -Stage Mesa" }
    if (-not (Test-Path $SwitchToolchainFile)) {
        Fail "Switch toolchain file not found: $SwitchToolchainFile (expected from nfsmw-nx)"
    }
    if (-not (Test-Path (Join-Path $SwitchSdkDir 'cmake\rexglue_switch.cmake'))) {
        Fail "Switch SDK at $SwitchSdkDir has no cmake\rexglue_switch.cmake. Use nfsmw-nx's sdk folder or pass -SwitchSdkDir."
    }
    $problems = @(Test-SwitchSdkCompat $SwitchSdkDir)
    if ($problems.Count) {
        $msg = "The Switch SDK ($SwitchSdkDir) cannot build skate3recomp as it is: " + ($problems -join '; ') + ". " +
               "Run the Port stage (it ports nfsmw-nx's Horizon layer onto the Skate SDK fork into out\horizon-sdk), fix what its report lists, " +
               "then re-run. Or use -ForceSwitchSdk to try anyway (expect compile errors)."
        if ($ForceSwitchSdk) { Write-Warn2 ("-ForceSwitchSdk given, continuing despite: " + ($problems -join '; ')) } else { Fail $msg }
    } else { Write-Ok 'Switch SDK provides everything skate3recomp includes' }
    $mp = Show-MemoryPlan
    $buildJobs = $Jobs
    if ($JobsAuto -and -not $NoMemoryTuning) { $buildJobs = $mp.CompileJobs }
    $toolchain = $SwitchToolchainFile
    $tu = Resolve-TitleUpdate
    # IMPORTANT: the host Skate checkout pins a Windows-oriented ReXGlue SDK.
    # For Switch we deliberately override REXSDK_DIR with nfsmw-nx's Switch-capable
    # SDK fork, which provides rexglue_switch.cmake and the Horizon/NVK integration.
    # The toolchain also sets this flag, but pass it explicitly so a stale CMake cache
    # cannot silently fall back to the host platform.
    $cfg = @('-S', $Skate, '-B', $NroBuild, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
             "-DCMAKE_TOOLCHAIN_FILE=$toolchain",
             '-DREXGLUE_PLATFORM_SWITCH=ON',
             '-DREXGLUE_USE_VULKAN=ON',
             '-DREXGLUE_USE_D3D12=OFF',
             '-DREXGLUE_ENABLE_TRACY=OFF',
             '-DREXGLUE_ENABLE_PERF_COUNTERS=OFF',
             "-DREXSDK_DIR=$SwitchSdkDir",
             "-DSKATE3_LTO_JOBS=$($mp.LtoJobs)",
             "-DREXGLUE_SWITCH_NVK_SDK=$MesaSdk",
             "-DSKATE3_GAME_DATA_ROOT=$GameDir")
    if ($tu) { $cfg += "-DSKATE3_TITLE_UPDATE_PACKAGE=$tu" }
    $cfg += $ExtraCMakeArgs
    Apply-SwitchPackagingPatch
    Invoke-CMakeRecover -ArgList $cfg -BinDir $NroBuild

    # Evidence, not assumption: what LTO worker count did CMake actually bake into the build?
    $ltoSeen = @(Get-LtoJobsInBuild $NroBuild)
    if ($ltoSeen.Count -eq 0) { Write-Host '  build.ninja contains no -flto=N flag (LTO worker count not set explicitly)' }
    elseif ($NoMemoryTuning -or ($ltoSeen.Count -eq 1 -and $ltoSeen[0] -eq $mp.LtoJobs)) { Write-Ok ("LTO workers in the build: {0}" -f ($ltoSeen -join ', ')) }
    else {
        Write-Warn2 ("LTO workers in build.ninja: {0} (planned {1}). The CMake block added by Apply-SwitchPackagingPatch should set it from SKATE3_LTO_JOBS; check that the block is in CMakeLists.txt." -f ($ltoSeen -join ', '), $mp.LtoJobs)
        $hits = @(Get-ChildItem -LiteralPath $SwitchSdkDir, (Split-Path $SwitchToolchainFile -Parent) -Recurse -Include *.cmake, CMakeLists.txt -File -ErrorAction SilentlyContinue |
                  Select-String -Pattern '-flto=\d+' | Select-Object -First 5)
        foreach ($h in $hits) { Write-Host ("    {0}:{1}: {2}" -f $h.Path, $h.LineNumber, $h.Line.Trim()) }
    }

    $swNro = [Diagnostics.Stopwatch]::StartNew()
    try {
        Invoke-CMakeRecover -ArgList @('--build', $NroBuild, '--target', $NroTarget, '-j', "$buildJobs") -BinDir $NroBuild
    } catch {
        throw ("{0}`nIf this was an out-of-memory failure (std::bad_alloc, 'cannot allocate', 'virtual memory exhausted'), re-run with a smaller plan: -Jobs 3 -LtoJobs 1 (or -NoMemoryTuning). nfsmw-nx needed ~16 GB for 2 LTO workers." -f $_.Exception.Message)
    }
    Write-Host ("  [time] compile + link took {0:mm\:ss}  ({1} compile jobs, LTO workers {2}, budget {3} GB) - compare this between runs" -f $swNro.Elapsed, $buildJobs, $(if ($ltoSeen.Count) { $ltoSeen -join '/' } else { 'n/a' }), $mp.BudgetGB)

    $nro = Get-ChildItem $NroBuild -Recurse -Filter *.nro | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $nro) { Fail "build finished but no .nro found under $NroBuild (is -NroTarget '$NroTarget' the packaging target?)" }
    Write-Ok ("{0}  ({1:N1} MB)" -f $nro.FullName, ($nro.Length / 1MB))
    [void](Invoke-Inspect @('nro', $nro.FullName, '--name', $Pin.AppName, '--author', $Pin.AppAuthor))
}

function Invoke-Inspect {
    # Runs switch_inspect.py (format checks verified against nfsmw-nx's real NRO). Exit 1 = format error -> stop the build.
    param([string[]]$InspectArgs)
    $tool = Join-Path $PSScriptRoot 'switch_inspect.py'
    if (-not (Test-Path -LiteralPath $tool)) { Write-Warn2 'switch_inspect.py not found next to build.ps1 - format checks skipped'; return 0 }
    $py = Get-Command python.exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $py) { Write-Warn2 'python.exe not found - format checks skipped'; return 0 }
    $rc = Invoke-Native $py.Source (@($tool) + $InspectArgs) -AllowFail
    if ($rc -eq 1) { Fail ("format check failed ({0} {1}) - see the [ERROR] lines above" -f $InspectArgs[0], (Split-Path $InspectArgs[1] -Leaf)) }
    if ($rc -ne 0) { Fail ("format checker could not read {0} (exit {1})" -f $InspectArgs[1], $rc) }
    return 0
}

function Test-HasNro {
    return [bool](Get-ChildItem -LiteralPath $NroBuild -Recurse -Filter *.nro -File -ErrorAction SilentlyContinue | Select-Object -First 1)
}

function Test-Fat32Limit {
    # FAT32 cannot hold a file of 4 GiB or more. The recomp reads loose files from game\, so one such file means the SD card
    # must be exFAT (Horizon supports it), otherwise the copy fails or silently truncates on other tools.
    param([string]$Dir, [string]$Target = '')
    $big = @(Get-ChildItem -LiteralPath $Dir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -ge 4GB })
    if (-not $big.Count) { Write-Ok 'no file in game\ is 4 GiB or larger (FAT32 and exFAT cards both work)'; return }
    $big | Select-Object -First 5 | ForEach-Object { Write-Host ("    >= 4 GiB: {0} ({1:N2} GB)" -f $_.FullName.Substring($Dir.Length).TrimStart('\'), ($_.Length / 1GB)) }
    $msg = "{0} file(s) in game\ are 4 GiB or larger: the SD card must be formatted exFAT, not FAT32." -f $big.Count
    if ($Target) {
        $fmt = ''
        try { $fmt = (New-Object IO.DriveInfo ($Target.Substring(0, 1))).DriveFormat } catch { $fmt = '' }
        if ($fmt -eq 'FAT32') { Fail "$msg Drive $($Target.Substring(0, 1)): is FAT32." }
        Write-Ok "SD card format: $fmt"
    } else { Write-Warn2 $msg }
}

function Get-ConsoleForwarderNro {
    # TooTallNate/switch-nsp-forwarder: a homebrew app that runs ON the Switch and generates + installs the forwarder NSP there.
    # Per its release notes (0.0.4 onward) it writes plaintext NSPs and fetches the header key from the console through the "spl"
    # service when no prod.keys is present, so no key file is needed. 0.0.5+ can install the NSP itself. 0.0.8 is the latest.
    # Local first (an existing copy next to the scripts / in Downloads), then the GitHub release - unless -NoInstall.
    foreach ($d in @($PSScriptRoot, $WorkDir, (Join-Path $Out 'downloads'), "$env:USERPROFILE\Downloads")) {
        if ($d -and (Test-Path -LiteralPath $d)) {
            $hit = Get-ChildItem -LiteralPath $d -Recurse -Depth 3 -Filter 'switch-nsp-forwarder*.nro' -File -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($hit) { Write-Ok "switch-nsp-forwarder already on disk: $($hit.FullName)"; return $hit.FullName }
        }
    }
    if ($NoInstall) { Write-Warn2 'switch-nsp-forwarder not found locally and -NoInstall was given - not downloading it'; return $null }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $rel = Invoke-RestMethod 'https://api.github.com/repos/TooTallNate/switch-nsp-forwarder/releases/latest' -Headers @{ 'User-Agent' = 'skate3-nx-build' }
    $dl = Join-Path $Out 'downloads'
    New-Item -ItemType Directory -Force $dl | Out-Null
    $asset = $rel.assets | Where-Object { $_.name -match '\.nro$' } | Select-Object -First 1
    if ($asset) {
        $dst = Join-Path $dl $asset.name
        Write-Host "  downloading $($asset.browser_download_url)"
        Invoke-WebRequest $asset.browser_download_url -OutFile $dst -UseBasicParsing
        return $dst
    }
    $zipAsset = $rel.assets | Where-Object { $_.name -match '\.zip$' } | Select-Object -First 1
    if (-not $zipAsset) { Write-Warn2 ("release {0} has no .nro or .zip asset (assets: {1})" -f $rel.tag_name, (($rel.assets | ForEach-Object { $_.name }) -join ', ')); return $null }
    $zipPath = Join-Path $dl $zipAsset.name
    Write-Host "  downloading $($zipAsset.browser_download_url)"
    Invoke-WebRequest $zipAsset.browser_download_url -OutFile $zipPath -UseBasicParsing
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $z = [IO.Compression.ZipFile]::OpenRead($zipPath)
    try {
        $e = $z.Entries | Where-Object { $_.Name -match '\.nro$' } | Select-Object -First 1
        if (-not $e) { Write-Warn2 "$($zipAsset.name) contains no .nro"; return $null }
        $dst = Join-Path $dl $e.Name
        [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dst, $true)
        return $dst
    } finally { $z.Dispose() }
}

function Stage-SwitchFinal {
    Write-Step 'SwitchFinal (SD-card layout + on-console NSP generator)'
    Show-GpuInfo
    $nro = Get-ChildItem -LiteralPath $NroBuild -Recurse -Filter *.nro -File -ErrorAction SilentlyContinue |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $nro) { Fail "no .nro under $NroBuild - the Switch build (Nro stage) has not produced one yet" }
    Write-Ok ("NRO: {0} ({1:N1} MB)" -f $nro.FullName, ($nro.Length / 1MB))
    # Format gate: a malformed NRO must not get packaged.
    [void](Invoke-Inspect @('nro', $nro.FullName, '--name', $Pin.AppName, '--author', $Pin.AppAuthor))

    $results = New-Object System.Collections.ArrayList
    New-Item -ItemType Directory -Force $SwitchFinal | Out-Null
    foreach ($sub in 'nsp', 'xci') {
        $d = Join-Path $SwitchFinal $sub
        if (Test-Path -LiteralPath $d) {
            if (-not ((Resolve-Path -LiteralPath $d).Path.StartsWith((Resolve-Path -LiteralPath $Out).Path, [StringComparison]::OrdinalIgnoreCase))) { Fail "refusing to delete outside out\: $d" }
            Remove-Item -LiteralPath $d -Recurse -Force
        }
    }

    # ---- 1) SD-card layout (what actually runs the game)
    $sdTree = Join-Path $SwitchFinal ('sdcard\switch\' + $SdFolder)
    New-Item -ItemType Directory -Force $sdTree | Out-Null
    Copy-Item -LiteralPath $nro.FullName -Destination (Join-Path $sdTree $SdNroName) -Force
    [void]$results.Add("[ok]      SD layout: sdcard\switch\$SdFolder\$SdNroName")

    if (-not $SkipGameCopy) {
        Ensure-GameDir
        Write-Host '  copying game data to SWITCHFINAL (multi-GB, local disk only)...'
        & robocopy $GameDir (Join-Path $sdTree $GameFolder) /E /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -ge 8) { Fail "robocopy game data failed ($LASTEXITCODE)" }
        [void]$results.Add("[ok]      SD layout: $GameFolder\ (your retail dump - never redistribute)")
        Test-Fat32Limit -Dir (Join-Path $sdTree $GameFolder)
    } else { [void]$results.Add("[skipped] $GameFolder\ (-SkipGameCopy): copy it to /switch/$SdFolder/$GameFolder yourself") }

    # Title-update patch files generated by the Switch build; fall back to older locations.
    $xexp = @(
        @{ Name = 'default.xexp';   Rel = 'game\default.xexp';                Path = (Join-Path $NroBuild 'title_update_codegen\default.xexp') },
        @{ Name = 'EAWebkit.xexp';  Rel = 'game\data\webkit\EAWebkit.xexp';   Path = (Join-Path $NroBuild 'title_update_codegen\data\webkit\EAWebkit.xexp') }
    )
    foreach ($item in $xexp) {
        $hit = $null
        if (Test-Path -LiteralPath $item.Path) { $hit = Get-Item -LiteralPath $item.Path }
        else { $hit = Get-ChildItem -LiteralPath $Skate -Recurse -Filter $item.Name -File -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notlike "$Out*" } | Select-Object -First 1 }
        if ($hit) {
            $dest = Join-Path $sdTree ($item.Rel -replace '^game', $GameFolder)
            New-Item -ItemType Directory -Force (Split-Path $dest -Parent) | Out-Null
            Copy-Item -LiteralPath $hit.FullName -Destination $dest -Force
            [void]$results.Add("[ok]      $($item.Name) -> $($item.Rel)")
        } else { [void]$results.Add("[warn]    $($item.Name) not produced by the build; the title update will not be applied") }
    }
    if ($ConfigToml -and (Test-Path -LiteralPath $ConfigToml)) {
        Copy-Item -LiteralPath $ConfigToml -Destination $sdTree -Force
        [void]$results.Add("[ok]      config: $(Split-Path $ConfigToml -Leaf)")
    }

    # Verify the SD tree the way nfsmw-nx's installer lays it out: /switch/<name>/<name>.nro, config, game files.
    $la = @('layout', (Join-Path $SwitchFinal 'sdcard'), '--folder', $SdFolder, '--nro', $SdNroName)
    if ($SkipGameCopy) { $la += '--no-game' } else { $la += @('--game-dir', $GameFolder, '--require', 'default.xex', 'data/webkit/EAWebkit.xex') }
    [void](Invoke-Inspect $la)

    # ---- 2) NSP: created ON the Switch, so nothing is built or encrypted on this PC and no key file is involved.
    #         TooTallNate's switch-nsp-forwarder reads the NRO, makes the forwarder NSP there and installs it.
    if ($SkipNsp) { [void]$results.Add('[skipped] NSP generator (-SkipNsp)') }
    else {
        $fwNro = Get-ConsoleForwarderNro
        if ($fwNro) {
            try { [void](Invoke-Inspect @('nro', $fwNro)) } catch { Write-Warn2 ("format check of the downloaded NRO failed: " + $_.Exception.Message + ' - copying it anyway (third-party app)') }
            $fwDir = Join-Path $SwitchFinal 'sdcard\switch\switch-nsp-forwarder'
            New-Item -ItemType Directory -Force $fwDir | Out-Null
            Copy-Item -LiteralPath $fwNro -Destination (Join-Path $fwDir (Split-Path $fwNro -Leaf)) -Force
            [void]$results.Add('[ok]      NSP generator staged: sdcard\switch\switch-nsp-forwarder\ - run it ON the Switch (title takeover: hold R), pick ' + $SdNroPath)
        } else {
            [void]$results.Add('[warn]    NSP generator not staged (see above). The NRO still runs from the Homebrew Launcher with title takeover (hold R).')
        }
    }

    @(
        'Skate 3 -> Nintendo Switch: final package',
        ('Built: ' + (Get-Date -Format o)),
        ('NRO: ' + $nro.Name + ' (' + [math]::Round($nro.Length / 1MB, 2) + ' MB)'),
        '',
        'HOW TO USE',
        '1. Copy the CONTENTS of sdcard\ to the root of your SD card. This is what runs the game.',
        '   The SD card should be exFAT if any file in game\ is 4 GiB or larger (the build warns about this).',
        '2. Start it - pick ONE:',
        '   a) Homebrew Launcher in title takeover: hold R while launching any game or app, then choose the Skate 3 entry.',
        '      Nothing is installed. Applet mode (hbmenu opened from the Album) has too little memory.',
        '   b) A Home-menu icon: start "switch-nsp-forwarder" the same way (title takeover), choose',
        ('      /switch/' + $SdFolder + '/' + $SdNroName + ', and let it create and install the NSP on the console.'),
        '      The NSP is made on the Switch itself; nothing is built or encrypted on the PC and no key file is used here.',
        '',
        'FILES',
        ('sdcard\switch\' + $SdFolder + '\' + $SdNroName + '   the game. Do not move or rename it: the NSP made in step 2b has this path built in.'),
        ('sdcard\switch\' + $SdFolder + '\' + $GameFolder + '\   your game files (the retail dump you supplied)'),
        'sdcard\switch\switch-nsp-forwarder\      the NSP generator (third-party, TooTallNate). Only needed for step 2b.',
        'No .xci is produced: an XCI cannot be built without a PC-side key-based tool, and the NRO / NSP route does not need one.',
        '',
        'ABOUT THE NSP',
        '- It is unsigned (only Nintendo can sign titles). Stock firmware rejects it; a system that runs unsigned titles has to have',
        '  signature checks patched, and installing forwarders online can get a console banned. Step 2a needs none of that.',
        '- A forwarder starts the NRO as a full application (far more RAM than hbmenu from the Album). Title takeover gives the same memory.',
        '- Forwarders have broken on firmware updates (9.0.0, 12.0.0, 19.0.0, 21.0.0). Update switch-nsp-forwarder after one.',
        '- game\ is the retail dump you supplied. Do not redistribute it or the NRO built from it.'
    ) | Set-Content -LiteralPath (Join-Path $SwitchFinal 'README.txt') -Encoding UTF8

    Write-Host ''
    Write-Host '  ===== SWITCHFINAL RESULT =====' -ForegroundColor Green
    foreach ($r in $results) { if ($r -like '`[warn*') { Write-Warn2 $r } else { Write-Host "  $r" } }
    Write-Host "  folder: $SwitchFinal" -ForegroundColor Green
}

function Stage-Sd {
    Write-Step 'Sd (staging layout)'
    $nro = Get-ChildItem $NroBuild -Recurse -Filter *.nro -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $nro) { Fail "no .nro under $NroBuild - run -Stage Nro" }

    New-Item -ItemType Directory -Force $SdStage | Out-Null
    Copy-Item $nro.FullName (Join-Path $SdStage $SdNroName) -Force
    Write-Ok $SdNroName
    if ($ConfigToml) { Copy-Item $ConfigToml $SdStage -Force; Write-Ok "config: $(Split-Path $ConfigToml -Leaf)" }
    else { Write-Warn2 'no -ConfigToml given; the port will need one next to the NRO' }

    $gameOut = Join-Path $SdStage $GameFolder
    if (-not $SkipGameCopy) {
        Ensure-GameDir
        Write-Host '  copying game dump (multi-GB, local disk only)...'
        & robocopy $GameDir $gameOut /E /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -ge 8) { Fail "robocopy failed ($LASTEXITCODE)" }
        Write-Ok "game\ staged from $GameDir"
    }

    # Staged title-update patches (default.xexp, EAWebkit.xexp) come out of the host build.
    # Where skate3recomp stages them was not checked; we search its build + generated dirs.
    $tuTargets = @{
        'default.xexp' = 'default.xexp'
        'EAWebkit.xexp' = 'data\webkit\EAWebkit.xexp'
    }
    foreach ($name in $tuTargets.Keys) {
        $hit = Get-ChildItem $Skate -Recurse -Filter $name -ErrorAction SilentlyContinue |
               Where-Object { $_.FullName -notlike "$Out*" } | Select-Object -First 1
        if ($hit) {
            $dest = Join-Path $gameOut $tuTargets[$name]
            New-Item -ItemType Directory -Force (Split-Path $dest -Parent) | Out-Null
            Copy-Item $hit.FullName $dest -Force
            Write-Ok "$name -> $($tuTargets[$name])"
        } else { Write-Warn2 "$name not found - run Codegen with -TitleUpdate, or copy it into game\ yourself" }
    }
    Write-Host "  staged at: $SdStage"

    if ($SdRoot) {
        $dest = Join-Path $SdRoot ('switch\' + $SdFolder)
        if (-not (Test-Path $SdRoot)) { Fail "SD root not found: $SdRoot" }
        if (Test-Path -LiteralPath $gameOut) { Test-Fat32Limit -Dir $gameOut -Target $SdRoot }
        if (-not $Yes) {
            $a = Read-Host "Copy $SdStage to $dest on the SD card? (y/N)"
            if ($a -notmatch '^[yY]') { Write-Host '  skipped.'; return }
        }
        & robocopy $SdStage $dest /E /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -ge 8) { Fail "robocopy to SD failed ($LASTEXITCODE)" }
        Write-Ok "copied to $dest"
    }
}

# ---------------------------------------------------------------- main
New-Item -ItemType Directory -Force $LogDir | Out-Null
$log = Join-Path $LogDir ("build-{0:yyyyMMdd-HHmmss}.log" -f (Get-Date))
Start-Transcript -Path $log | Out-Null
Write-Host 'build.ps1 version 2026-10-05.21 (ninja 'failed recompaction' recovery; stale build process check)'
try {
    $order = @('Prereqs', 'Extract', 'Fetch', 'Verify', 'Codegen', 'Port', 'Mesa', 'Nro', 'SwitchFinal', 'Sd')
    $want = if ($Stage -contains 'All') { $order } else { @($Stage) }
    if ($IsoPath -and -not $GameDir -and ($want -contains 'Codegen' -or $want -contains 'Sd' -or $want -contains 'SwitchFinal')) { $want += 'Extract' }
    # Prerequisites are always checked first (and installed if missing) unless opted out.
    if (-not $SkipPrereqs) { $want += 'Prereqs' }
    # Dependencies are added only when their output is missing, so packaging an existing NRO does not rebuild anything.
    if ($want -contains 'SwitchFinal' -and -not (Test-HasNro)) { $want += 'Nro' }
    if ($want -contains 'Nro') {
        if (-not $SwitchSdkExplicit -and -not (Test-Path -LiteralPath (Join-Path $PortSdk '.skate3nx-port'))) { $want += 'Port' }
        if (-not (Test-Path -LiteralPath (Join-Path $Skate 'generated\sources.cmake'))) { $want += 'Codegen' }
        if (-not (Test-MesaSdk)) { $want += 'Mesa' }
    }
    $script:Plan = @($order | Where-Object { $want -contains $_ } | Select-Object -Unique)
    $timings = New-Object System.Collections.ArrayList
    foreach ($s in $script:Plan) {
        $sw = [Diagnostics.Stopwatch]::StartNew()
        & "Stage-$s"
        $sw.Stop()
        [void]$timings.Add(("{0,-12} {1:hh\:mm\:ss}" -f $s, $sw.Elapsed))
    }
    Write-Host ''
    Write-Host '  [time] stage durations (compare between runs when tuning):'
    foreach ($t in $timings) { Write-Host "    $t" }
    Write-Host "`nDone. Log: $log" -ForegroundColor Green
} catch {
    Write-Host "`nFAILED: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log: $log"
    # Keep an interactive console open on error until SPACE is pressed.
    if (-not $NoPause -and [Environment]::UserInteractive -and -not [Console]::IsInputRedirected) {
        Write-Host "`nPress SPACE to close this window..." -ForegroundColor Yellow
        try { do { $k = [Console]::ReadKey($true) } until ($k.Key -eq 'Spacebar') } catch { }
    }
    exit 1
} finally {
    Stop-Transcript | Out-Null
}
