<#
.SYNOPSIS
  Windows GUI launcher for build.ps1 (Skate 3 -> Switch port).

.DESCRIPTION
  1. Loads build.ps1 from this folder and checks it with PowerShell's own parser.
  2. Looks in this folder (and up to 3 levels of subfolders) for:
       - your Skate 3 dump          (default.xex + data\webkit\EAWebkit.xex), OR
       - your Skate 3 Xbox 360 ROM: the .7z download from Vimm's Lair vault #78455 (USA/Europe v1.0),
         or a plain .iso. The Extract stage unpacks the archive (7-Zip, installed if missing) and extracts
         the game with the same XDVDFS method as skate3recomp's "Select ISO" installer.
       - the Title Update 3 package (TU_12K2276_000000C000000.00000000000O3)
     and checks each one opens and has a plausible file header.
  3. Shows a checklist of what loaded, then starts build.ps1 after a short countdown
     (Start now / Cancel available) and shows its output live with a progress bar.

  Nothing is copied or uploaded: the dump and title update are used where they are.
  NOT RUN by the author (no Windows machine available) - report any error text you see.

  ERRORS: if anything goes wrong (a file fails to load, the build exits with an error, or the launcher itself
  throws) the window will NOT close: the close button and Alt+F4 are blocked and it shows
  "Press SPACE to close". Cancelling the build yourself is not treated as an error.

  Double-click Run-Skate3-Build.cmd, or:
    powershell -STA -ExecutionPolicy Bypass -File tools\launcher.ps1
#>
[CmdletBinding()]
param(
    [int]$CountdownSeconds = 5,
    [switch]$NoAutoStart
)

$ErrorActionPreference = 'Stop'

function Show-Fatal([string]$text) {
    # Last-resort window for errors that happen before/outside the main window. Stays open until SPACE is pressed.
    try {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        $f = New-Object Windows.Forms.Form
        $f.Text = 'Skate 3 -> Switch build - ERROR'; $f.Size = New-Object Drawing.Size(820, 460); $f.StartPosition = 'CenterScreen'
        $f.BackColor = [Drawing.Color]::FromArgb(30, 30, 30); $f.KeyPreview = $true
        $t = New-Object Windows.Forms.TextBox
        $t.Multiline = $true; $t.ReadOnly = $true; $t.ScrollBars = 'Both'; $t.WordWrap = $false; $t.Text = $text
        $t.Dock = 'Fill'; $t.BackColor = [Drawing.Color]::FromArgb(18, 18, 18); $t.ForeColor = [Drawing.Color]::FromArgb(240, 100, 100)
        $t.Font = New-Object Drawing.Font('Consolas', 9); $t.TabStop = $false
        $l = New-Object Windows.Forms.Label
        $l.Text = 'An error occurred. Press SPACE to close this window.'; $l.Dock = 'Bottom'; $l.Height = 34; $l.TextAlign = 'MiddleCenter'
        $l.BackColor = [Drawing.Color]::FromArgb(150, 30, 30); $l.ForeColor = [Drawing.Color]::White
        $l.Font = New-Object Drawing.Font('Segoe UI', 11, [Drawing.FontStyle]::Bold)
        $f.Controls.Add($t); $f.Controls.Add($l)
        $f.Add_KeyDown({ param($sender, $e) if ($e.KeyCode -eq 'Space') { $e.Handled = $true; $sender.Tag = 'ack'; $sender.Close() } })
        $f.Add_FormClosing({ param($sender, $e) if ($sender.Tag -ne 'ack') { $e.Cancel = $true } })
        $f.Add_Shown({ param($sender, $e) $sender.Activate() })
        [void]$f.ShowDialog()
    } catch {
        Write-Host $text -ForegroundColor Red
        Write-Host 'Press SPACE to close...'
        try { do { $k = [Console]::ReadKey($true) } until ($k.Key -eq 'Spacebar') } catch { Start-Sleep -Seconds 600 }
    }
}
trap { Show-Fatal ("{0}`r`n`r`n{1}" -f $_.Exception.Message, $_.ScriptStackTrace); exit 0 }

# WinForms wants a single-threaded apartment.
if ([Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    $a = @('-NoProfile', '-STA', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"", '-CountdownSeconds', $CountdownSeconds)
    if ($NoAutoStart) { $a += '-NoAutoStart' }
    Start-Process powershell.exe -ArgumentList $a | Out-Null
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::SetUnhandledExceptionMode([Windows.Forms.UnhandledExceptionMode]::CatchException)
[Windows.Forms.Application]::EnableVisualStyles()

$ScriptDir = Split-Path -Parent $PSCommandPath
$BuildPs1  = Join-Path $ScriptDir 'build.ps1'
$WorkDir   = (Resolve-Path (Join-Path $ScriptDir '..')).Path
$LogDir    = Join-Path $WorkDir 'out\logs'
$AllStages = @('Prereqs', 'Extract', 'Fetch', 'Verify', 'Codegen', 'Port', 'Mesa', 'Nro', 'SwitchFinal', 'Sd')

# ---------------------------------------------------------------- file discovery / validation
function Format-Size([long]$b) {
    if ($b -ge 1GB) { return ('{0:N2} GB' -f ($b / 1GB)) }
    if ($b -ge 1MB) { return ('{0:N1} MB' -f ($b / 1MB)) }
    return ('{0:N0} KB' -f ($b / 1KB))
}

function Read-Magic([string]$Path) {
    $fs = [IO.File]::OpenRead($Path)
    try {
        $b = New-Object byte[] 4
        $n = $fs.Read($b, 0, 4)
        if ($n -lt 4) { return $null }
        return [Text.Encoding]::ASCII.GetString($b)
    } finally { $fs.Dispose() }
}

function New-Row([string]$Item, [string]$Status, [string]$Detail, [string]$Level) {
    [pscustomobject]@{ Item = $Item; Status = $Status; Detail = $Detail; Level = $Level }
}

function Test-XexFile([string]$Label, [string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return New-Row $Label 'Missing' $Path 'err' }
    try {
        $m = Read-Magic $Path
        $size = Format-Size (Get-Item -LiteralPath $Path).Length
        if ($m -in 'XEX2', 'XEX1') { return New-Row $Label 'Loaded' "$size, header $m" 'ok' }
        return New-Row $Label 'Loaded (warning)' "$size, unexpected header '$m' (expected XEX2)" 'warn'
    } catch { return New-Row $Label 'Cannot read' $_.Exception.Message 'err' }
}

function Test-SkateRepo([string]$d) {
    if (-not $d -or -not (Test-Path -LiteralPath $d)) { return $false }
    return ((Test-Path -LiteralPath (Join-Path $d 'CMakePresets.json')) -and
            ((Test-Path -LiteralPath (Join-Path $d 'src\skate3_app_common.cpp')) -or (Test-Path -LiteralPath (Join-Path $d 'cmake\CodegenTargets.cmake'))))
}

function Find-Skate3Recomp {
    # Same search order as build.ps1: the scripts' own repo, siblings, home folders, then the root of every fixed drive.
    $c = @($WorkDir, (Split-Path $ScriptDir -Parent), "$WorkDir\skate3recomp", "$ScriptDir\skate3recomp", "$(Split-Path $WorkDir -Parent)\skate3recomp",
           "$env:USERPROFILE\skate3recomp", "$env:USERPROFILE\source\repos\skate3recomp", "$env:USERPROFILE\Documents\GitHub\skate3recomp",
           "$env:USERPROFILE\Desktop\skate3recomp", "$env:USERPROFILE\Downloads\skate3recomp")
    foreach ($d in [IO.DriveInfo]::GetDrives()) { if ($d.DriveType -eq 'Fixed') { $c += (Join-Path $d.Name 'skate3recomp') } }
    foreach ($d in ($c | Where-Object { $_ } | Select-Object -Unique)) { if (Test-SkateRepo $d) { return (Resolve-Path -LiteralPath $d).Path } }
    return $null
}

function Find-Inputs {
    $rows = New-Object System.Collections.ArrayList
    $r = @{ GameDir = $null; IsoPath = $null; TitleUpdate = $null; SkateDir = $null; NfsSdkDir = $null; Fatal = $false; Warn = $false; ParseReport = $null }

    # --- build.ps1 present + syntax-checked with PowerShell's own parser
    if (-not (Test-Path -LiteralPath $BuildPs1)) {
        [void]$rows.Add((New-Row 'build.ps1' 'Missing' $BuildPs1 'err')); $r.Fatal = $true
    } else {
        $tok = $null; $err = $null
        [void][Management.Automation.Language.Parser]::ParseFile($BuildPs1, [ref]$tok, [ref]$err)
        if ($err -and $err.Count) {
            $e = $err[0]
            $src = @(Get-Content -LiteralPath $BuildPs1)
            $n = $e.Extent.StartLineNumber
            $txt = ''
            if ($n -ge 1 -and $n -le $src.Count) { $txt = $src[$n - 1].Trim() }
            [void]$rows.Add((New-Row 'build.ps1' 'Syntax error' ("line {0}, col {1}: {2}  |  {3}" -f $n, $e.Extent.StartColumnNumber, $e.Message, $txt) 'err')); $r.Fatal = $true
            # Full report (every error, with 2 lines of context) for the log pane and a file you can send.
            $report = New-Object System.Collections.ArrayList
            [void]$report.Add(("build.ps1: {0} parse error(s), PowerShell {1}, file {2} ({3} lines, {4} bytes)" -f $err.Count, $PSVersionTable.PSVersion, $BuildPs1, $src.Count, (Get-Item $BuildPs1).Length))
            foreach ($pe in $err) {
                $ln = $pe.Extent.StartLineNumber
                [void]$report.Add(("--- line {0}, col {1}: {2} [{3}]" -f $ln, $pe.Extent.StartColumnNumber, $pe.Message, $pe.ErrorId))
                for ($k = [math]::Max(1, $ln - 2); $k -le [math]::Min($src.Count, $ln + 2); $k++) { [void]$report.Add(("{0,5}: {1}" -f $k, $src[$k - 1])) }
            }
            $r.ParseReport = $report
            try {
                New-Item -ItemType Directory -Force $LogDir | Out-Null
                Set-Content -Path (Join-Path $LogDir 'build-ps1-syntax.txt') -Value $report -Encoding UTF8
            } catch { }
        } else {
            [void]$rows.Add((New-Row 'build.ps1' 'Loaded' ("{0}, syntax OK" -f (Format-Size (Get-Item $BuildPs1).Length)) 'ok'))
        }
    }

    try {
        $osi = Get-CimInstance Win32_OperatingSystem
        $totG = [math]::Round($osi.TotalVisibleMemorySize / 1MB, 1); $freeG = [math]::Round($osi.FreePhysicalMemory / 1MB, 1)
        $bud = [int][math]::Min(20, [math]::Floor($freeG * 0.85))
        $lvl = 'ok'; if ($bud -lt 12) { $lvl = 'warn'; $r.Warn = $true }
        [void]$rows.Add((New-Row 'Memory' 'Plan' ("{0} GB total, {1} GB free: the Switch build plans for up to {2} GB (more compile jobs + LTO workers). Close big programs first if this is low." -f $totG, $freeG, $bud) $lvl))
    } catch { }
    # an unzipped nfsmw-nx release placed next to the scripts (sdk\cmake\rexglue_switch.cmake) is used instead of a git clone
    $swHit = Get-ChildItem -LiteralPath $ScriptDir -Recurse -Depth 4 -File -Filter 'rexglue_switch.cmake' -ErrorAction SilentlyContinue |
             Where-Object { $_.Directory.Name -eq 'cmake' -and $_.Directory.Parent.Name -eq 'sdk' } | Select-Object -First 1
    if ($swHit) {
        $r.NfsSdkDir = $swHit.Directory.Parent.FullName
        [void]$rows.Add((New-Row 'nfsmw-nx release' 'Found' ("{0} - used for the Horizon SDK, toolchain and Mesa patch (no git clone needed)" -f $r.NfsSdkDir) 'ok'))
    }
    $portTree = Join-Path $WorkDir 'out\horizon-sdk'
    if (Test-Path -LiteralPath (Join-Path $portTree '.skate3nx-port')) {
        $left = 0
        foreach ($d in 'src', 'include', 'cmake', 'switch_compat') {
            $dd = Join-Path $portTree $d
            if (Test-Path -LiteralPath $dd) { $left += @(Get-ChildItem -LiteralPath $dd -Recurse -File -ErrorAction SilentlyContinue | Select-String -Pattern '^<<<<<<< (skate-fork|HEAD)' -List).Count }
        }
        if ($left -gt 0) { [void]$rows.Add((New-Row 'Horizon SDK port' 'In progress' ("{0} file(s) still have merge-conflict markers in {1}. See out\horizon-port\report.md" -f $left, $portTree) 'warn')); $r.Warn = $true }
        else { [void]$rows.Add((New-Row 'Horizon SDK port' 'Merged' ("no conflict markers left in {0} (a clean merge is not proof it compiles)" -f $portTree) 'ok')) }
    } else {
        [void]$rows.Add((New-Row 'Horizon SDK port' 'Not started' 'Tick Port to merge nfsmw-nx''s Switch layer into the Skate SDK. Without it the Nro stage has nothing to build against.' 'warn'))
        $r.Warn = $true
    }
    $iconFile = Join-Path $ScriptDir 'switch\skate3_icon.jpg'
    if (Test-Path -LiteralPath $iconFile) { [void]$rows.Add((New-Row 'Game icon' 'Loaded' ("{0} (256x256 JPEG, goes into the NRO and the NSP)" -f $iconFile) 'ok')) }
    else { [void]$rows.Add((New-Row 'Game icon' 'Not found' 'Put skate3_icon.jpg (256x256 baseline JPEG) in a switch\ folder next to the scripts; without it the default libnx icon is used.' 'warn')); $r.Warn = $true }
    $fwLocal = Get-ChildItem -LiteralPath $ScriptDir -Recurse -Depth 3 -Filter 'switch-nsp-forwarder*.nro' -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($fwLocal) { [void]$rows.Add((New-Row 'NSP generator' 'Found' ("{0} - will be copied to the SD layout (runs on the Switch, no key file)" -f $fwLocal.FullName) 'ok')) }
    else { [void]$rows.Add((New-Row 'NSP generator' 'Will download' 'switch-nsp-forwarder (TooTallNate) is fetched from GitHub when SwitchFinal runs, unless "install missing prerequisites" is unticked. It makes the NSP ON the Switch.' 'ok')) }
    $smi = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue | Select-Object -First 1
    $gpuText = 'no NVIDIA driver tools found'
    if ($smi) { try { $g = (@(& $smi.Source '--query-gpu=name,memory.total' '--format=csv,noheader' 2>$null) | Select-Object -First 1); if ($g) { $gpuText = $g } } catch { } }
    [void]$rows.Add((New-Row 'GPU' 'Info' ("{0}. Not used by codegen, the devkitA64 compile/link or packaging (CPU-bound); used when you run the Windows host build." -f $gpuText) 'ok'))

    # --- local skate3recomp checkout (used instead of cloning)
    $r.SkateDir = Find-Skate3Recomp
    if ($r.SkateDir) { [void]$rows.Add((New-Row 'skate3recomp folder' 'Found' ("{0} - used as-is, prerequisites are searched for here too" -f $r.SkateDir) 'ok')) }
    else { [void]$rows.Add((New-Row 'skate3recomp folder' 'Not found' 'No local copy on this machine - it will be cloned (v2.0.2)' 'ok')) }

    # --- game dump: a folder holding default.xex (prefer one that also has EAWebkit.xex)
    $roots = @($ScriptDir)
    if (Test-Path (Join-Path $WorkDir 'out\game')) { $roots += (Join-Path $WorkDir 'out\game') }   # from an earlier ISO extraction
    $xexes = @($roots | ForEach-Object { Get-ChildItem -LiteralPath $_ -Recurse -Depth 3 -File -Filter 'default.xex' -ErrorAction SilentlyContinue })
    $pick = $xexes | Where-Object { Test-Path -LiteralPath (Join-Path $_.DirectoryName 'data\webkit\EAWebkit.xex') } | Select-Object -First 1
    if (-not $pick) { $pick = $xexes | Select-Object -First 1 }
    if ($pick) {
        $r.GameDir = $pick.DirectoryName
        [void]$rows.Add((New-Row 'Game dump folder' 'Found' $r.GameDir 'ok'))
        $x1 = Test-XexFile 'default.xex' (Join-Path $r.GameDir 'default.xex')
        $x2 = Test-XexFile 'data\webkit\EAWebkit.xex' (Join-Path $r.GameDir 'data\webkit\EAWebkit.xex')
        [void]$rows.Add($x1); [void]$rows.Add($x2)
        if ($x1.Level -eq 'err' -or $x2.Level -eq 'err') { $r.GameDir = $null; $r.Warn = $true }
        if ($x1.Level -eq 'warn' -or $x2.Level -eq 'warn') { $r.Warn = $true }
    } else {
        [void]$rows.Add((New-Row 'Game dump folder' 'Not found' 'No extracted dump (default.xex) next to the scripts; looking for an ISO instead.' 'warn'))
    }

    # --- Skate 3 ROM: plain .iso, or the .7z/.zip/.rar download that contains it.
    #     Reference: Vimm's Lair Xbox 360 vault #78455 - "Skate 3", USA/Europe, v1.0, delivered as .7z (Redump-synced).
    #     Used only when there is no extracted dump.
    $all = @(Get-ChildItem -LiteralPath $ScriptDir -Recurse -Depth 3 -File -ErrorAction SilentlyContinue |
             Where-Object { $_.Extension -eq '.iso' -or ($_.Extension -in '.7z', '.zip', '.rar' -and $_.Length -gt 1GB) })
    if ($all.Count) {
        $rom = $all | Sort-Object { if ($_.Name -match 'skate') { 0 } else { 1 } }, { if ($_.Extension -eq '.7z') { 0 } elseif ($_.Extension -eq '.iso') { 1 } else { 2 } } | Select-Object -First 1
        $note = if ($r.GameDir) { 'extracted dump found, so this ROM will not be used' } else { 'will be extracted by the Extract stage' }
        try {
            if ($rom.Extension -eq '.iso') {
                $fs = [IO.File]::OpenRead($rom.FullName); $off = -1
                try {
                    foreach ($o in 0x0, 0xFB20, 0x20600, 0x2080000, 0xFD90000) {      # same offsets skate3recomp's installer probes
                        $pos = $o + 32 * 2048
                        if ($pos + 20 -gt $fs.Length) { continue }
                        $fs.Position = $pos
                        $b = New-Object byte[] 20
                        if ($fs.Read($b, 0, 20) -eq 20 -and [Text.Encoding]::ASCII.GetString($b) -eq 'MICROSOFT*XBOX*MEDIA') { $off = $o; break }
                    }
                } finally { $fs.Dispose() }
                if ($off -ge 0) {
                    $r.IsoPath = $rom.FullName
                    [void]$rows.Add((New-Row 'Skate 3 ISO' 'Loaded' ("{0}, {1}, XDVDFS at 0x{2:X}; {3}" -f $rom.Name, (Format-Size $rom.Length), $off, $note) 'ok'))
                } else {
                    $r.Warn = $true
                    [void]$rows.Add((New-Row 'Skate 3 ISO' 'Not usable' "$($rom.Name): no Xbox 360 XDVDFS volume found (raw/compressed/repacked image?)" 'err'))
                }
            } else {
                $fs = [IO.File]::OpenRead($rom.FullName)
                try { $hb = New-Object byte[] 6; [void]$fs.Read($hb, 0, 6) } finally { $fs.Dispose() }
                $hex = ($hb | ForEach-Object { $_.ToString('X2') }) -join ''
                $kind = if ($hex -eq '377ABCAF271C') { '7z' } elseif ($hex.StartsWith('504B')) { 'zip' } elseif ($hex.StartsWith('526172')) { 'rar' } else { $null }
                if (-not $kind) {
                    $r.Warn = $true
                    [void]$rows.Add((New-Row 'Skate 3 ROM (archive)' 'Not usable' "$($rom.Name): not a valid 7z/zip/rar file (header $hex)" 'err'))
                } else {
                    $inner = ''
                    $z = Get-Command 7z -ErrorAction SilentlyContinue | Select-Object -First 1
                    $zp = if ($z) { $z.Source } else { @("$env:ProgramFiles\7-Zip\7z.exe", "${env:ProgramFiles(x86)}\7-Zip\7z.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1 }
                    if ($zp) {
                        $cur = $null; $best = $null
                        foreach ($l in (& $zp l -slt -ba $rom.FullName 2>$null)) {
                            if ($l -match '^Path = (.+)$') { $cur = @{ P = $Matches[1]; S = 0L } }
                            elseif ($cur -and $l -match '^Size = (\d+)$') { $cur.S = [int64]$Matches[1]; if ($cur.P -match '\.iso$' -and (-not $best -or $cur.S -gt $best.S)) { $best = $cur } }
                        }
                        $inner = if ($best) { "; contains $($best.P) ($(Format-Size $best.S))" } else { '; WARNING: no .iso inside' }
                        if (-not $best) { $r.Warn = $true }
                    } else { $inner = '; 7-Zip will be installed to unpack it' }
                    $r.IsoPath = $rom.FullName
                    [void]$rows.Add((New-Row 'Skate 3 ROM (archive)' 'Loaded' ("{0}, {1}, valid {2} archive{3}; {4}. Allow ~20 GB free (ISO + extracted game)." -f $rom.Name, (Format-Size $rom.Length), $kind, $inner, $note) 'ok'))
                }
            }
        } catch { $r.Warn = $true; [void]$rows.Add((New-Row 'Skate 3 ROM' 'Cannot read' $_.Exception.Message 'err')) }
        if ($all.Count -gt 1) { $r.Warn = $true; [void]$rows.Add((New-Row 'Other ROM files' 'Ignored' (($all | Where-Object { $_.FullName -ne $rom.FullName } | ForEach-Object Name) -join ', ') 'warn')) }
    }
    if (-not $r.GameDir -and -not $r.IsoPath) {
        $r.Warn = $true
        [void]$rows.Add((New-Row 'Game files' 'Not provided' 'Put your Skate 3 ROM (.7z from Vimm vault #78455, or the .iso) or an extracted dump next to these scripts. Codegen will be skipped.' 'warn'))
    }

    # --- title update 3 package: original name (any subfolder, e.g. 5C087C2C\TU_...), a renamed copy (size+SHA-1), or a .zip
    $TuName = 'TU_12K2276_000000C000000.00000000000O3'; $TuSize = 1773568
    $TuSha1 = '0e362b6d2483317605302e64542ef29c411871ca'          # No-Intro: Skate 3 (World) (v3)
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $cands = @(Get-ChildItem -LiteralPath $ScriptDir -Recurse -Depth 3 -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Name -like 'TU_12K2276*' -or $_.Length -eq $TuSize -or $_.Extension -eq '.zip' } |
               Sort-Object { if ($_.Name -eq $TuName) { 0 } elseif ($_.Name -like 'TU_12K2276*') { 1 } elseif ($_.Extension -eq '.zip') { 3 } else { 2 } })
    $tuRow = $null; $fallback = $null
    foreach ($c in $cands) {
        try {
            $bytes = $null; $from = ''
            if ($c.Extension -eq '.zip') {
                $zip = [IO.Compression.ZipFile]::OpenRead($c.FullName)
                try {
                    $e = $zip.Entries | Where-Object { $_.Name -like 'TU_12K2276*' -or $_.Length -eq $TuSize } | Select-Object -First 1
                    if (-not $e) { continue }
                    $ms = New-Object IO.MemoryStream; $es = $e.Open(); try { $es.CopyTo($ms) } finally { $es.Dispose() }
                    $bytes = $ms.ToArray(); $from = " in $($c.Name)"
                } finally { $zip.Dispose() }
            } else { $bytes = [IO.File]::ReadAllBytes($c.FullName) }
            $sha = -join ([Security.Cryptography.SHA1]::Create().ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') })
            $named = ($c.Name -like 'TU_12K2276*')
            if (-not ($named -or $sha -eq $TuSha1)) { continue }
            $magic = if ($bytes.Length -ge 4) { [Text.Encoding]::ASCII.GetString($bytes, 0, 4) } else { '' }
            $size = Format-Size $bytes.Length
            if ($sha -eq $TuSha1) {
                $row = New-Row 'Title Update 3' 'Loaded' ("{0}{1}, {2}, STFS '{3}', SHA-1 matches No-Intro v3" -f $c.Name, $from, $size, $magic) 'ok'
                $r.TitleUpdate = $c.FullName; $tuRow = $row; break
            } elseif (-not $fallback) {
                $fallback = @{ Row = (New-Row 'Title Update 3' 'Loaded (warning)' ("{0}{1}, {2}, SHA-1 differs from No-Intro v3 (expected {3} bytes) - may be another version" -f $c.Name, $from, $size, $TuSize) 'warn'); Path = $c.FullName }
            }
        } catch { continue }
    }
    if (-not $tuRow -and $fallback) { $tuRow = $fallback.Row; $r.TitleUpdate = $fallback.Path; $r.Warn = $true }
    if ($tuRow) { [void]$rows.Add($tuRow) }
    else {
        $r.Warn = $true
        [void]$rows.Add((New-Row 'Title Update 3' 'Not provided' "Put $TuName (or its .zip) next to the scripts. Without it codegen uses the unpatched image." 'warn'))
    }

    $r.Rows = $rows
    return $r
}

# ---------------------------------------------------------------- UI
$bg = [Drawing.Color]::FromArgb(30, 30, 30)
$fg = [Drawing.Color]::FromArgb(220, 220, 220)
$cOk = [Drawing.Color]::FromArgb(110, 210, 120)
$cWarn = [Drawing.Color]::FromArgb(240, 190, 80)
$cErr = [Drawing.Color]::FromArgb(240, 100, 100)
$cStep = [Drawing.Color]::FromArgb(110, 180, 255)

$form = New-Object Windows.Forms.Form
$form.Text = 'Skate 3 -> Switch build'
$form.Size = New-Object Drawing.Size(960, 760)
$form.MinimumSize = New-Object Drawing.Size(760, 600)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $bg; $form.ForeColor = $fg
$form.Font = New-Object Drawing.Font('Segoe UI', 9)

$lblFiles = New-Object Windows.Forms.Label
$lblFiles.Text = 'Files'; $lblFiles.Font = New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)
$lblFiles.Location = '12,8'; $lblFiles.AutoSize = $true

$lv = New-Object Windows.Forms.ListView
$lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.HeaderStyle = 'Nonclickable'
$lv.BackColor = [Drawing.Color]::FromArgb(40, 40, 40); $lv.ForeColor = $fg
$lv.Location = '12,30'; $lv.Size = '920,150'; $lv.Anchor = 'Top,Left,Right'
[void]$lv.Columns.Add('Item', 190); [void]$lv.Columns.Add('Status', 120); [void]$lv.Columns.Add('Detail', 590)

$lblSummary = New-Object Windows.Forms.Label
$lblSummary.Location = '12,186'; $lblSummary.Size = '920,22'; $lblSummary.Anchor = 'Top,Left,Right'
$lblSummary.Font = New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)

$gb = New-Object Windows.Forms.GroupBox
$gb.Text = 'Stages'; $gb.ForeColor = $fg
$gb.Location = '12,212'; $gb.Size = '920,80'; $gb.Anchor = 'Top,Left,Right'
$chk = @{}
$x = 6
foreach ($s in $AllStages) {
    $c = New-Object Windows.Forms.CheckBox
    $c.Text = $s; $c.AutoSize = $true; $c.Location = New-Object Drawing.Point($x, 22)
    if ($s -eq 'Prereqs') { $c.Checked = $true; $c.Enabled = $false }   # always runs first
    $chk[$s] = $c; $gb.Controls.Add($c); $x += 90
}
$chk['Fetch'].Checked = $true; $chk['Verify'].Checked = $true
$tip = New-Object Windows.Forms.ToolTip
$tip.SetToolTip($chk['Extract'], 'Unpacks your ROM (.7z via 7-Zip, then the .iso) to out\game. Needs ~20 GB free at peak. Skipped if an extracted dump is already present.')
$tip.SetToolTip($chk['Port'], 'Ports nfsmw-nx''s Horizon (Switch) SDK layer onto the Skate SDK fork into out\horizon-sdk and writes a conflict report. Never overwrites your edits there unless you rebuild it. Needs internet (clones upstream rexglue-sdk).')
$tip.SetToolTip($chk['Mesa'], 'Needs the NVK driver build (see nfsmw-nx mesa/README.md); stops with instructions if not built.')
$tip.SetToolTip($chk['Nro'], 'Cross-compiles the .nro. Refuses to start if the Switch SDK lacks headers skate3recomp uses (the Phase 3 port is not done) - it tells you which.')
$tip.SetToolTip($chk['SwitchFinal'], 'Needs an .nro. Builds the SD-card layout and stages switch-nsp-forwarder, which creates the NSP ON the Switch (no keys, nothing built on the PC).')
$chkInstall = New-Object Windows.Forms.CheckBox
$chkInstall.Text = 'Install missing prerequisites automatically (winget / devkitPro installer, may show UAC prompts)'
$chkInstall.AutoSize = $true; $chkInstall.Checked = $true; $chkInstall.Location = '12,50'
$gb.Controls.Add($chkInstall)

$lblStatus = New-Object Windows.Forms.Label
$lblStatus.Location = '12,300'; $lblStatus.Size = '700,20'; $lblStatus.Anchor = 'Top,Left,Right'; $lblStatus.Text = 'Loading...'
$lblTime = New-Object Windows.Forms.Label
$lblTime.Location = '720,300'; $lblTime.Size = '212,20'; $lblTime.TextAlign = 'MiddleRight'; $lblTime.Anchor = 'Top,Right'

$bar = New-Object Windows.Forms.ProgressBar
$bar.Location = '12,322'; $bar.Size = '880,24'; $bar.Anchor = 'Top,Left,Right'; $bar.Minimum = 0; $bar.Maximum = 100
$lblPct = New-Object Windows.Forms.Label
$lblPct.Location = '896,325'; $lblPct.Size = '40,20'; $lblPct.Anchor = 'Top,Right'; $lblPct.Text = '0%'

$rtb = New-Object Windows.Forms.RichTextBox
$rtb.Location = '12,356'; $rtb.Size = '920,272'; $rtb.Anchor = 'Top,Bottom,Left,Right'
$rtb.ReadOnly = $true; $rtb.BackColor = [Drawing.Color]::FromArgb(18, 18, 18); $rtb.ForeColor = $fg
$rtb.Font = New-Object Drawing.Font('Consolas', 9); $rtb.WordWrap = $false; $rtb.HideSelection = $false

$btnStart = New-Object Windows.Forms.Button; $btnStart.Text = 'Start now'
$btnStop  = New-Object Windows.Forms.Button; $btnStop.Text = 'Cancel'
$btnLogs  = New-Object Windows.Forms.Button; $btnLogs.Text = 'Open logs folder'
$btnClose = New-Object Windows.Forms.Button; $btnClose.Text = 'Close'
$bx = 12
foreach ($b in $btnStart, $btnStop, $btnLogs) {
    $b.Size = '130,30'; $b.Location = New-Object Drawing.Point($bx, 670); $b.Anchor = 'Bottom,Left'
    $b.FlatStyle = 'System'; $bx += 140
}
$btnClose.Size = '100,30'; $btnClose.Location = '832,670'; $btnClose.Anchor = 'Bottom,Right'; $btnClose.FlatStyle = 'System'
$lblCount = New-Object Windows.Forms.Label
$lblCount.Location = '440,676'; $lblCount.Size = '380,20'; $lblCount.Anchor = 'Bottom,Left,Right'; $lblCount.ForeColor = $cWarn

$lblErr = New-Object Windows.Forms.Label
$lblErr.Location = '12,634'; $lblErr.Size = '920,28'; $lblErr.Anchor = 'Bottom,Left,Right'; $lblErr.Visible = $false
$lblErr.BackColor = [Drawing.Color]::FromArgb(150, 30, 30); $lblErr.ForeColor = [Drawing.Color]::White; $lblErr.TextAlign = 'MiddleCenter'
$lblErr.Font = New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)
$form.KeyPreview = $true
$form.Controls.AddRange(@($lblErr, $lblFiles, $lv, $lblSummary, $gb, $lblStatus, $lblTime, $bar, $lblPct, $rtb, $btnStart, $btnStop, $btnLogs, $btnClose, $lblCount))

# ---------------------------------------------------------------- state
$script:Inputs = $null
$script:Proc = $null
$script:OutTask = $null
$script:ErrTask = $null
$script:Planned = @()
$script:StageIdx = 0
$script:StageFrac = 0.0
$script:Started = $null
$script:Remaining = 0
$script:Running = $false
$script:Finished = $false
$script:HasError = $false
$script:ErrAck = $false
$script:UserCancelled = $false

$countdownTimer = New-Object Windows.Forms.Timer; $countdownTimer.Interval = 1000
$pollTimer = New-Object Windows.Forms.Timer; $pollTimer.Interval = 100

function Add-Log([string]$text, [Drawing.Color]$color) {
    if ($rtb.TextLength -gt 1500000) { $rtb.Select(0, 500000); $rtb.SelectedText = '' }
    $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
    $rtb.SelectionColor = $color
    $rtb.AppendText($text + "`n")
    $rtb.ScrollToCaret()
}

function Set-ErrorState([string]$msg) {
    # Any error locks the window shut until the user presses SPACE.
    if ($msg) { Add-Log "ERROR: $msg" $cErr }
    $script:HasError = $true; $script:ErrAck = $false
    $lblErr.Text = 'An error occurred - this window stays open. Press SPACE to close it.'
    $lblErr.Visible = $true
    $btnClose.Enabled = $false; $btnClose.Text = 'Press SPACE'
    $form.ActiveControl = $rtb                     # keep focus off the buttons so SPACE can't click one
    try { [Media.SystemSounds]::Hand.Play() } catch { }
}

function Clear-ErrorState {
    $script:HasError = $false; $lblErr.Visible = $false
    $btnClose.Enabled = $true; $btnClose.Text = 'Close'
}

function Invoke-Safe([scriptblock]$Body) {
    try { & $Body } catch { Set-ErrorState ("{0} (line {1})" -f $_.Exception.Message, $_.InvocationInfo.ScriptLineNumber) }
}

function Set-Progress {
    $n = [math]::Max(1, $script:Planned.Count)
    $v = [int][math]::Min(99, [math]::Floor(100 * ($script:StageIdx + $script:StageFrac) / $n))
    $bar.Value = $v; $lblPct.Text = "$v%"
}

function Handle-Line([string]$line) {
    if ($null -eq $line) { return }
    $line = ($line -split "`r")[-1]          # git progress uses carriage returns
    if ($line.Trim().Length -eq 0) { return }

    if ($line -match '^==\s+(Prereqs|Extract|Fetch|Verify|Codegen|Port|Mesa|Nro|SwitchFinal|Sd)\b') {
        $i = [array]::IndexOf($script:Planned, $Matches[1])
        $name = $Matches[1]
        if ($i -ge $script:StageIdx) {
            $script:StageIdx = $i; $script:StageFrac = 0.0
            $lblStatus.Text = "Stage $($i + 1) of $($script:Planned.Count): $name"
            Set-Progress
        }
    } elseif ($line -match '^==\s+(.+)$') {
        $lblStatus.Text = "Stage $($script:StageIdx + 1) of $($script:Planned.Count): $($Matches[1])"
    } elseif ($line -match '^\[(\d+)/(\d+)\]') {                       # ninja
        if ([int]$Matches[2] -gt 0) { $script:StageFrac = [math]::Min(0.99, [double]$Matches[1] / [double]$Matches[2]); Set-Progress }
    } elseif ($line -match '^Extracting:\s+(\d+)%') {                 # ISO extraction
        $script:StageFrac = [math]::Min(0.99, [double]$Matches[1] / 100.0); Set-Progress
    } elseif ($line -match '^(Receiving objects|Resolving deltas|Updating files):\s+(\d+)%') {   # git
        $script:StageFrac = [math]::Min(0.99, [double]$Matches[2] / 100.0); Set-Progress
    }

    $c = $fg
    if ($line -match '^==') { $c = $cStep }
    elseif ($line -match '\[ok\]|^Done\.') { $c = $cOk }
    elseif ($line -match '\[warn\]') { $c = $cWarn }
    elseif ($line -match '^FAILED|\berror\b|\bfatal\b') { $c = $cErr }
    if ($line -match '^FAILED') { Set-ErrorState $null }
    Add-Log $line $c
}

function Finish-Run {
    $pollTimer.Stop()
    $script:Running = $false; $script:Finished = $true
    $code = $script:Proc.ExitCode
    if ($code -eq 0) {
        $bar.Value = 100; $lblPct.Text = '100%'
        $lblStatus.Text = 'Finished successfully.'; $lblStatus.ForeColor = $cOk
    } elseif ($script:UserCancelled) {
        $lblStatus.Text = 'Cancelled.'; $lblStatus.ForeColor = $cWarn
    } else {
        $lblStatus.Text = "Stopped with exit code $code - see the red lines above and the log."; $lblStatus.ForeColor = $cErr
        Set-ErrorState "The build stopped with exit code $code."
    }
    Add-Log "---- exited with code $code ----" ($(if ($code -eq 0) { $cOk } elseif ($script:UserCancelled) { $cWarn } else { $cErr }))
    foreach ($c in $chk.Values) { if ($c.Text -ne 'Prereqs' -and ($c.Text -ne 'Codegen' -or $script:Inputs.GameDir -or $script:Inputs.IsoPath) -and ($c.Text -ne 'Extract' -or ($script:Inputs.IsoPath -and -not $script:Inputs.GameDir))) { $c.Enabled = $true } }
    $chkInstall.Enabled = $true
    $btnStart.Text = 'Run again'; $btnStart.Enabled = $true; $btnStop.Enabled = $false
}

function Quote-Ps([string]$s) { return "'" + ($s -replace "'", "''") + "'" }

function Start-Build {
    $countdownTimer.Stop(); $lblCount.Text = ''
    if ($script:Inputs.Fatal) { return }

    $sel = @($AllStages | Where-Object { $chk[$_].Checked })
    if ($sel -contains 'Codegen' -and -not $script:Inputs.GameDir -and -not $script:Inputs.IsoPath) {
        [void][Windows.Forms.MessageBox]::Show('Codegen needs an extracted dump or the Skate 3 ROM (.7z / .iso) next to these scripts. Untick Codegen or add one and re-run.', 'Game files missing')
        $btnStart.Enabled = $true; return
    }
    $script:Planned = $sel
    $script:StageIdx = 0; $script:StageFrac = 0.0; $script:Finished = $false; $script:UserCancelled = $false
    Clear-ErrorState
    $bar.Value = 0; $lblPct.Text = '0%'; $lblStatus.ForeColor = $fg; $lblStatus.Text = 'Starting...'

    $cmd = "& " + (Quote-Ps $BuildPs1) + " -Stage " + ($sel -join ',')
    if ($script:Inputs.GameDir)     { $cmd += " -GameDir " + (Quote-Ps $script:Inputs.GameDir) }
    elseif ($script:Inputs.IsoPath) { $cmd += " -IsoPath " + (Quote-Ps $script:Inputs.IsoPath) }
    if ($script:Inputs.TitleUpdate) { $cmd += " -TitleUpdate " + (Quote-Ps $script:Inputs.TitleUpdate) }
    if ($script:Inputs.SkateDir) { $cmd += " -Skate3RecompDir " + (Quote-Ps $script:Inputs.SkateDir) }
    if ($script:Inputs.NfsSdkDir) { $cmd += " -NfsSdkDir " + (Quote-Ps $script:Inputs.NfsSdkDir) }
    $cmd += ' -NoPause'
    if ($chkInstall.Checked) { $cmd += ' -Yes' } else { $cmd += ' -NoInstall' }

    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = 'powershell.exe'
    $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -Command `"$cmd; if (-not `$?) { exit 1 }; exit `$LASTEXITCODE`""
    $psi.WorkingDirectory = $ScriptDir
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.StandardOutputEncoding = [Text.Encoding]::UTF8; $psi.StandardErrorEncoding = [Text.Encoding]::UTF8

    Add-Log ("> powershell.exe " + $psi.Arguments) $cStep
    try { $script:Proc = [Diagnostics.Process]::Start($psi) }
    catch { Set-ErrorState "Could not start powershell.exe: $($_.Exception.Message)"; $btnStart.Enabled = $true; return }
    $script:OutTask = $script:Proc.StandardOutput.ReadLineAsync()
    $script:ErrTask = $script:Proc.StandardError.ReadLineAsync()
    $script:Started = Get-Date; $script:Running = $true
    foreach ($c in $chk.Values) { $c.Enabled = $false }
    $chkInstall.Enabled = $false
    $btnStart.Enabled = $false; $btnStop.Text = 'Stop build'; $btnStop.Enabled = $true
    $pollTimer.Start()
}

$pollTimer.Add_Tick({ Invoke-Safe {
    if (-not $script:Proc) { return }
    $lblTime.Text = 'Elapsed ' + ((Get-Date) - $script:Started).ToString('hh\:mm\:ss')
    $n = 0
    while ($script:OutTask -and $script:OutTask.IsCompleted -and $n -lt 400) {
        $l = $script:OutTask.Result
        if ($null -eq $l) { $script:OutTask = $null } else { Handle-Line $l; $script:OutTask = $script:Proc.StandardOutput.ReadLineAsync() }
        $n++
    }
    while ($script:ErrTask -and $script:ErrTask.IsCompleted -and $n -lt 400) {
        $l = $script:ErrTask.Result
        if ($null -eq $l) { $script:ErrTask = $null } else { Handle-Line $l; $script:ErrTask = $script:Proc.StandardError.ReadLineAsync() }
        $n++
    }
    if (-not $script:OutTask -and -not $script:ErrTask -and $script:Proc.HasExited -and -not $script:Finished) { Finish-Run }
} })

$countdownTimer.Add_Tick({ Invoke-Safe {
    $script:Remaining--
    if ($script:Remaining -le 0) { Start-Build }
    else { $lblCount.Text = "Starting automatically in $($script:Remaining)s (untick stages now to change; Cancel to stop)" }
} })

$btnStart.Add_Click({ Invoke-Safe { Start-Build } })
$btnStop.Add_Click({ Invoke-Safe {
    if ($script:Running -and $script:Proc -and -not $script:Proc.HasExited) {
        $script:UserCancelled = $true
        & taskkill.exe /T /F /PID $script:Proc.Id | Out-Null
        Add-Log '---- cancelled by user ----' $cWarn
    } elseif ($countdownTimer.Enabled) {
        $countdownTimer.Stop(); $lblCount.Text = 'Auto-start cancelled. Press Start now when ready.'
    }
} })
$btnLogs.Add_Click({ Invoke-Safe {
    New-Item -ItemType Directory -Force $LogDir | Out-Null
    Start-Process explorer.exe $LogDir
} })
$btnClose.Add_Click({ $form.Close() })
$form.Add_FormClosing({
    if ($_.CloseReason -eq 'WindowsShutDown') { return }
    if ($script:Running -and $script:Proc -and -not $script:Proc.HasExited) {
        $a = [Windows.Forms.MessageBox]::Show('A build is still running. Stop it and close?', 'Build running', 'YesNo', 'Warning')
        if ($a -ne 'Yes') { $_.Cancel = $true; return }
        $script:UserCancelled = $true
        & taskkill.exe /T /F /PID $script:Proc.Id | Out-Null
    }
    # Error present: refuse to close until SPACE has been pressed.
    if ($script:HasError -and -not $script:ErrAck) { $_.Cancel = $true; $lblErr.Text = 'Press SPACE to close (the window cannot be closed any other way while an error is shown).' }
})
$form.Add_KeyDown({
    if ($script:HasError -and $_.KeyCode -eq 'Space') {
        $_.Handled = $true; $_.SuppressKeyPress = $true
        $script:ErrAck = $true; $form.Close()
    }
})
[Windows.Forms.Application]::add_ThreadException({ param($sender, $e) Set-ErrorState $e.Exception.Message })


# ---------------------------------------------------------------- load + verify, then countdown
$form.Add_Shown({ Invoke-Safe {
    $form.Refresh()
    Add-Log "Script folder: $ScriptDir" $cStep
    $btnStart.Enabled = $false; $btnStop.Enabled = $true; $btnStop.Text = 'Cancel'
    $script:Inputs = Find-Inputs
    foreach ($row in $script:Inputs.Rows) {
        $it = New-Object Windows.Forms.ListViewItem($row.Item)
        [void]$it.SubItems.Add($row.Status); [void]$it.SubItems.Add($row.Detail)
        $it.ForeColor = switch ($row.Level) { 'ok' { $cOk } 'warn' { $cWarn } default { $cErr } }
        [void]$lv.Items.Add($it)
        Add-Log ("{0,-26} {1,-18} {2}" -f $row.Item, $row.Status, $row.Detail) $it.ForeColor
    }

    if ($script:Inputs.ParseReport) {
        foreach ($pl in $script:Inputs.ParseReport) { Add-Log $pl $cErr }
        Add-Log ("(saved to {0})" -f (Join-Path $LogDir 'build-ps1-syntax.txt')) $cWarn
    }
    if ($script:Inputs.Fatal -or @($script:Inputs.Rows | Where-Object { $_.Level -eq 'err' }).Count) {
        Set-ErrorState 'One or more files failed to load - see the red items in the list.'
    }
    if ($script:Inputs.Fatal) {
        $lblSummary.Text = 'build.ps1 did not load correctly - cannot continue.'; $lblSummary.ForeColor = $cErr
        $lblStatus.Text = 'Fix the red item above and restart.'; $btnStop.Enabled = $false; return
    }
    if ($script:Inputs.Warn) { $lblSummary.Text = 'Loaded, with warnings (see orange items).'; $lblSummary.ForeColor = $cWarn }
    else { $lblSummary.Text = 'All files loaded correctly.'; $lblSummary.ForeColor = $cOk }

    $haveGame = ($script:Inputs.GameDir -or $script:Inputs.IsoPath)
    if ($haveGame) { $chk['Codegen'].Checked = $true } else { $chk['Codegen'].Checked = $false; $chk['Codegen'].Enabled = $false }
    if ($script:Inputs.IsoPath -and -not $script:Inputs.GameDir) { $chk['Extract'].Checked = $true } else { $chk['Extract'].Checked = $false; $chk['Extract'].Enabled = $false }
    $lblStatus.Text = 'Ready.'
    $btnStart.Enabled = $true
    if (-not $NoAutoStart) {
        $script:Remaining = $CountdownSeconds
        $lblCount.Text = "Starting automatically in $($script:Remaining)s (untick stages now to change; Cancel to stop)"
        $countdownTimer.Start()
    }
} })

[void]$form.ShowDialog()
