@echo off
rem Double-click launcher. Runs the GUI hidden. If PowerShell itself fails to start or parse the launcher,
rem a visible window opens and stays open until SPACE is pressed.
if /i not "%~1"=="--min" (
  start "Skate 3 NX build" /min "%~f0" --min
  exit /b
)
start "" /wait powershell.exe -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0launcher.ps1"
if errorlevel 1 goto :err
exit /b 0

:err
start "Skate 3 NX build - ERROR" powershell.exe -NoProfile -Command "Write-Host ''; Write-Host 'The launcher failed to start - exit code %ERRORLEVEL%.' -ForegroundColor Red; Write-Host 'To see the message, run in a PowerShell window:'; Write-Host '  powershell -STA -ExecutionPolicy Bypass -File launcher.ps1'; Write-Host ''; Write-Host 'Press SPACE to close this window.' -ForegroundColor Yellow; do { $k = [Console]::ReadKey($true) } until ($k.Key -eq 'Spacebar')"
exit /b 1
